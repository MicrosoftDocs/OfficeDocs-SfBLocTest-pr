---
title: Skype a teléfono
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 2/29/2016
ms.audience: Admin
ms.topic: How To
ms.prod: SKYPEFORBUSINESS
description: Learn what Skype--to-phone is and get links to information on setup, access numbers, and providers. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: fa2a6199-8b47-4d1f-bde9-e9dff3b466df
---


# Skype a teléfono

Skype para teléfono es un conjunto de características que permite a los asociados sindicados proporcionar correo de voz y características de operador automático para las organizaciones que usan Skype Empresarial Online. Skype para teléfono para Office UNRESOLVED_TOKEN_VAL(365) es una solución de voz basada en la nube que está completamente integrada con Skype Empresarial Online y Exchange Online. Como administrador de Office UNRESOLVED_TOKEN_VAL(365), se han implementado la conectividad y el enrutamiento de red y el asociado sindicado de Skype para teléfono ofrece resistencia de centro de datos y conectividad de teléfono completa.
  
    
    


-  [Configurar mensajería por voz de Skype a teléfono](skype-to-phone-voice-messaging-set-up.md)
    
  
-  [Skypes-to-phone access numbers](skypes-to-phone-access-numbers.md)
    
  
-  [Skype-to-phone providers](skype-to-phone-providers.md)
    
  

