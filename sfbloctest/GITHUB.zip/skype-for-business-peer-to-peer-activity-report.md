---
title: Informe de actividad punto a punto de Skype Empresarial
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 10/24/2017
ms.audience: Admin
ms.topic: How To
f1_keywords:
- O365E_ReportsS4BPeerActivity
- O365M_ReportsS4BPeerActivity
- O365P_ReportsS4BPeerActivity
description: Get a Skype for Business Peer-to-peer activity report, and learn how to interpret and customize it for your needs. 
ms.collection:
- Adm_Skype4B_Online
- Adm_UI_Elements
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 operated by 21Vianet - Enterprise admin
- Office 365 operated by 21Vianet - Midsize Business admin
- Office 365 operated by 21Vianet - Small Business admin
- Office 365 Small Business admin
- Skype for Business admin center
- Skype for Business Online
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: d3b2d569-4ee9-44b8-92bf-d518142f0713
---



# Informe de actividad punto a punto de Skype Empresarial

> [!IMPORTANT]
> Este artículo se ha traducido con traducción automática; vea la  [declinación de responsabilidades](d3b2d569-4ee9-44b8-92bf-d518142f0713.md#MT_Footer). Para su referencia, puede encontrar la versión en inglés de este artículo  [aquí](https://support.office.com/en-us/article/d3b2d569-4ee9-44b8-92bf-d518142f0713). 
  
    
    


El nuevo panel **Informes** de Office 365 muestra la información general de actividad en los productos de Office 365 de su organización. Le permite explorar los informes de nivel de cada producto para obtener datos más pormenorizados sobre las actividades dentro de cada producto. Por ejemplo, puede usar el **Informe de actividad punto a punto de Skype Empresarial** para ver cuánto utilizan sus usuarios la MI, el audio/vídeo, el uso compartido de aplicaciones y la transferencia de archivos. Consulte [Informes de actividades en el Centro de administración de Office 365](http://technet.microsoft.com/library/0d6dfb17-8582-4172-a9a9-aed798150263%28Office.14%29.aspx).
  
    
    


Este informe, junto con los demás informes de Skype Empresarial, le ofrece detalles sobre la actividad en toda su organización. Estos detalles son muy útiles para investigar, planificar y tomar otras decisiones empresariales para su organización.
  
    
    


> [!NOTE]
> Puede ver todos los informes de Skype Empresarial cuando inicie sesión como administrador en el Centro de administración de Office 365. 
  
    
    


## Cómo acceder al informe de actividad punto a punto de Skype Empresarial


1. Vaya al Centro de administración de Office 365 > **Informes**
    
  
2. Seleccione **Informes** en el menú izquierdo o haga clic en el widget **Informes**.
    
  
3. Haga clic en el widget **Actividad de Skype Empresarial** en el panel y seleccione **Actividad punto a punto de Skype Empresarial** o selecciónelo de la lista **Seleccionar un informe** en la página de informes **Uso**.
    
     ![Skype peer to peer menu selected](images/603ec74a-7f39-4e12-8f10-00979f7ee977.PNG)
  

    
    > [!IMPORTANT]
      > Según la suscripción de Office 365 que tenga, puede que no vea todos los productos ni los informes de actividad que se muestran en aquí. 

## Interpretar el informe de actividad punto a punto de Skype Empresarial

Puede obtener una vista de su actividad punto a punto de Skype Empresarial en los gráficos **Actividad**, **Usuarios** y **Minutos**.
  
    
    

  
    
    
![Skype peer to peer report with callouts.](images/82dec398-ca05-46c7-b0fe-affcbfc0ddd5.PNG)
  
    
    

  
    
    

|||
|:-----|:-----|
|**1** <br/> |El informe de **actividad punto a punto de Skype Empresarial** se puede usar para ver las tendencias de los últimos 7 días, 30 días, 90 días o 180 días. <br/> |
|**2** <br/> |Cada informe tiene la fecha del momento en que se generó. Normalmente, el informe refleja una latencia de 24 a 48 horas desde el momento de actividad.  <br/> |
|**3** <br/> |Utilice los datos del gráfico interactivo **Actividad** para comprender las tendencias de uso y ver el número total de sesiones por tipo de sesión que se realizan en su organización. Se muestra el número total y los tipos de sesiones de **MI**, **Audio**, **Vídeo**, **Uso compartido de aplicaciones** y **Transferencias de archivos** de su organización. <br/> |
|**4** <br/> | Utilice los datos del gráfico interactivo **Usuarios** para comprender las tendencias de uso y ver el número de usuarios únicos que participan en las actividades punto a punto realizadas en su organización. Se muestra el número total de usuarios y los tipos de conferencias de **MI**, **Audio**, **Vídeo**, **Uso compartido de aplicaciones** y **Transferencias de archivos** en las sesiones de punto a punto. <br/> |
|**5** <br/> |Usar los datos de gráfico interactivo en el gráfico de **minutos** para comprender las tendencias de uso y para ver el número de minutos de actividades de punto a punto con audio y vídeo de los usuarios. Se muestran el número total de minutos de **Audio** y **vídeo** que se utiliza en sesiones de punto a punto. <br/> |
|**6** <br/> | Cada gráfico tiene un eje X (horizontal) y un eje Y (vertical). <br/>  En el gráfico de actividad **Actividad**, el eje Y es el número total de sesiones de MI, audio, vídeo, uso compartido de aplicaciones y transferencia de archivos que han realizado sus usuarios en su organización.  <br/>  En el gráfico de actividad **Usuarios**, el eje Y es el número total de usuarios que han realizado sesiones de MI, audio, vídeo, uso compartido de aplicaciones y transferencia de archivos.  <br/>  En el gráfico de actividad **Minutos**, el eje Y es el número total de minutos que han pasado los usuarios de su organización en sesiones de punto a punto de audio y vídeo.  <br/>  En ambos gráficos, el eje X es el intervalo de fechas seleccionado para este informe específico. <br/> |
|**7** <br/> |Puede filtrar las series que aparecen en el gráfico haciendo clic en un elemento de la leyenda. Por ejemplo, en el gráfico **Actividad**, haga clic o pulse en **MI**, **Audio**, **Vídeo**, **Uso compartido de aplicaciones** y **Transferencia de archivos** para ver solo la información relacionada con cada uno de los elementos. Cambiar esta selección no cambia la información en la tabla de cuadrícula. <br/> |
|**8** <br/> | La tabla muestra un desglose de todas las actividades de punto a punto por usuario. Se muestran todos los usuarios que tienen Skype Empresarial asignado y sus actividades de punto a punto. Puede agregar columnas a la tabla. <br/> **Nombre de usuario** es el nombre del usuario. <br/> **Eliminado** indica que se ha quitado la licencia del usuario. <br/> > [!NOTE]>  La actividad de un usuario eliminado seguirá mostrándose en un informe siempre que el usuario tuviera la licencia en cualquier momento durante el período de tiempo seleccionado. La columna **Eliminado** ayuda a ver que el usuario ya no está activo, pero que ha contribuido a los datos del informe.          **Fecha de eliminación** es la fecha en que se quitó la licencia del usuario. <br/> **Fecha de última actividad (UTC)** es la fecha de última actividad (UTC) del usuario. <br/> **MI** muestra el número total de sesiones de punto a punto que ha utilizado el usuario. <br/> **Audio** muestra el número total de sesiones de punto a punto en las que se ha utilizado audio. <br/> **Vídeo** muestra el número total de sesiones de punto a punto en las que se ha utilizado vídeo. <br/> **Uso compartido de aplicaciones** muestra el número total de sesiones de punto a punto de uso compartido de aplicaciones. <br/> **Transferencias de archivos** muestra el total de sesiones de punto a punto de transferencia de archivos. <br/> **Minutos de audio** muestra el número total de minutos de audio que se han usado en la organización. <br/> **Minutos de audio** muestra el número total de minutos de audio que se han usado en la organización. <br/>  Si las directivas de la organización le impiden ver los informes en los que la información del usuario es identificable, puede cambiar la configuración de privacidad de todos estos informes. Consulte la sección **Cómo ocultar los detalles del nivel de usuario** en [Informes de actividades en el Centro de administración de Office 365](http://technet.microsoft.com/library/0d6dfb17-8582-4172-a9a9-aed798150263%28Office.14%29.aspx).  <br/> |
|**9** <br/> |También puede exportar los datos del informe a un archivo .csv de Excel haciendo clic o pulsando o tocando en **Exportar**.           <br/> ![Skype for Business Reporting Export Button.](images/de7e2ab7-d70c-422f-a0ec-178b10f7dd51.png)De esta forma se exportan los datos de todos los usuarios, a los que puede aplicar orden y filtros simples para realizar más análisis. Si tiene menos de 2000 usuarios, puede ordenar y filtrar dentro de la tabla en el mismo informe. Si tiene más de 2000 usuarios, para ordenar y filtrar tendrá que exportar los datos.  <br/> |
|**10** <br/> |![Skype for Business Online Reporting Manage Button.](images/4c8f5387-cebb-4d6c-b7d3-05c954a2c234.png)Haga clic o toque pulse en **Columnas** para agregar o quitar columnas de un informe.           <br/> |
   

## ¿Desea ver otros informes de Skype Empresarial?


-  [Informe de actividad de Skype Empresarial](skype-for-business-activity-report.md) Puede ver cuánto los usuarios utilizan punto a punto, organizada y participó en sesiones de conferencia.
    
  
-  [Informe de clientes usados de Skype Empresarial](skype-for-business-clients-used-report.md) Puede para ver los dispositivos incluidos sistemas operativos basados en Windows y dispositivos móviles que tienen el Skype empresarial instalan y utilizan para mensajería instantánea y reuniones.
    
  
-  [Informe de actividad de organizador de conferencias de Skype Empresarial](skype-for-business-conference-organizer-activity-report.md) Puede ver cuánto los usuarios están organizar conferencias que utilizan mensajería instantánea, audio y vídeo, uso compartido de Web, marcado o fuera de las partes - 3 º y marcado-o fuera de Microsoft.
    
  
-  [Informe de actividad de participantes de conferencias de Skype Empresarial](skype-for-business-conference-participant-activity-report.md) Puede ver cuántas mensajería instantánea, audio o vídeo, compartir aplicaciones, Web y y conferencias de conferencias de acceso telefónico o fuera son que se ha participado en.
    
  
-  [Informe de usuarios bloqueados de Skype Empresarial](skype-for-business-blocked-users-report.md) Puede ver los usuarios de su organización que se ha bloqueado de realizar llamadas de RTC.
    
  
-  [Informe de uso de RTC de Skype Empresarial](skype-for-business-pstn-usage-report.md) Puede ver el número de minutos de llamadas entrantes y salientes y el costo para estas llamadas.
    
  
-  [Informe de usuarios bloqueados de Skype Empresarial](skype-for-business-blocked-users-report.md) Puede ver los detalles sobre el tipo de medio que se usa, la duración de la sesión, el cliente que utiliza y la dirección URL de la conferencia.
    
  

## 
<a name="MT_Footer"> </a>


> [!NOTE]
> **Declinación de responsabilidades de traducción automática**: Este artículo se ha traducido con un sistema informático sin intervención humana. Microsoft ofrece estas traducciones automáticas para que los hablantes de otros idiomas distintos del inglés puedan disfrutar del contenido sobre los productos, los servicios y las tecnologías de Microsoft. Puesto que este artículo se ha traducido con traducción automática, es posible que contenga errores de vocabulario, sintaxis o gramática. 
  
    
    


## See also
<a name="MT_Footer"> </a>


#### 


  
    
    
 [Informes de actividades en el Centro de administración de Office 365](http://technet.microsoft.com/library/0d6dfb17-8582-4172-a9a9-aed798150263%28Office.14%29.aspx)
