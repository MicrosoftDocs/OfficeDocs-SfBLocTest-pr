---
title: The user's Skype for Business Online service plan isn't valid
ms.author: TONYSMIT
author: TONYSMIT
manager: scotv
ms.date: 5/4/2015
ms.audience: Admin
ms.topic: Troubleshooting
f1_keywords: ms.lync.lac.ServicePlanNotValid
description: See where to assign a valid service plan for a user after a Skype for Business Online service plan isn't valid error. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: 3631967e-d342-4a8a-905d-9b65d2ab554b
---


# The user's Skype for Business Online service plan isn't valid

Sorry, the Skype Empresarial Onlineservice plan assigned to this user is not recognized, or is invalid. 
  
    
    


Go to the **Office 365 admin center** > **Users and groups** and assign a valid service plan to this user.
  
    
    


