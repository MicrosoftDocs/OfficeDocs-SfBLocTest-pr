---
title: Try or purchase Audio Conferencing in Office 365
ms.author: tonysmit
author: tonysmit
ms.date: 9/28/2017
ms.audience: Admin
f1_keywords: ms.lync.lac.CpcGettingStarted
description: See how to try or purchase Audio Conferencing (PSTN conferencing) licenses for Office 365 to set up conference calls that people can dial in to. 
ms.technology:
- Microsoft Teams
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
ms.set-free-tag: Strat_SB_PSTN
ms.assetid: d080bb8c-3465-47bb-ad2b-9428f1a3fd24
---


# Try or purchase Audio Conferencing in Office 365

Sometimes people in your organization will need to use a phone to call into a meeting. Skype Empresarial and Microsoft Teams include the Audio Conferencing feature for just this situation! People can call into Skype Empresarial and Microsoft Teams meetings using a phone, instead of using the Skype Empresarial or Microsoft Teams app on a mobile device or PC. 
  
    
    


You only need to set up audio conferencing for people who plan to schedule or lead meetings. Meeting attendees who call in to the meeting don't need any licenses assigned to them and don't need other setup. 
  
    
    


Looking for pricing info, see  [Pricing for Audio Conferencing](https://products.office.com/en-us/skype-for-business/pstn-conferencing#requirements).
  
    
    



  
    
    


## Step 1: Buy and assign Audio Conferencing licenses

You must be an  [Acerca de los roles de administrador de Office 365](http://technet.microsoft.com/library/da585eea-f576-4f55-a1e0-87090b6aaa9d%28Office.14%29.aspx) to perform these steps.
  
    
    

### To buy and assign user Audio Conferencing licenses:


1. Find out if **Audio Conferencing** available in your country/region. [Países o regiones que se pueden llamar a los planes y las conferencias de Audio](countries-regions-that-are-supported-for-audio-conferencing-and-calling-plans.md). 
    
  
2. Get your ** Audio Conferencing** licenses. If you want to:
    
  - **Try it** before you buy it, you can sign up for an Office 365 Enterprise E5 free trial that includes Audio Conferencing. See [Office 365 Enterprise E5 Trial](https://portal.office.com/Signup?OfferId=101bde18-5ffb-4d79-a47b-f5b2c62525b3).
    
  
  - **Buy it**, see [Skype para Business y Microsoft Teams licencias de complemento](skype-for-business-and-microsoft-teams-add-on-licensing.md).
    
  
3.  [Asignar o cancelar licencia para Office 365 para empresas](http://technet.microsoft.com/library/997596b5-4173-4627-b915-36abac6786dc%28Office.14%29.aspx) you purchased to the people in your organization who are going to schedule or lead meetings.
    
  
4. If you purchased audio conferencing add-on licenses and Communications Credits licenses, assign them, too. For instructions, see  [Asignar Skype para Business y Microsoft Teams licencias](assign-skype-for-business-and-microsoft-teams-licenses.md).
    
  

### To buy and assign pay-per-minute Audio Conferencing licenses:

If you're a Volume and Licensing customer, you can get pay-per-minute Audio Conferencing licenses. For additional information on pay-per-minute Audio Conferencing licenses, see  [Audio conferencia pago por minuto](audio-conferencing-pay-per-minute.md). 
  
    
    

1. Find out if **Audio Conferencing** available in your country/region. [Países o regiones que se pueden llamar a los planes y las conferencias de Audio](countries-regions-that-are-supported-for-audio-conferencing-and-calling-plans.md). 
    
  
2. Get your **Audio Conferencing** licenses. To acquire pay-per-minute licenses please reach out to your account representative.
    
  
3.  [Configurar comunicaciones créditos para su organización](set-up-communications-credits-for-your-organization.md) for your organization. To set up Communications Credits, see [¿Qué son créditos de comunicaciones?](what-are-communications-credits.md)
    
    > [!IMPORTANT]
      > If Communication Credits hasn't been set up, Audio Conferencing won't work for any users with pay-per-minute licenses. 
4.  [Asignar o cancelar licencia para Office 365 para empresas](http://technet.microsoft.com/library/997596b5-4173-4627-b915-36abac6786dc%28Office.14%29.aspx) you purchased to the people in your organization who are going to schedule or lead meetings.
    
    > [!NOTE]
      > If you have Audio Conferencing pay-per-minute licenses, you don't have to assign Communications Credits licenses separately to each user specifically for Audio Conferencing usage (you might still need to assign them for other services). 

## Step 2: Set the audio conferencing provider for people who lead or schedule meetings

When you assign an **Audio Conferencing** license to people in your organization who lead or schedule meetings, they are all set up and ready to go! (You don't have to set their audio conferencing provider.) But if you have users that have been using a third-party audio conferencing provider (ACP), you will need to [Moving a user's audio conferencing provider to Microsoft](moving-a-user-s-audio-conferencing-provider-to-microsoft.md).
  
    
    

## Step 3: Other admin tasks

The following steps are **optional**, but a lot of admins like to do them:
  
    
    

1.  [Customize meeting invitations](customize-meeting-invitations.md) . The dial-in numbers that are set for the user will be automatically added to the meeting invitations that are sent to attendees. However, you can add your own help and legal links, a text message, and small company graphic.
    
  
2.  [Establecer los números de teléfono de conferencias de Audio para organizadores que se incluyen en invitaciones](set-the-audio-conferencing-phone-numbers-for-meeting-organizers-that-are-include.md) . This is the phone number that will show up in the meeting that is scheduled by a user.
    
  
3.  [Establecer idiomas del operador automático para conferencias de Audio](set-auto-attendant-languages-for-audio-conferencing.md) that the audio conferencing auto attendant uses to greet a caller when they dial into a audio conferencing phone number. This step only applies if you're using Microsoft as your audio conferencing provider.
    
  
4.  [Establecer la longitud del PIN para las reuniones de acceso telefónico local](set-the-length-of-the-pin-for-audio-conferencing-meetings.md) .
    
  

## 


> [!NOTE]
> This feature is not yet available to customers using Office 365 operated by 21Vianet in China. To learn more, see  [Learn about Office 365 operated by 21Vianet](http://technet.microsoft.com/library/A8AB5061-3346-4DA0-BB7C-5260822B53AE%28Office.14%29.aspx). 
  
    
    


## See also


#### 


  
    
    
 [Configurar Skype Empresarial Online](set-up-skype-for-business-online.md)
  
    
    
 [Números de teléfono para las conferencias de Audio](phone-numbers-for-audio-conferencing.md)
  
    
    
 [Establecer opciones para reuniones en línea y llamadas de conferencia](http://technet.microsoft.com/library/DCD1CA39-0C1F-466C-9573-F04138FEF5E2%28Office.14%29.aspx)
