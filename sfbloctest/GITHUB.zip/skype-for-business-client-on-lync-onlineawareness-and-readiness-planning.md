---
title: Cliente de Skype Empresarial en Lync Online conciencia y preparación para la planificación
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 12/30/2016
ms.audience: Admin
ms.topic: Planning
ms.service: OFFICE365
description: Learn tips and ways to plan adoption of Skype for Business for organizations that are currently using the Lync Online. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: a97c2110-13d0-4855-bae1-85c30b01affb
---


# Cliente de Skype Empresarial en Lync Online: conciencia y preparación para la planificación

El cliente de Skype Empresarial está inspirado en la apariencia de Skype pero proporciona el mismo nivel de seguridad y control que el cliente de Lync. Esta nueva interfaz de usuario es una actualización para el cliente de Lync 2013 existente que estará disponible en una actualización mensual para aquellos clientes con Office 2013 Pro Plus.
  
    
    


Cuando el cliente de Skype Empresarial se inicia es imprescindible cubrir dos elementos clave para realizar correctamente una transición y adopción de la nueva interfaz de usuario: conciencia y preparación. La mayor parte de esta transición es concienciar de que la nueva experiencia del cliente se instalará en los escritorios de los usuarios y proporcionar un número de recursos de preparación para ayudarle a realizar una transición sin problemas al nuevo Skype Empresarial. Para obtener un poco más información sobre el cliente, consulte  [Lync Online se está convirtiendo en Skype Empresarial ](http://go.microsoft.com/fwlink/?LinkId=528320).
  
    
    


A medida que nos acerquemos al lanzamiento de Skype Empresarial, seguiremos agregando recursos adicionales para ayudarle a que su organización esté preparada para la transición.
  
    
    


Aquí se encuentran algunos aspectos a considerar sobre cómo desarrollará su plan de adopción e implementación. Aquí se muestran algunas preguntas que quizás quiera preguntar:
  
    
    


- ¿Confiamos en que Office 365 proporcione actualizaciones a mi organización?
    
  
- ¿Cuánto tiempo llevará preparar a las personas del departamento de soporte técnico para que ayuden a los usuarios?
    
  
- ¿Necesita actualizar los sitios internos o los recursos para ayudar a los usuarios?
    
  

## Planes de comunicación sugeridos para su organización

Es importante que prepare a los usuarios de su organización para **la conversión de Lync a Skype Empresarial**. Verá este cambio en el lanzamiento de abril de la actualización de Office que comienza el 14/4/2015.
  
    
    

- Dos semanas antes (alrededor del 30/3/2015) del lanzamiento del nuevo cliente de Skype Empresarial, envíe un correo electrónico a los usuarios de que **Lync está cambiando a Skype Empresarial**.
    
  
- Cinco días antes (alrededor del 9/4/2015) de que implemente el nuevo cliente de Skype Empresarial, envíe un correo electrónico a sus usuarios de que **Lync está cambiando a Skype Empresarial**.
    
  
- Cuando el nuevo cliente de Skype Empresarial se lance el 14/4/2015, envíe un correo electrónico a sus usuarios de que el nuevo cliente de **Skype Empresarial se ha lanzado** y ellos empezarán a ver los cambios en un par de semanas.
    
  

## Recursos para la adopción del nuevo cliente

Para ayudarle con la adopción de los usuarios, estos son algunos de los recursos que proporcionaremos:
  
    
    

- Esto es lo que denominamos nuestra "Primera vista de Windows". Esto contiene recursos que incluyen una introducción rápida a la nueva interfaz de usuario de Skype Empresarial y a las características que se ejecutan en la primera instalación del cliente para un usuario. 
    
  
- Hay vídeos para el usuario final. Estos vídeos contendrán una introducción y un vídeo de Novedades para ayudar a los usuarios sobre lo que esperan de estos cambios.
    
  
- Habrá plantillas de correo electrónico que obtendrá. Estos serán correos electrónicos de muestra que puede usar para proporcionarles a los usuarios de su organización para que conozcan los cambios que se van a producir.
    
  

## Recursos para la preparación de los usuarios de su organización


-  [Tarjetas de referencia rápida para sus usuarios](http://go.microsoft.com/fwlink/?LinkId=529154)
    
  
-  [Plantillas de correo electrónico de muestra](http://go.microsoft.com/fwlink/?LinkId=529159)
    
  
-  [Descubrir Skype Empresarial](http://go.microsoft.com/fwlink/p/?LinkId=528686)
    
  
-  [Recursos de preparación y concienciación del cliente de Skype Empresarial](http://go.microsoft.com/fwlink/?LinkId=529159)
    
  

## See also


#### 


  
    
    
 [Skype Empresarial: Haga que lo increíble suceda ](http://aka.ms/Skype4Bamazing )
  
    
    
 [Skype Empresarial: Novedades de clientes ]( http://aka.ms/Skype4Bwhatsnew)
  
    
    
 [Skype Empresarial: Tutorial para nuevos usuarios ](http://aka.ms/Skype4Bsteps )
  
    
    
 [Skype Empresarial: Introducción rápida ](http://aka.ms/Skype4Bintro )
