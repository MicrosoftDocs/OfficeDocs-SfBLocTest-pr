---
title: Features managed by your Office 365 provider
ms.author: TONYSMIT
author: TONYSMIT
manager: scotv
ms.date: 5/4/2015
ms.audience: Admin
ms.topic: Reference
f1_keywords: ms.lync.lac.ProviderManagedFeature
description: Learn how to get admin help for Office 365 for Business and Skype to reset your password, improve call and video quality, install Skype for business and more. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: 3ac5774c-bb08-4c0a-9c43-b5a10605f640
---


# Features managed by your Office 365 provider

If you purchased Office 365 from one of Microsoft's partners, rather than directly from Microsoft, your provider manages the following feature:
  
    
    


- **Skype para teléfono** Lets Skype Empresarial Online users make calls to, or receive calls from, any phone number.
    
  

For details, contact your Office 365 provider.
  
    
    


