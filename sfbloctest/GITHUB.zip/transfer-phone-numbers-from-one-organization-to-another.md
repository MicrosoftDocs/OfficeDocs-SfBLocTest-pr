---
title: Transfer phone numbers from one organization to another
ms.author: tonysmit
author: tonysmit
ms.date: 8/23/2017
ms.assetid: 2d04abd1-31aa-4e7d-8894-cc78abd389c4
---


# Transfer phone numbers from one organization to another

Intro text here.
  
    
    


## First level heading

text here
  
    
    

### Second level heading

text here
  
    
    

