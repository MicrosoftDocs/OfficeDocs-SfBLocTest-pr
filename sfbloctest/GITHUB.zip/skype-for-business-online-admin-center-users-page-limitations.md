---
title: Skype for Business Online admin center users page limitations
ms.author: TONYSMIT
author: TONYSMIT
manager: scotv
ms.date: 12/9/2015
ms.audience: Admin
ms.topic: Reference
f1_keywords: ms.lync.lac.UsersCountLimitationWarning
description: Learn how to work within the limitations of Skype for Business Online admin's display of users. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: 0a24c1d1-11e3-4971-a90d-4c3e69ef165f
---


# Skype for Business Online admin center users page limitations

For performance reasons the **Centro de administración de Skype Empresarial**displays the first 1,000 users in your user list. If you have more than 1,000 users, use **Filter**![Filtrar](images/d360528a-a05a-4f0d-a7fd-25a6c696206a.png) and **Search**![Búsqueda](images/5cc29d50-4eec-48a4-bdad-bbeae230f9ae.png) to find the specific people you're looking for.
  
    
    


## Bulk editing
<a name="__top"> </a>


1. Select the first 1,000 usersor everyone returned by your filter or searchby checking the box next to **Display name** at the top of the list.
    
  
2. Click **Edit**![Editar](images/2f8948c1-e4f3-4022-b9cd-37fed066056e.png).
    
  
You can change the number of users shown on each page with the control at the bottom of the list:
  
    
    
![Navegación por la página Usuarios para cambiar la cantidad de usuarios que se muestran en ella](images/7d8ba24e-e3e8-4ff8-92f7-98ac143aab6d.png)
  
    
    

  
    
    

