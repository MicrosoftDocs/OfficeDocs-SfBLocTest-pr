---
title: Iniciar una audioconferencia por teléfono sin un PIN
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 9/25/2017
ms.audience: Admin
ms.topic: How To
ms.service: OFFICE365
description: Learn how to enable or disable anonymous callers from joining a meeting from the Skype for Business admin center or using a PowerShell script. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Microsoft Teams
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag:
- Adm_O365_FullSet
- Strat_SB_PSTN
ms.assetid: d5b1f775-d7ed-4d30-853a-1d49f81e8fde
---


# Iniciar una audioconferencia por teléfono sin un PIN

> [!IMPORTANT]
> Este artículo se ha traducido con traducción automática; vea la  [declinación de responsabilidades](d5b1f775-d7ed-4d30-853a-1d49f81e8fde.md#MT_Footer). Para su referencia, puede encontrar la versión en inglés de este artículo  [aquí](https://support.office.com/en-us/article/d5b1f775-d7ed-4d30-853a-1d49f81e8fde). 
  
    
    


Puede ser frustrante para los usuarios que llaman a una reunión para guardarlo en la sala de espera de la reunión escuchar música porque la Skype para empresas o Microsoft Teams organizador de la reunión no ha iniciado la reunión.
  
    
    


Si un organizador de la reunión llama a la reunión, de manera predeterminada, se requerirá un PIN para iniciarla. Pero puede cambiar la configuración para que cualquier usuario pueda entrar en la reunión y para que no sea necesario un PIN para iniciarla. También puede establecer esto cuando un único usuario o cuando todos los usuarios de acceso telefónico local de su organización pueden iniciar reuniones sin un PIN. Puede usar el Centro de administración de Skype Empresarial para habilitar o deshabilitar este parámetro para un solo usuario.
  
    
    


Un PIN no es necesario para el organizador de la reunión si alguien ha empezado a la reunión desde un Skype para empresas o Microsoft Teams la aplicación. Un PIN solo es necesario cuando el organizador de la reunión unan a la reunión a través de un teléfono. El PIN para las reuniones se envía al usuario acceso telefónico cuando se asigna la licencia de **Conferencias de Audio** y están habilitados para conferencias de audio. Ver, [Enviar un correo electrónico a un usuario con su información sobre la conferencia de acceso telefónico local](send-an-email-to-a-user-with-their-audio-conferencing-information.md) y [Mensajes de correo electrónico que se envían automáticamente a los usuarios cuando cambie su configuración de conferencias de Audio](emails-that-are-automatically-sent-to-users-when-their-audio-conferencing-settin.md).
  
    
    


## Habilitar o deshabilitar la posibilidad de que los autores de llamada anónimos se unan a la reunión


1. Inicie sesión en Office 365 con su cuenta profesional o educativa.
    
  
2. Vaya a **Centro de administración de Office 365** > **Skype Empresarial**.
    
  
3. En la **Centro de administración de Skype Empresarial**, en el panel de navegación izquierdo, vaya a las **conferencias de Audio** > **usuarios de acceso telefónico**.
    
  
4. Seleccione un usuario de la lista y, en el panel de acciones, haga clic en **Editar**.
    
  
5. En la página de propiedades del usuario, en **Opciones de reunión**, active o desactive la casilla **Permitir que los autores de llamada no autenticados sean los primeros asistentes de una reunión. Si esto no se permite, permanecerán en la sala de espera hasta que se una un usuario autenticado**.
    
  
6. Haga clic en **Guardar**.
    
  
 **Para habilitar o deshabilitar a las personas que llaman anónimas a todas las reuniones del usuario con Windows Powershell**
  
    
    

- Ejecute lo siguiente: 
    
  ```
  Set-CsOnlineDialInConferencingTenantSetting -AllowPSTNOnlyMeetingsByDefault $true | $false
  ```


## ¿Qué más debe saber?


- Si desea restablecer el PIN, consulte  [Restablecer el PIN de conferencia de acceso telefónico local de un usuario](reset-the-audio-conferencing-pin-for-a-user.md).
    
  
- Si se ha habilitado el acceso anónimo o la posibilidad de iniciar la reunión sin un PIN:
    
  - Si no se ha iniciado la reunión (hay nadie de la reunión todavía): una llamada le preguntará si es el organizador, si dice que sí, le pedirá su PIN después entradas el PIN, comenzará la reunión y el usuario se une a una reunión.
    
  
  - Si la reunión ya ha iniciado (otra persona ya está en la reunión): no se solicita un llamador si es el organizador y nunca se pedirá el PIN, ya se ha iniciado la reunión, unirá a la persona que llama.
    
  
- Si se deshabilita el acceso anónimo o no requieren un PIN iniciar una reunión:
    
  - Si no se ha iniciado la reunión (hay nadie de la reunión todavía): no se solicita un llamador si es el organizador y nunca se pedirá el PIN. Dado que la configuración del organizador se establece en desactivado, comenzará la reunión y las personas que llaman anónimas se une a una reunión.
    
  
  - Si la reunión ya ha iniciado (otra persona ya está en la reunión): no se solicita un llamador si es el organizador y nunca se pedirá el PIN, ya se ha iniciado la reunión, unirá a la persona que llama.
    
  

## ¿Desea saber cómo administrar con Windows PowerShell?


- Para ahorrar tiempo o automatizar este proceso para varios usuarios, puede usar el cmdlet  [Set-CsOnlineDialInConferencingUser](https://go.microsoft.com/fwlink/?LinkId=617688 ) .
    
  

- Cuando se trata de Windows PowerShell, Skype Empresarial Online se centra en la administración de usuarios y en determinar qué pueden o no hacer los usuarios. Con Windows PowerShell, puede administrar Office UNRESOLVED_TOKEN_VAL(365) con un único punto de administración que puede simplificar el trabajo diario cuando tiene varias tareas que realizar. Para empezar a usar Windows PowerShell, vea estos temas:
    
  -  [Seis razones por las podría desear usar Windows PowerShell para administrar Office 365 ](https://go.microsoft.com/fwlink/?LinkId=525041)
    
  
  -  [Mejores formas de administrar Office 365 con Windows PowerShell](https://go.microsoft.com/fwlink/?LinkId=525142)
    
  
- Windows PowerShell cuenta con muchas ventajas en velocidad, simplicidad y productividad en comparación con solo usar el centro de administración de Office 365, como cuando realiza cambios de configuración para muchos usuarios a la vez. Más información sobre estas ventajas en los temas siguientes:
    
  -  [Una introducción a Windows PowerShell y Skype Empresarial Online](https://go.microsoft.com/fwlink/?LinkId=525039)
    
     [Usar Windows PowerShell para administrar Skype Empresarial Online](https://go.microsoft.com/fwlink/?LinkId=525453)
    
  
  -  [Usar Windows PowerShell para realizar tareas de administración comunes de Skype Empresarial Online](https://go.microsoft.com/fwlink/?LinkId=525038)
    
  

    > [!NOTE]
      > El módulo Windows PowerShell para Skype Empresarial Online le permite crear una sesión de Windows PowerShell remota que se conecta con Skype Empresarial Online. Este módulo, que solo es compatible con equipos de 64 bits, se puede descargar desde el Centro de descarga de Microsoft en  [Módulo de Windows PowerShell para Skype Empresarial Online.](https://go.microsoft.com/fwlink/?LinkId=294688)

## 
<a name="MT_Footer"> </a>


> [!NOTE]
> **Declinación de responsabilidades de traducción automática**: Este artículo se ha traducido con un sistema informático sin intervención humana. Microsoft ofrece estas traducciones automáticas para que los hablantes de otros idiomas distintos del inglés puedan disfrutar del contenido sobre los productos, los servicios y las tecnologías de Microsoft. Puesto que este artículo se ha traducido con traducción automática, es posible que contenga errores de vocabulario, sintaxis o gramática. 
  
    
    


