---
title: Usar audioconferencia dinámicos identificadores de su organización
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 9/25/2017
ms.audience: Admin
ms.service: OFFICE365
ms.collection: Adm_Skype4B_Online
ms.technology:
- Microsoft Teams
- Office 365
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag:
- Adm_O365_FullSet
- Strat_SB_PSTN
ms.assetid: e55e4bff-fb67-4389-8695-f03024baa9b6
---


# Usar audioconferencia dinámicos identificadores de su organización

> [!IMPORTANT]
> Este artículo se ha traducido con traducción automática; vea la  [declinación de responsabilidades](e55e4bff-fb67-4389-8695-f03024baa9b6.md#MT_Footer). Para su referencia, puede encontrar la versión en inglés de este artículo  [aquí](https://support.office.com/en-us/article/e55e4bff-fb67-4389-8695-f03024baa9b6). 
  
    
    


Se está actualizando el servicio de conferencia de Audio para proporcionar cada Skype para reuniones de negocios y Microsoft Teams identificadores de conferencia diferente. Identificadores de conferencia dinámicos son una mejora significativa sobre identificadores de conferencia estático ya que proporcionan:
  
    
    


- **Seguridad mejorada** Los identificadores de conferencia son únicos para cada Skype para empresas o Microsoft Teams reunión y generan cuando programada de la reunión.
    
  
- **Una mejor experiencia para todo tipo de reuniones** Las reuniones de un único organizador reciben una información específica de acceso telefónico local para evitar que los participantes por teléfono de la reunión se mezclen con los participantes de otra cuando se programan una detrás de otra.
    
  
- **Una transición constante** Cuando a su organización se le habilita un identificador de conferencia dinámico, todas las reuniones que ya se hayan programado con un identificador estático de conferencia seguirán funcionando.
    
  

> [!TIP]
> Identificadores dinámicos solo están disponibles para los usuarios que están habilitados para ** Conferencias de Audio** y ha establecido Microsoft como su proveedor de servicios de audioconferencia. Puede [Asignar Microsoft como proveedor de conferencias de audio](assign-microsoft-as-the-audio-conferencing-provider.md) para sus usuarios.
  
    
    


## ¿Qué cambios verán los usuarios en mi organización?

Después de conferencia dinámico que identificadores se han habilitado para su organización, cualquier nueva Skype para empresas o Microsoft Teams reunión programada por usuarios de su organización que están habilitados para conferencias de Audio, tendrá identificadores de conferencia que serán diferentes de el identificador de conferencia estático que tenían antes. Para los organizadores que tuvieron identificadores de conferencia estática antes, que necesitan para recordar a los usuarios unirse a sus reuniones que ahora debe usar un nuevo identificador de conferencia en la invitación de la reunión antes de que puedan unirse a ella.
  
    
    

> [!NOTE]
> Las reuniones que haya programado un usuario con identificadores de conferencia estáticos, antes de que su organización estuviera habilitada para utilizar identificadores de conferencia dinámicos, seguirán teniendo los identificadores de conferencia estáticos para que puedan seguir programándose reuniones sin problema. 
  
    
    

Estos ejemplos muestra la nueva experiencia para dos Skype para reuniones que han sido clasificados por el mismo usuario pero ambas ahora tendrá dos identificadores de conferencia diferente:
  
    
    
La **reunión 1** se ha programado de 9:00 a 10:00 y su id. de conferencia es 93907123:
  
    
    

  
    
    

  
    
    
![First Dynamic Conference ID.](images/997b2473-7645-46df-9774-95eb070c2239.png)
  
    
    
El mismo usuario ha programado la **reunión 2** de 10:00 a 11:00 y su id. de conferencia es 16353789:
  
    
    

  
    
    
![Second Dynamic Conference IDs](images/e1eecc76-812b-426c-90e8-80e9f6f4ad31.png)
  
    
    

  
    
    

  
    
    

## Temas relacionados


-  [Configurar Skype Empresarial Online](set-up-skype-for-business-online.md)
    
  
-  [Set up Audio Conferencing for Skype for Business and Microsoft Teams](set-up-audio-conferencing-for-skype-for-business-and-microsoft-teams.md)
    
  
-  [Skype para Business y Microsoft Teams licencias de complemento](skype-for-business-and-microsoft-teams-add-on-licensing.md)
    
  

## 
<a name="MT_Footer"> </a>


> [!NOTE]
> **Declinación de responsabilidades de traducción automática**: Este artículo se ha traducido con un sistema informático sin intervención humana. Microsoft ofrece estas traducciones automáticas para que los hablantes de otros idiomas distintos del inglés puedan disfrutar del contenido sobre los productos, los servicios y las tecnologías de Microsoft. Puesto que este artículo se ha traducido con traducción automática, es posible que contenga errores de vocabulario, sintaxis o gramática. 
  
    
    


