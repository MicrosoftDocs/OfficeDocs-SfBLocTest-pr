---
title: Establecer el PIN para transferir los números de teléfono a un nuevo proveedor de servicios
ms.author: tonysmit
author: tonysmit
ms.date: 9/25/2017
ms.technology:
- Microsoft Teams
- Office 365 Germany – Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
ms.set-free-tag: Strat_SB_PSTN
ms.assetid: f1defa5b-e49c-4d8c-a5f8-3f736201af5e
---


# Establecer el PIN para transferir los números de teléfono a un nuevo proveedor de servicios

> [!IMPORTANT]
> Este artículo se ha traducido con traducción automática; vea la  [declinación de responsabilidades](f1defa5b-e49c-4d8c-a5f8-3f736201af5e.md#MT_Footer). Para su referencia, puede encontrar la versión en inglés de este artículo  [aquí](https://support.office.com/en-us/article/f1defa5b-e49c-4d8c-a5f8-3f736201af5e). 
  
    
    


Para transferir o  *puerto de los*  números de teléfono de Skype empresarial Online a otro proveedor de servicio de teléfono o carrier, deberá definir manualmente un PIN. Después de configurar el PIN, debe incluirlo en la solicitud de un número de teléfono con el puerto. No es el mismo que el **PIN de soporte técnico** de Office 365 que se usa para autenticar al llamar a soporte. La compatibilidad con el PIN es un código generado dinámicamente introduzca el PIN de soporte técnico en nuestro sistema telefónico automatizado, pero no se usa en Skype empresarial Online. Si está buscando su PIN de soporte técnico, vaya [Get your support PIN](http://technet.microsoft.com/library/cb0d3ad7-da00-4b71-96a2-5a1902f144aa%28Office.14%29.aspx).
  
    
    


> [!IMPORTANT]
> Solo se utiliza un puerto el PIN para las organizaciones de los Estados Unidos 
  
    
    


Puede ver  [Números de teléfono de transferencia a Office 365](transfer-phone-numbers-to-office-365.md) para obtener más información sobre cómo transferir y trasladar números de teléfono de entrada y salida.
  
    
    


Aquí encontrará información específica sobre este PIN debe conocer:
  
    
    


- Si no se ha configurado un PIN, no podrá al puerto números de teléfono o la transferencia de Skype empresarial Online.
    
  
- Puede contener 6 a 10 dígitos (números).
    
  
- No puede contener letras o caracteres especiales.
    
  
- El PIN predeterminado está en blanco, pero si se insertan en, no puede quitar o establecer en blanco.
    
  
- Puede actualizar o cambiar el PIN después de especificar uno.
    
  

## Configurar el PIN


1. Inicie sesión en Office 365 con su cuenta profesional o educativa.
    
  
2. Vaya al **Centro de administración de Office 365** > **centros de administración** > **Skype Empresarial**.
    
  
3. En el panel de navegación izquierdo, **voz** > **pedidos de puerto**.
    
  
4. Haga clic en **configurar y administrar el PIN** que se usa para la transferencia o trasladar números a otro operador de servicio.
    
  
5. En el panel de **administrar su puerto el PIN**, introduzca el PIN y haga clic en **Guardar**.
    
  

## 
<a name="MT_Footer"> </a>


> [!NOTE]
> **Declinación de responsabilidades de traducción automática**: Este artículo se ha traducido con un sistema informático sin intervención humana. Microsoft ofrece estas traducciones automáticas para que los hablantes de otros idiomas distintos del inglés puedan disfrutar del contenido sobre los productos, los servicios y las tecnologías de Microsoft. Puesto que este artículo se ha traducido con traducción automática, es posible que contenga errores de vocabulario, sintaxis o gramática. 
  
    
    


## See also
<a name="MT_Footer"> </a>


#### 


  
    
    
 [Términos y condiciones de las llamadas de emergencias](emergency-calling-terms-and-conditions.md)
  
    
    
 [Audio Conferencing complimentary dial-out period](audio-conferencing-complimentary-dial-out-period.md)
