---
title: ¿Cuáles son los operadores automáticos de sistema telefónico?
ms.author: tonysmit
author: tonysmit
ms.date: 9/25/2017
description: Learn what Phone System (Cloud PBX) auto attendents are and how to use them. 
ms.technology:
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
ms.set-free-tag: Strat_SB_PSTN
ms.assetid: ab9f05a2-22cb-4692-a585-27f82d1b37c7
---


# ¿Cuáles son los operadores automáticos de sistema telefónico?

> [!IMPORTANT]
> Este artículo se ha traducido con traducción automática; vea la  [declinación de responsabilidades](ab9f05a2-22cb-4692-a585-27f82d1b37c7.md#MT_Footer). Para su referencia, puede encontrar la versión en inglés de este artículo  [aquí](https://support.office.com/en-us/article/ab9f05a2-22cb-4692-a585-27f82d1b37c7). 
  
    
    


Sistema telefónico en Office 365 los operadores automáticos de pueden usarse para crear un sistema de menús para su organización que le permite externas e internas de las personas que llaman desplazarse por el sistema de menús para localizar y coloque o transferir llamadas a los usuarios de la compañía o los departamentos de su organización.
  
    
    


Cuando llama personas, se presentan con una serie de mensajes de voz que les ayudan a realizar una llamada a un usuario o buscar a alguien de su organización y, a continuación, realizar una llamada a ese usuario. Un operador automático es una serie de mensajes de voz o y archivo de audio que las personas que llaman escuchar en lugar de un operador cuando llaman a una organización. Un operador automático permite a las personas que llaman desplazarse por el sistema de menús, realizar llamadas, o buscar usuarios con un teclado del teléfono (DTMF) o usando el reconocimiento de voz de entradas de voz. Para configurar un operador automático para el sistema telefónico en Office 365, vaya  [Configurar un operador automático de sistema telefónico](set-up-a-phone-system-auto-attendant.md).
  
    
    


Un operador automático de sistema telefónico tiene las siguientes características:
  
    
    


- Puede transmitir saludos corporativos o informativos.
    
  
- Puede proporcionar menús corporativos personalizados. Estos menús se pueden personalizar para que tengan más de un nivel.
    
  
- Ofrece la capacidad de búsqueda en directorios, de modo que los autores de llamadas pueden buscar un nombre en el directorio de la organización.
    
  
- Permite que el autor de una llamada se ponga en contacto con una persona de su organización o le deje un mensaje.
    
  

Para configurar un sistema telefónico automático operador, vaya  [Configurar un operador automático de sistema telefónico](set-up-a-phone-system-auto-attendant.md).
  
    
    


## Introducción

Para comenzar a utilizar operadores automáticos, es importante recordar que:
  
    
    

- Licencia Enterprise E5 o una licencia Enterprise E3 plus **Sistema telefónico**, debe tener su organización (como mínimo). El número de licencias de usuario de **Sistema de teléfono** asignados desventajas el número del servicio de números que está disponible para usarse con operadores automáticos. Los números de los operadores automáticos que puede tener depende de las licencias de **Sistema telefónico** y **Conferencias de Audio de** número que se asignan en su organización. Para obtener más información sobre licencias, vaya [Skype para Business y Microsoft Teams licencias de complemento](skype-for-business-and-microsoft-teams-add-on-licensing.md).
    
    > [!TIP]
      > Para desviar llamadas a un operador o una opción de menú que es un usuario en línea con una licencia de **Sistema telefónico**, necesitará habilitarlos para telefonía IP empresarial o asignarles llamar a los planes. Vea  [Asignar Skype para Business y Microsoft Teams licencias](assign-skype-for-business-and-microsoft-teams-licenses.md). También puede usar Windows PowerShell. Ejecutar por ejemplo:  `Set-CsUser -identity "Amos Marble" -EnterpriseVoiceEnabled $true`
- Para obtener y utilizar números de servicio gratuito para los operadores automáticos, debe configurar créditos de comunicaciones. Para ello, consulte  [¿Qué son créditos de comunicaciones?](what-are-communications-credits.md) y [Configurar comunicaciones créditos para su organización](set-up-communications-credits-for-your-organization.md).
    
    > [!IMPORTANT]
      > Los números de teléfono de usuario (suscriptor) no se pueden asignar a los operadores automáticos; solo se pueden usar números de teléfono de servicio de pago y gratuitos. 

## Información general sobre las características


### Marcado por nombre

Marcado por nombre es una característica de un operador automático que se conoce como la búsqueda en el directorio. Permite que las personas que llaman a su operador automático para usar voz (reconocimiento de voz) o el teclado del teléfono (DTMF) para escribir un nombre completo o parcial para buscar el directorio de la empresa, busque a la persona y, a continuación, tener transferir la llamada a ellos. Si dispone de Skype empresarial los usuarios, **no se necesitan tener un número de teléfono o llamar a los planes han asignado, pero deben tener una licencia de **Sistema telefónico**** para que sean accesibles cuando busquen con acceso telefónico por su nombre. Marcado por nombre incluso podrá encontrar y transferir llamadas a Skype empresarial los usuarios alojados en diferentes países o regiones para organizaciones multinacionales.
  
    
    

> [!CAUTION]
> Los usuarios de las implementaciones locales de Skype Empresarial 2015 o de Lync Server 2013 y 2010 no aparecerán en el directorio cuando los busquen. 
  
    
    


### Tamaño máximo de directorio

No hay ningún límite en el tamaño de Active Directory de marcado por nombre es compatible cuando se usa el teclado del teléfono para buscar para introducir nombres completos o parciales (nombre apellidos y también Apellidos + Nombre). Sin embargo, el tamaño máximo de una lista de nombre de que un operador automático solo puede admitir usando el reconocimiento de nombre con voz es 80.000 usuarios.
  
    
    

||||
|:-----|:-----|:-----|
|**Tipo de entrada** <br/> |**Formato de búsqueda** <br/> |**Número máximo de usuarios en una organización** <br/> |
|DTMF (entrada con teclado)  <br/> |Parcial  <br/> Nombre + Apellidos  <br/> Apellidos + Nombre  <br/> |Sin límite  <br/> |
|Voz (entrada de voz)  <br/> |Nombre  <br/> Apellidos  <br/> Nombre + Apellidos  <br/> Apellidos + Nombre  <br/> |80.000 usuarios  <br/> |
   

> [!NOTE]
> Si está utilizando marcado por nombre con el reconocimiento de voz, pero es mayor de 80.000 usuarios de Active Directory de su organización y que no ha limitado el ámbito de acceso telefónico por nombre mediante acceso telefónico ámbito característica, acceso telefónico por nombre seguirán funcionando para las llamadas con un teclado numérico de teléfono y las entradas de voz estará disponibles para todos los demás casos. Puede usar la característica de ámbito de acceso telefónico para restringir los nombres que se puede llegar al cambiar el ámbito de acceso telefónico por nombre para un operador automático determinado. 
  
    
    


### Marcado por nombre: entrada mediante teclado (DTMF)

Los autores de llamadas pueden usar Marcado por nombre para contactar con usuarios especificando el nombre completo o parcial de la persona con la que quieren hablar. Un aspecto especialmente positivo de esta característica es que se pueden usar diferentes formatos para introducir el nombre.
  
    
    
Para realizar búsquedas en el directorio de su organización, los usuarios pueden usar la tecla 0 (cero) para indicar un espacio entre el nombre y el apellidos, o viceversa. Al introducir el nombre, se les pedirá que finalicen la entrada mediante teclado con la tecla # (almohadilla). Por ejemplo, "Después de introducir el nombre de la persona que busca, pulse #". Si se encuentran varios nombres, se proporcionará una lista de nombres al autor de la llamada para que seleccione uno.
  
    
    
Las personas pueden realizar búsquedas por nombre en su organización empleando los siguientes formatos de búsqueda con el teclado del teléfono:
  
    
    

|||||
|:-----|:-----|:-----|:-----|
|**Formato de nombre** <br/> |**Tipo de búsqueda** <br/> |**Ejemplo** <br/> |**Resultado de búsqueda** <br/> |
|Nombre + Apellidos  <br/> |Completo  <br/> |Amos0Marble#  <br/> |Amos Marble  <br/> |
|Apellidos + Nombre  <br/> |Completo  <br/> |Marble0Amos#  <br/> |Amos Marble  <br/> |
|Nombre  <br/> |Completo  <br/> |Amos#  <br/> |Pulse 1 para Amos Marble  <br/> Pulse 2 para Amos Marcus  <br/> |
|Apellidos  <br/> |Completo  <br/> |Marble#  <br/> |Pulse 1 para Amos Marble  <br/> Pulse 2 para Mary Marble  <br/> |
|Nombre o Apellidos  <br/> |Parcial  <br/> |Mar#  <br/> |Pulse 1 para Mary Marble  <br/> Pulse 2 para Mary Jones  <br/> Pulse 3 para Amos Marcus  <br/> |
|Nombre + Apellidos  <br/> |Parcial  <br/> |Mar0Amos#  <br/> |Pulse 1 para Amos Marble  <br/> Pulse 2 para Amos Marcus  <br/> |
|Apellidos + Nombre  <br/> |Parcial  <br/> |Mar0Am#  <br/> |Pulse 1 para Amos Marble  <br/> Pulse 2 para Amos Marcus  <br/> |
   
En las búsquedas de personas a través del teclado del teléfono se pueden utilizar diferentes caracteres especiales. Por ejemplo, el usuario deberá pulsar la tecla de almohadilla (#) y quizás necesite también la tecla de cero (0), que se utiliza para señalar espacios entre nombres. Al pulsar la tecla de asterisco (*) se repetirá la lista de nombres coincidentes.
  
    
    

|||
|:-----|:-----|
|**Carácter especial del teclado del teléfono** <br/> |**Significado** <br/> |
|# (almohadilla)  <br/> |Carácter de fin al introducir un nombre.  <br/> |
|0 (cero)  <br/> |Espacio entre nombres.  <br/> |
|* (asterisco)  <br/> |Repetir la lista de nombres coincidentes.  <br/> |
   

### Marcado por nombre: reconocimiento de nombres por voz

Los autores de llamadas pueden buscar a personas en su organización usando su voz (reconocimiento de voz). Pueden buscar a cualquier persona en el Active Directory de la empresa con solo decir su nombre. En la búsqueda por voz se pueden reconocer nombres en diferentes formatos, como nombre, apellidos, nombre + apellidos o apellidos + nombre de la persona con la que se quiere contactar.
  
    
    
Si activa el reconocimiento de voz en un operador automático, la entrada mediante teclado del teléfono (DTMF) no se desactivará, sino que estarán disponibles los dos tipos de entrada. La entrada mediante teclado del teléfono no se puede desactivar y siempre se puede usar, aunque esté activado el reconocimiento de voz en el operador automático.
  
    
    
Al igual que sucede con la entrada mediante el teclado del teléfono, si se encuentran varios nombres, se proporcionará una lista de nombres al autor de la llamada para que seleccione uno.
  
    
    
Los autores de llamadas pueden decir los nombres en los siguientes formatos:
  
    
    

|||||
|:-----|:-----|:-----|:-----|
|**Nombre por voz** <br/> |**Tipo de búsqueda** <br/> |**Ejemplo** <br/> |**Resultado de búsqueda** <br/> |
|Nombre + Apellidos  <br/> |Completo  <br/> |Amos Marble  <br/> |Amos Marble  <br/> |
|Apellidos + Nombre  <br/> |Completo  <br/> |Marble Amos  <br/> |Amos Marble  <br/> |
|Nombre  <br/> |Completo  <br/> |Amos  <br/> |Pulse o diga 1 para Amos Marble  <br/> Pulse o diga 2 para Amos Jones  <br/> |
|Apellidos  <br/> |Completo  <br/> |Marble  <br/> |Pulse o diga 1 para Amos Marble  <br/> Pulse o diga 2 para Ben Marble  <br/> |
   

> [!NOTE]
> Puede tardar hasta 36 horas para que su nombre aparezca en el directorio cuando alguien utiliza marcado por nombre con el reconocimiento de voz de un usuario nuevo. 
  
    
    


### Compatibilidad con idiomas

La característica de texto a voz está disponible en los siguientes idiomas:
  
    
    

||||
|:-----|:-----|:-----|
|Árabe (EG)  <br/> |Inglés (NZ)  <br/> |Coreano (KO)  <br/> |
|Chino (HK)  <br/> |Inglés (Reino Unido)  <br/> |Noruego (NO)  <br/> |
|Chino (TW)  <br/> |Inglés (Estados Unidos)  <br/> |Polaco (PL)  <br/> |
|Chino (ZH)  <br/> |Finés (FI)  <br/> |Portugués (BR)  <br/> |
|Danés (DA)  <br/> |Francés (CA)  <br/> |Portugués (PT)  <br/> |
|Neerlandés (NL)  <br/> |Francés (FR)  <br/> |Ruso (RU)  <br/> |
|Inglés (AU)  <br/> |Alemán (DE)  <br/> |Español (ES)  <br/> |
|Inglés (CA)  <br/> |Italiano (IT)  <br/> |Español (MX)  <br/> |
|Inglés (IN)  <br/> |Japonés (JP)  <br/> |Sueco (SV)  <br/> |
   
El reconocimiento de voz para operadores automáticos está disponible en los siguientes idiomas:
  
    
    

|||
|:-----|:-----|
|Chino (ZH)  <br/> |Francés (FR)  <br/> |
|Inglés (AU)  <br/> |Alemán (DE)  <br/> |
|Inglés (CA)  <br/> |Italiano (IT)  <br/> |
|Inglés (IN)  <br/> |Japonés (JP)  <br/> |
|Inglés (Reino Unido)  <br/> |Portugués (BR)  <br/> |
|Inglés (Estados Unidos)  <br/> |Español (ES)  <br/> |
|Francés (CA)  <br/> |Español (MX)  <br/> |
   
Los siguientes comandos de voz están disponibles en los catorce (14﻿) idiomas admitidos para el reconocimiento de voz:
  
    
    

|||
|:-----|:-----|
|**Comando de voz** <br/> |**Significado** <br/> |
|Sí  <br/> |Sí (equivale a pulsar 1 para Sí).  <br/> |
|No  <br/> |No (equivale a pulsar 2 para No).  <br/> |
|Repetir  <br/> |Repite la lista de opciones (equivale a pulsar * para repetir la lista de opciones).  <br/> |
|Operador  <br/> |Salida al operador (equivale a pulsar 0 para "Operador").  <br/> |
|Menú principal  <br/> |Lleva al autor de la llamada al menú principal del operador automático.  <br/> |
|Cero  <br/> |Equivale a pulsar 0 (de forma predeterminada, igual que "Operador").  <br/> |
|Uno  <br/> |Equivale a pulsar 1.  <br/> |
|Dos  <br/> |Equivale a pulsar 2.  <br/> |
|Tres  <br/> |Equivale a pulsar 3.  <br/> |
|Cuatro  <br/> |Equivale a pulsar 4.  <br/> |
|Cinco  <br/> |Equivale a pulsar 5.  <br/> |
|Seis  <br/> |Equivale a pulsar 6.  <br/> |
|Siete  <br/> |Equivale a pulsar 7.  <br/> |
|Ocho  <br/> |Equivale a pulsar 8.  <br/> |
|Nueve  <br/> |Equivale a pulsar 9.  <br/> |
   

### Usar la opción de operador

Usar un operador en relación con un operador automático es una configuración opcional que ofrece la posibilidad a los autores de llamadas de hablar con una persona real.
  
    
    
De forma predeterminada, la tecla 0 y el comando de voz "Operador" (en todos los idiomas admitidos para el reconocimiento de voz) están asignados al operador.
  
    
    

> [!NOTE]
> Puede cambiar la tecla asignada a la opción **Operador** en **Opciones de menú**. 
  
    
    

Puede elegir entre las siguientes opciones para designar un operador:
  
    
    

- Skype de un usuario que tiene una licencia de **Sistema telefónico** que está habilitada para telefonía IP empresarial o que tenga planes de llamada que se les ha asignado. Puede configurarlo para que la persona que llama se pueden enviar al correo de voz. Para ello, seleccione una **persona de su empresa** y establezca las llamadas automáticamente se desvíen directamente al correo de voz de la persona.
    
    > [!NOTE]
      > Los usuarios locales que utilicen Skype Empresarial Server 2015 o Lync Server 2013 y 2010 no pueden ser operadores. 
- Otro operador automático configurado para su organización.
    
  
- Cualquier cola de llamadas que tenga su organización. Para obtener más información sobre las colas de llamadas, consulte  [Crear una cola de llamada del sistema telefónico](create-a-phone-system-call-queue.md).
    
  

### Horario laboral y administración de llamadas

Para los operadores automáticos es necesario definir el horario laboral correspondiente. Si este horario no está definido, se considerará que todos los días y todas las horas del día pertenecen al horario laboral, dado que el horario ininterrumpido es la opción configurada de forma predeterminada. Puede establecer horarios laborales partidos, de modo que todas las horas que no estén configuradas como horario laboral, se considerarán no laborales. Puede configurar diferentes opciones de administración de llamadas entrantes y diferentes mensajes de saludo (esta característica es opcional), tanto para el horario laboral como para el no laboral.
  
    
    
Los operadores automáticos tienen opciones de administración de llamadas que se pueden configurar:
  
    
    

- Puede hacer que la llamada se desconecte después del mensaje de saludo.
    
  
- También puede:
    
  - Desviar la llamada a un Skype empresarial Online usuario que tiene una licencia de **Sistema telefónico** está habilitada para telefonía IP empresarial o llamar a los planes tiene asignados. Puede configurarlo para que la persona que llama se pueden enviar al correo de voz. Para ello, seleccione una **persona de su empresa** y establezca las llamadas automáticamente se desvíen directamente al correo de voz de la persona.
    
    > [!NOTE]
      > Los usuarios locales que utilicen Skype Empresarial Server 2015, Lync Server 2013 y 2010 no son compatibles. 
  - Redirigir la llamada a una cola de llamadas. Para obtener más información sobre las colas de llamadas, consulte  [Crear una cola de llamada del sistema telefónico](create-a-phone-system-call-queue.md).
    
  
  - Redirigir la llamada a otro operador automático que haya configurado.
    
  
- Crear opciones de menú y reproducir un mensaje con instrucciones para el autor de la llamada. Por ejemplo: "Pulse 1 para Ventas, pulse 2 para Servicios. Para hablar con el operador, pulse 0 en cualquier momento".
    
  

### Opciones de menú

Operadores automáticos de sistema de teléfono le permiten crear indicaciones de menú ("Presione 1 para ventas, presione 2 para los servicios de") y configurar las opciones de menú para dirigir las llamadas en función de lo que el usuario selecciona. Configurar las opciones de menú para un operador automático permite a una organización que proporcione una guía interactiva para obtener a la persona a su destino más rápido, sin confiar en un operador controle las llamadas entrantes. Menú indicaciones pueden crearse con la característica texto a voz (indicaciones generadas por el sistema) o cargar un archivo de audio que se ha registrado. Reconocimiento de voz utiliza comandos de voz para la navegación de manos libres, pero personas que llaman también pueden usar el teclado del teléfono para desplazarse por los menús.
  
    
    
Las teclas del 0 al 9 se pueden asignar a las **opciones del menú** de un operador automático a través del Centro de administración de Skype Empresarial. Pueden crear conjuntos de opciones de menú diferentes para el horario laboral y el no laboral, y puede activar o desactivar Marcado por nombre en las **opciones del menú**. Se pueden asignar las teclas para transferir las llamadas a:
  
    
    

- Un operador, que tiene asignada la tecla 0 de forma predeterminada. Sin embargo, se puede reasignar a cualquier otra tecla o quitar el operador del menú.
    
  
- Una cola de la llamada.
    
  
- Otro operador automático. Puede establecer menús multinivel haciendo que una **opción del menú** de un operador automático señale a otro operador automático con sus propias opciones de menú (conocido como operador automático "anidado").
    
  
- Un Skype empresarial Online usuario que tiene una licencia de **Sistema telefónico** que está habilitada para telefonía IP empresarial o llamar a los planes asignados... Puede configurarlo para que la persona que llama se pueden enviar al correo de voz. Para ello, seleccione una **persona de su empresa** y establezca llamadas de la persona que reenvíe automáticamente directamente al correo de voz.
    
    > [!NOTE]
      > Los usuarios locales que utilicen Skype Empresarial Server 2015, Lync Server 2013 y 2010 no se pueden usar en **Opciones de menú**. 
El nombre de cada opción del menú recibe una palabra clave de reconocimiento de voz, si se ha activado esta característica. Por ejemplo, el autor de la llamada puede decir "Uno" para seleccionar la opción de menú asignada a la tecla 1, o decir simplemente "Ventas" para seleccionar la misma opción de menú, llamada "Ventas".
  
    
    
Para configurar un operador automático y las opciones de menú, vaya  [Configurar un operador automático de sistema telefónico](set-up-a-phone-system-auto-attendant.md).
  
    
    

### Obtener números de servicio para un operador automático

Antes de crear y configurar sus operadores automáticos, deberá obtener los números de servicio de pago o gratuitos, o transferir los existentes. Después de obtener los números de servicio de pago o gratuitos, estos se mostrarán en el **Centro de administración de Skype Empresarial** > **Voz** > **ficha Números de teléfono** y en el **Tipo de número** se indicará **Servicio - Número gratuito**. Para obtener los números de servicio, consulte  [Obtener números de teléfono de servicio de Skype Empresarial](getting-service-phone-numbers-for-skype-for-business-and-microsoft-teams.md) o, si desea transferir un número de servicio existente, consulte [Números de teléfono de transferencia a Office 365](transfer-phone-numbers-to-office-365.md).
  
    
    

> [!NOTE]
> Si usted se encuentra fuera de los EE. UU., no podrá usar el Centro de administración de Skype Empresarial para obtener números de servicio. En su lugar, vaya  [Manage phone numbers for your organization](manage-phone-numbers-for-your-organization.md) para ver cómo realizar esta acción desde fuera de los EE. UU.
  
    
    


## Cambiar el identificador de usuario para que sea el número de teléfono de una cola de llamada

Puede proteger la identidad de un usuario cambiando su identificador de llamada para las llamadas salientes a una cola de llamada en su lugar mediante la creación de una directiva mediante el cmdlet **New-CallingLineIdentity**.
  
    
    
Para hacer esta ejecución:
  
    
    



```
New-CsCallingLineIdentity -Identity "UKSalesQueue" -CallingIdSubstitute "Service" -ServiceNumber 14258828080 -EnableUserOverride $False -Verbose
```

A continuación, aplicar la directiva al usuario mediante el cmdlet **Grant-CallingLineIdentity**. Para hacer esta ejecución:
  
    
    



```
Grant-CsCallingLineIdentity -PolicyName UKSalesQueue -Identity "AmosMarble@contoso.com"
```

Puede obtener más información sobre cómo realizar cambios en la configuración de identificador de llamada de su organización  [Cómo se puede usar la identificación de llamadas en su organización](how-can-caller-id-be-used-in-your-organization.md).
  
    
    

## Temas relacionados

 [Aquí es lo que obtiene con el sistema telefónico en Office 365](here-s-what-you-get-with-phone-system-in-office-365.md)
  
    
    
 [Configurar planes de llamada](set-up-calling-plans.md)
  
    
    

## 
<a name="MT_Footer"> </a>


> [!NOTE]
> **Declinación de responsabilidades de traducción automática**: Este artículo se ha traducido con un sistema informático sin intervención humana. Microsoft ofrece estas traducciones automáticas para que los hablantes de otros idiomas distintos del inglés puedan disfrutar del contenido sobre los productos, los servicios y las tecnologías de Microsoft. Puesto que este artículo se ha traducido con traducción automática, es posible que contenga errores de vocabulario, sintaxis o gramática. 
  
    
    


