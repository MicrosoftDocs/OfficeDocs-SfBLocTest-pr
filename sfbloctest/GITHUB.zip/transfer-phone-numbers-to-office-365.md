---
title: Números de teléfono de transferencia a Office 365
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 11/1/2017
ms.audience: Admin
ms.topic: How To
f1_keywords: ms.lync.lac.PortingNumbersOverview
ms.service: OFFICE365
description: Learn what you need to know and do before porting phone numbers to Skype for Business, and how to create a port order to transfer them.
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag:
- Adm_O365_FullSet
- DianeF_Adm_Simplified
- LIL_Placement
- Strat_SB_PSTN
ms.assetid: 47b3af8e-4171-4dec-8333-c956f108664e
---



# Números de teléfono de transferencia a Office 365

> [!IMPORTANT]
> Este artículo se ha traducido con traducción automática; vea la  [declinación de responsabilidades](47b3af8e-4171-4dec-8333-c956f108664e.md#MT_Footer). Para su referencia, puede encontrar la versión en inglés de este artículo  [aquí](https://support.office.com/en-us/article/47b3af8e-4171-4dec-8333-c956f108664e). 
  
    
    


Es fácil transferir sus números de teléfono desde su proveedor de servicios actual a Skype Empresarial. Después de realizar la portabilidad de sus números de teléfono a Skype Empresarial, Microsoft se convertirá en su proveedor de servicios y le facturará por esos números de teléfono. 
  
    
    


## Todo lo que necesita saber antes de realizar la portabilidad de los números
<a name="bk_LNPcountries"> </a>


> [!NOTE]
> Antes de empezar, es procesar pedidos de puerto para la transferencia de números de teléfono solo en días laborables de Estados Unidos y no en los días festivos o fines de semana. 
  
    
    


### ¿Qué países y regiones permiten la portabilidad de número?

Puede trasladar o números de teléfono de transferencia en todos los países o regiones admitidos pero cómo enviar una solicitud de orden de puerto depende del país o región de dónde proceden los números de teléfono. Puede ver una lista de los países o regiones que son compatibles,  [Países o regiones que se pueden llamar a los planes y las conferencias de Audio](countries-regions-that-are-supported-for-audio-conferencing-and-calling-plans.md). Cuando realiza tareas de administración números de teléfono como transferir (trasladar) números o al obtener números de teléfono que no están disponibles en la Skype centro de administración de empresa,  [Manage phone numbers for your organization](manage-phone-numbers-for-your-organization.md).
  
    
    

### ¿Qué números se pueden transferir?

 **PUEDE TRANSFERIR:**
  
    
    
En general, puede transferir cualquier número de teléfono que sea de un proveedor compatible, como por ejemplo:
  
    
    

- Números de teléfono de líneas fijas.
    
  
- Números de teléfono del dispositivo móvil, como los que se utilizan para teléfonos móviles y tabletas, etcetera.
    
    > [!NOTE]
      > Solo es posible transferir números de teléfono móvil en EE. UU. y Puerto Rico. 
- Números de teléfono de pago.
    
  
- Números de teléfono gratuitos
    
    > [!NOTE]
      > Número de teléfono gratuito de universal internacional (UIFN) no se puede transferir a nosotros. 
- Números de teléfono de servicio, como los que se utilizan para puentes de conferencias, operadores automáticos, etcetera.
    
  
- Números de teléfono de fax, pero no se pueden usar para fax. Es necesario asignarlos a un usuario.
    
  
- Números de teléfono VoIP de un proveedor de telefonía como Vonage o RingCentral.
    
  
- Skype empresarial Hybrid números de teléfono. Si desea transferir estos números, debe  [Enviar correo electrónico que nos](ptn@microsoft.com).
    
  
 **NO PUEDE TRANSFERIR:**
  
    
    

> [!NOTE]
> Actualmente no se pueden transferir números de teléfono que no sean de un país o región admitido, incluidos los números de teléfono de un proveedor de telefonía VoIP. Para ver una lista de los países o regiones admitidos, consulte  [Países o regiones que se pueden llamar a los planes y las conferencias de Audio](countries-regions-that-are-supported-for-audio-conferencing-and-calling-plans.md)
  
    
    


- Números de teléfono usados para conexiones de datos, como números para líneas ADSL o conexiones a Internet de banda ancha.
    
  
- Los números de teléfono dedicados para fax.
    
    Si tiene números de teléfono dedicada existentes que se utilizan para enviar faxes,  *puede*  transferir estos números sobre a Skype para empresas pero el fax servicios no continuarán funcionando según lo previsto. Servicios de fax no están disponibles para los clientes de Skype Empresarial, incluso si tiene suficientes licencias para el **Sistema telefónico**, **Llamar a planear nacionales** o **Llamar a planear internacional**.
    
    Si realiza una portabilidad del número de teléfono a Skype Empresarial, puede asignar este número de teléfono a un usuario de su organización en lugar de usarlo para fax.
    
  

> [!NOTE]
> En este momento, no se admite en el Reino Unido (RU) la transferencia de números no geográficos, como los números de coste compartido para los códigos de área 0843, 0844, 0845, 0870, 0871, 0872. 
  
    
    


### ¿Qué información tendré que proporcionar?

Debe tener toda la información de cuenta para la compañía actual. La información que necesita para poner en el orden de puerto principalmente se encuentra en la factura o la factura más reciente de su proveedor actual. También deberá saber qué números que desea puerto cuyo nombre es en la cuenta y, por supuesto.
  
    
    

### ¿Qué son las transferencias de portabilidad completa y portabilidad parcial?

Cuando esté realizando la portabilidad de números de teléfono a Office 365, tiene la opción de transferir todos sus números o solo algunos de ellos.
  
    
    

- **Portabilidad completa**: es cuando transfiere todos sus números desde su proveedor de servicios actual a Skype Empresarial Online. Cuando indique los números de teléfono que quiere transferir, ** *tiene que incluir* ** el número de teléfono de facturación con el resto de los números de teléfono de su cuenta.
    
    Por ejemplo, si el número de teléfono de facturación es  *+1 425-555-1234*  y quiere realizar la portabilidad de todos los 25 números de teléfono ( *desde +1 425-555-1235 hasta 1259*  ), cuando siga las instrucciones siguientes para transferir sus números, escribiría: **+14255551234 - +14255551259**.
    
  
- **Portabilidad parcial**: es cuando solo transfiere algunos de sus números de teléfono desde su proveedor de servicios actual a Skype Empresarial Online. Si quiere transferir algunos de los números de teléfono vinculados al mismo número de teléfono de facturación, ** *no tiene que incluir* ** el número de teléfono de facturación con el resto de los números de teléfono de su cuenta.
    
    Por ejemplo, supongamos que su número de teléfono de facturación (botón) es  *+1 425-555-1234*  y desea trasladar solo 5 de los números de 25 teléfono ( *+1 425-555-1235 a través de 1259*  ). Si sigue las instrucciones siguientes para transferir sus números, debe escribir: **+1 425 555 1235-+ 1 425 555 1239**.
    
  

### ¿Puedo enviar una sola solicitud de portabilidad de número para todos mis números a la vez?
<a name="bkmk_type"> </a>

Se necesita una solicitud única por cada transportista y el tipo de número que se están trasladando.
  
    
    
Por ejemplo, debe enviar una solicitud separada de portabilidad de número para cada uno de los siguientes tipos y números: 
  
    
    

- Números de pago locales, también denominados números geográficos o de suscripción
    
  
- Números gratuitos con los códigos de área de pago como por ejemplo: 800, 844, 855, 866, 877 y 888
    
  
- Números de teléfono móvil
    
  
- Números de servicio que se pueden usar para conferencias de Audio en Office 365.
    
  
Aquí dispone de más información sobre el envío de solicitudes de portabilidad de número para cada uno de los siguientes tipos de número: 
  
    
    

- Los **números de teléfono** proporcionados por diferentes operadores requieren una solicitud de portabilidad separada para los números de cada operador.
    
  
- **Número gratuito números** con códigos de área como: 800, 844, 855, 866, 877 y 888 no se puede incluir en una solicitud de trasladar número con otros tipos de números. Para estos gratuito números de puerto, debe [Manually submit a custom service request](manually-submit-a-custom-service-request.md); no se enviaron en el centro de administración de Skype Empresarial.
    
    Es importante que use la LOA correcta para el país y el tipo de número de teléfono que desea transferir. Puede descargar las LOA  [Descargar una Carta de autorización (LOA)](download-a-letter-of-authorization-loa.md).
    
  
- **Números de teléfono móvil** requieren un código PIN para autorizar la transferencia. Por lo tanto, necesita separar solicitud trasladar número.
    
  
- Las solicitudes de portabilidad de **números de servicio** se deben enviar por separado. No se pueden enviar junto con otros tipos de números.
    
  

### ¿Cuánto tiempo se tarda en realizar la portabilidad de los números?
<a name="bkmk_type"> </a>

Una vez haya completado la solicitud de orden de puerto, tardará entre 7 a 14 días que deben procesarse. Sin embargo, dependiendo de su proveedor de servicios puede tardar hasta 30 días. Después de que los números de teléfono se pongan en puerto, recibirá un correo electrónico de nuestra que indica que está listo.
  
    
    
Puede comprobar el estado de su solicitud de portabilidad dirigiéndose al centro de administración de Skype Empresarial > **Voz** > **Solicitudes de portabilidad**. El estado de la solicitud de portabilidad se mostrará en la ventana debajo de la columna **Estado**.
  
    
    

### ¿Es posible convertir los números de teléfono de usuario (suscriptor) en números de servicio?
<a name="bkmk_type"> </a>

Sí, lo es. Solo necesita enviar una solicitud de servicio que incluya el GUID del inquilino de su organización y los números de teléfono que desea convertir. Puede hacerlo  [Manage phone numbers for your organization](manage-phone-numbers-for-your-organization.md).
  
    
    

### Errores comunes que se deben evitar
<a name="bkmk_type"> </a>

El proceso de portabilidad de números es muy sencillo. Sin embargo, la solicitud se podría complicar si surgiera un problema con el proveedor de servicios de telefonía, la solicitud estuviera incompleta y faltara información o hubiese errores tipográficos. 
  
    
    
A continuación se muestran los errores más comunes entre los clientes que han realizado la portabilidad de sus números. Evite tener que realizar una llamada a la asistencia al cliente y compruebe esos errores. 
  
    
    

- Compruebe que la información de la cuenta que proporcione coincida exactamente con la información registrada por su operador de telefonía. Los errores de coincidencia de información son la causa más común de errores y retrasos en las solicitudes de portabilidad. Compruebe lo siguiente:
    
  - El nombre autorizado es correcto.
    
  
  - La dirección es correcta.
    
  
  - El número de cuenta es correcto.
    
  
  - El número de teléfono de facturación (BTN) es correcto.
    
  
- Asegúrese de que no hay ninguna llamada avanzadas características de control, por ejemplo, captura de llamar timbre distintivo, que están habilitadas en estos números de teléfono.
    
  
- Asegúrese de que no ha realizado una nueva solicitud de servicio o desconexión con su proveedor de servicios actual.
    
  
- Compruebe que todos los números sean del mismo operador y de la misma cuenta.
    
  
- Asegúrese de que el servicio está activo. Inmovilizar la cuenta, evita que el cambio de transportistas en la cuenta. El usuario autorizado necesitará enviar un pedido a la compañía actual para quitar la inmovilización. Este proceso puede tardar semanas de 1 a 3 dependiendo de la compañía.
    
  

### ¿Puede transferir o números de puerto?
<a name="bkmk_type"> </a>

Para transferir o  *puerto de los*  números de teléfono de Skype empresarial Online a otro proveedor de servicio de teléfono o carrier, debe establecer un PIN. Después de configurar el PIN, debe incluirlo en la solicitud de un número de teléfono con el puerto. Para ver cómo configurar el PIN, vea [Establecer el PIN para transferir los números de teléfono a un nuevo proveedor de servicios](set-your-pin-for-transferring-phone-numbers-to-a-new-service-provider.md).
  
    
    

## Cómo crear una solicitud de portabilidad y transferir sus números de teléfono a Skype Empresarial
<a name="bk_LNPcountries"> </a>

Si tiene números de servicio de puentes de conferencias de acceso telefónico, operadores automáticos u otros números de servicio, números de teléfono gratuito o tiene más de 999 números de teléfono del usuario (suscriptor) que necesita transferir a Skype Empresarial, consulte  [Manually submit a custom service request](manually-submit-a-custom-service-request.md).
  
    
    
Siga estos pasos si tiene **menos de 999** números de teléfono para transferir.
  
    
    
 **Sugerencia**: en ocasiones, lleva mucho tiempo transferir los números de teléfono en grupos (lo que se conoce como portabilidad compleja, de proyecto o a granel), pero esto depende del proveedor de servicios actual. Si tiene varias solicitudes con diversos números de teléfono, abra una incidencia de soporte técnico y déjenos ayudarlo. Consulte [Manually submit a custom service request](manually-submit-a-custom-service-request.md).
  
    
    

1. Inicie sesión en Office 365 con su cuenta profesional o educativa.
    
  
2. Vaya a **Centro de administración de Office 365** > **Skype Empresarial**.
    
  
3. En el panel de navegación izquierdo, vaya a **Voz** > **Solicitudes de portabilidad** y haga clic en **Agregar**.
    
  
4. En la página **Nueva solicitud de portabilidad de número local**, lea la información y haga clic en **Empezar**.
    
  
5. En la página **Información de cuenta**, introduzca la información siguiente y luego haga clic en **Siguiente**:
    
  - **Número de cuenta** Número de cuenta del proveedor de servicios o el operador.
    
  
  - **Número de teléfono de facturación** debe estar en el formato E.164 (requiere un signo + para anteponga el número). Por ejemplo, un número de Norteamérica, utilice el formato + 1XXXYYYZZZZ.
    
  
  - **PIN para desbloquear el número** El código PIN (si es necesario para su proveedor de servicios u operador actual).
    
  
  - **Nombre de la empresa** Este es el nombre de su empresa u organización.
    
    > [!NOTE]
      > La casilla **Nombre de la compañía** sólo aceptará 25 caracteres incluyendo los espacios. Si el nombre de la compañía es superior a 25 caracteres, los primeros 25 caracteres del nombre se enviarán y la solicitud de portabilidad se seguirá procesando.
  - **Persona que autoriza** El nombre del usuario que realiza la autorización.
    
    > [!NOTE]
      > La casilla **Persona que autoriza** sólo aceptará 15 caracteres incluyendo espacios. Si el nombre de la persona que realiza la autorización es superior a 15 caracteres, los primeros 15 caracteres del nombre se enviarán y la solicitud de portabilidad se seguirá procesando.
  - **Dirección de servicio** Dirección de servicio para la cuenta. Este se enumerará en la factura de su proveedor de servicios o del operador.
    
  
  - **Ciudad**, **estado** y **código postal** de la dirección del servicio.
    
  
6. En la página de **números**, escriba los números de teléfono que desea transferir en formato E.164. Por ejemplo, un número de Norteamérica, utilice el formato + 1XXXYYYZZZZ. Separe varios números de teléfono con un punto y coma.
    
    > [!NOTE]
      > Si está realizando una portabilidad completa, tendrá que incluir el número de teléfono de facturación (BTN) del servicio en la lista. Si está realizando una portabilidad parcial, no incluya el número de teléfono de facturación (BTN) del servicio en la lista. 

    Si está realizando una portabilidad completa, seleccione **Estoy transfiriendo todos mis números desde mi operador actual**. Si está realizando una portabilidad parcial, seleccione **Solo estoy transfiriendo algunos de mis números**. Después de elegir la opción correcta, haga clic en **Comprobar portabilidad de número**.
    
  
7. Haga clic en **continuar**.
    
  
8. En la página de **fecha de transferencia**, el **día** de la lista desplegable, seleccione la fecha en la **hora de comienzo** desplegable, seleccione el tiempo (EST) y, a continuación, haga clic en **siguiente**.
    
  
9. En la página de la **carta de autorización**, active cada una de las siguientes casillas. A continuación, en el cuadro **firma**, escriba a la persona que está autorizada para realizar cambios en la cuenta. Este es el mismo nombre que se usa en la página **Información de cuenta** > **autorización de la persona**. A continuación, haga clic en **siguiente**.
    
  
10. En la página **Enviar** en **otras personas para notificar a** escriba cualquier otra dirección de correo electrónico de las personas que desee y haga clic en **orden de puerto de envío**. El orden de puerto ahora se mostrará en la página de **pedidos de puerto**. Puede ver el estado del pedido en la columna **estado**. Puede ver los detalles del pedido puerto como **ID de pedido**, **enviado**, **Transferir fecha** y **estado**. Puede ver más detalles del pedido de puerto en el panel Acción, incluido el nombre de la compañía.
    
  

## ¿Qué sucede ahora?
<a name="bk_LNPcountries"> </a>

Una vez que se haya enviado y recibido la solicitud de portabilidad, recibirá un correo electrónico verificando esta solicitud. 
  
    
    
Su pedido puerto se comprueba y actualiza diariamente y se le notificará de su progreso y el estado de correo electrónico. Si se rechaza la solicitud, le pedirá que abra una incidencia de soporte técnico y que admiten vale que le pedimos que proporcione **ID de pedido de puerto**. El orden de puerto identificador se encuentra en la Skype para el centro de administración de la empresa en **voz** > **pedidos de puerto** > columna **ID de pedido**.
  
    
    

## ¿Qué debo hacer si tengo problemas?
<a name="bk_LNPcountries"> </a>

 **La dirección del servicio no es la misma que la dirección de facturación. La información de dirección ha enviado en el orden coincide con copia de factura del cliente, ¿por qué se sigue rechazar?** La mayoría de los transportistas identificarán la información trasladar según la información de dirección del servicio, no la dirección de facturación. Puesto que una copia de la factura es un registro de facturación, no podrá proporciona la misma información como la dirección del servicio para los números de teléfono se están trasladados.
  
    
    
 **¿Qué debo hacer si mi pedido tarda demasiado tiempo en procesarse?** Queremos trasladar número para ser muy rápido y sencillo proceso. Si el pedido está tardando más de lo que piense debería y el estado aún no mostrar como completados en el centro de administración de Skype Empresarial, abra incidencia de soporte técnico e incluir el ID de puerto
  
    
    

## 
<a name="bk_LNPcountries"> </a>


||
|:-----|
|![Icono pequeño de LinkedIn Learning](images/7e5cb7c8-dc66-4c9a-a16d-a30f10a970bd.png) **¿Usa Office 365 por primera vez?**         Descubra cursos en vídeo gratuitos para **administradores de Office 365 y profesionales de TI**, ofrecidos por LinkedIn Learning. |
   

## Temas relacionados
<a name="bk_LNPcountries"> </a>

 [Configurar planes de llamada](set-up-calling-plans.md)
  
    
    

## 
<a name="MT_Footer"> </a>


> [!NOTE]
> **Declinación de responsabilidades de traducción automática**: Este artículo se ha traducido con un sistema informático sin intervención humana. Microsoft ofrece estas traducciones automáticas para que los hablantes de otros idiomas distintos del inglés puedan disfrutar del contenido sobre los productos, los servicios y las tecnologías de Microsoft. Puesto que este artículo se ha traducido con traducción automática, es posible que contenga errores de vocabulario, sintaxis o gramática. 
  
    
    

