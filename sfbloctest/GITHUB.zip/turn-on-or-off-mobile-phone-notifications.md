---
title: Activar o desactivar las notificaciones del teléfono móvil
ms.author: TONYSMIT
author: TONYSMIT
manager: scotv
ms.date: 12/30/2016
ms.audience: Admin
ms.topic: How To
f1_keywords: ms.lync.lac.OrgMobileNotification
description: Learn how to turn mobile phone notirications on or off so your users can receive alerts about incoming, voice mail, and missed instant messages. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: 2de47013-4f09-493c-abc5-372f56ad69e3
---


# Activar o desactivar las notificaciones del teléfono móvil

Como ** [Asignar roles de administrador en Office 365](http://technet.microsoft.com/library/eac4d046-1afd-4f1a-85fc-8219c79e1504%28Office.14%29.aspx)** de su organización, podrá elegir si los usuarios de Skype Empresarial recibirán alertas sobre los mensajes instantáneos entrantes y perdidos cuando estén utilizando los teléfonos móviles o las tabletas.
  
    
    


En los teléfonos Android y Windows Phone, las notificaciones de Skype Empresarial aparecen en tiempo real. En los dispositivos Windows Phone, iPhone y iPad, sin embargo, se usan las notificaciones push para mostrar alertas siempre que el usuario no esté usando activamente Skype Empresarial en el teléfono o tableta.
  
    
    


## Desactive las notificaciones de inserción en todos los dispositivos Windows Phone o Apple de su organización
<a name="__top"> </a>


1. Vaya a **Organización** > **General**.
    
  
2. En **Notificaciones de teléfono móvil**, desactive la casilla situada junto al servicio de notificación que desea desactivar y haga clic en **Guardar**.
    
  
Tenga en cuenta:
  
    
    

- Si desactiva las notificaciones de inserción, los usuarios seguirán recibiendo todas las alertas cuando vuelvan a iniciar Skype Empresarial en otro dispositivo móvil.
    
  
- Las notificaciones de inserción están activadas de forma predeterminada. Los usuarios individuales pueden desactivarlas; para ello, deben seleccionar la opción adecuada de Skype Empresarial en su dispositivo móvil.
    
  
- Si desactiva las notificaciones de inserción, los usuarios no podrán volver a activarlas.
    
  

> [!IMPORTANT]
> Microsoft usa otras empresas que proporcionan notificaciones móviles para Skype Empresarial en tiempo real para usuarios de Windows Phone, iPhone y iPad. Consulte la  [Declaración de privacidad para los productos de Skype Empresarial](http://go.microsoft.com/fwlink/p/?linkid=247732). 
  
    
    


## See also
<a name="__top"> </a>


#### 


  
    
    
 [Configurar Skype Empresarial Online](set-up-skype-for-business-online.md)
