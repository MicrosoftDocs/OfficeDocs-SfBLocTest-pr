---
title: What is address validation?
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 9/25/2017
ms.audience: Admin
ms.topic: Setup/Install
f1_keywords: ms.lync.lac.CivicAddressValidation
description: Learn what address validation is, why it's important, and how it relates to emergency addresses and services. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag:
- Adm_O365_FullSet
- Strat_SB_PSTN
ms.assetid: 64353277-9949-4cf2-ac04-6d57cce43619
---


# What is address validation?

When you set up Calling Plans in Office 365, you will need to assign a phone number and emergency address to each of your users.
  
    
    


Validating a street or civic address involves making sure that it is correct but also correctly formatted. It is possible that a partially correct emergency address such as a mistyped name of the city, may pass still pass validation. The validation process uses all parts of a given address to determine if it contains enough information to route the call to the appropriate emergency services center. If so, it will be returned as validated and then can be assigned to a phone number.
  
    
    


## See also


#### 


  
    
    
 [Configurar planes de llamada](set-up-calling-plans.md)
  
    
    
 [Términos y condiciones de las llamadas de emergencias](emergency-calling-terms-and-conditions.md)
  
    
    
 [Audio Conferencing complimentary dial-out period](audio-conferencing-complimentary-dial-out-period.md)
