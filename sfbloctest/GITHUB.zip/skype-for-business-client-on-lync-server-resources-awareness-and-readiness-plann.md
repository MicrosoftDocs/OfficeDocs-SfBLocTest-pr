---
title: Recursos de cliente de Skype Empresarial en Lync Server concienciación y planificación de la configuración
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 12/30/2016
ms.audience: Admin
ms.topic: Planning
ms.service: OFFICE365
description: Learn tips and planning strategies for Skype for Business on a Lync server. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: d7fc0d31-1ae8-4eae-a535-2aa303b0d418
---


# Recursos de cliente de Skype Empresarial en Lync Server: concienciación y planificación de la configuración

El cliente de Skype Empresarial está inspirado en la apariencia de Skype pero proporciona el mismo nivel de seguridad y control que el cliente de Lync. Esta nueva interfaz de usuario es una actualización del cliente de Lync 2013 actual, que estará disponible en una actualización mensual para aquellos clientes con Office 2013 Pro Plus. Para obtener un poco más de información sobre el cliente, consulte  [Lync Online se está convirtiendo en Skype Empresarial]() [](http://go.microsoft.com/fwlink/?LinkId=528320)
  
    
    


Cuando el cliente de Skype Empresarial se inicie, es imprescindible cubrir dos elementos clave para que la transición y la adopción de la nueva interfaz de usuario se desarrolle correctamente: concienciación y preparación. La mayor parte de esta transición consiste en concienciar de que la nueva experiencia del cliente se instalará en los escritorios de los usuarios y garantizar el éxito de este proceso, para lo que se van a proporcionar un número de recursos creados para ayudarle a que la transición a Skype Empresarial sea un proceso muy sencillo.
  
    
    


A medida que nos acerquemos al lanzamiento de Skype Empresarial, seguiremos agregando recursos para ayudarle a que su organización esté preparada para la transición.
  
    
    


Aquí se encuentran algunos aspectos a considerar sobre cómo desarrollará su plan de adopción e implementación. Aquí se muestran algunas preguntas que quizás quiera preguntar:
  
    
    


- ¿Cuál es la política de instalación de software y actualización de clientes en su organización?
    
  
- ¿Cuándo quiero hacer el cambio a Skype Empresarial?
    
  
- ¿Cuánto tiempo llevará preparar a las personas del departamento de soporte técnico para que ayuden a los usuarios?
    
  
- ¿Necesita actualizar los sitios internos o los recursos para ayudar a los usuarios?
    
  

## Planes de comunicación sugeridos para su organización


- Informe a los miembros de su organización del cambio que se está produciendo en Lync mediante un correo electrónico a todos sus usuarios dos días antes de que se realice el cambio.
    
  
-  Informe a los miembros de su organización de que Lync se llamará Skype Empresarial unos cinco (5) días antes de que se despliegue en su organización.
    
  
- Informe a los miembros de su organización de que Skype Empresarial está listo para usar.
    
  

## Recursos para la preparación de los usuarios de su organización


-  [Tarjetas de referencia rápida para sus usuarios](http://go.microsoft.com/fwlink/?LinkId=529154)
    
  
-  [Plantillas de correo electrónico de muestra](http://go.microsoft.com/fwlink/?LinkId=529159)
    
  
-  [Descubrir Skype Empresarial](http://go.microsoft.com/fwlink/p/?LinkId=528686)
    
  
-  [Recursos de preparación y concienciación del cliente de Skype Empresarial](http://go.microsoft.com/fwlink/?LinkId=529159)
    
  

## See also


#### 


  
    
    
 [Skype Empresarial: Haga que lo increíble suceda ](http://aka.ms/Skype4Bamazing )
  
    
    
 [Skype Empresarial: Novedades de clientes ]( http://aka.ms/Skype4Bwhatsnew)
  
    
    
 [Skype Empresarial: Tutorial para nuevos usuarios ](http://aka.ms/Skype4Bsteps )
  
    
    
 [Skype Empresarial: Introducción rápida ](http://aka.ms/Skype4Bintro )
