---
title: Submitting a service request for local number porting
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 6/30/2017
ms.audience: Admin
ms.topic: How To
f1_keywords: ms.lync.lac.PortOrderQuickViewPanelO365Support
description: If you have more than 999 phone numbers to transferred to Skype for Business, learn how to submit a port order service request to get them moved. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: 99e3b7e9-fd0e-48a8-88c9-3ec5561db68e
---


# Submitting a service request for local number porting

 If you have more than 999 phone numbers (for users, or service numbers including toll or toll-free) or need to transfer numbers, you need to transfer, you need to submit a port order service request to get all of these phone numbers transferred to Skype Empresarial Online.
  
    
    


You will need to first download the **Letter of Authorization (LOA)**. To download it, see [Skype for Business number porting letter of authorization](https://go.microsoft.com/fwlink/?LinkId=623745).
  
    
    


 **For complete step-by-step instructions, see  [Manually submit a custom service request](manually-submit-a-custom-service-request.md).**
  
    
    


## See also


#### 


  
    
    
 [Términos y condiciones de las llamadas de emergencias](emergency-calling-terms-and-conditions.md)
  
    
    
 [Audio Conferencing complimentary dial-out period](audio-conferencing-complimentary-dial-out-period.md)
