---
title: What's the status of my port orders?
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 6/14/2016
ms.audience: Admin
ms.topic: Setup/Install
f1_keywords: ms.lync.lac.PortOrderNoOrderHelp
description: Learn how to get the status of your port orders, and what the different actions you can take on them. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: f651e82d-4237-4e3d-ad74-40fdf11fa8d1
---


# What's the status of my port orders?

You can see the status of your port order by going to the **Skype for Business admin center** > **Voice** > **Port orders**. Each port order status will be listed in the **Status** column. If you need us to help, [Póngase en contacto con el soporte de Office 365 para empresas: ayuda para administradores](http://technet.microsoft.com/library/32a17ca7-6fa0-4870-8a8d-e25ba4ccfd4b%28Office.14%29.aspx).
  
    
    


This table shows you the status of your order and if something needs to be done (if anything), it tells you what you can do.
  
    
    



|**Status**|**Can you view the order?**|**Can you edit the order?**|**Can you cancel the order?**|**Can you delete the order?**|**Description**|
|:-----|:-----|:-----|:-----|:-----|:-----|
|**Processing** <br/> |Yes  <br/> |No  <br/> |Yes  <br/> |No  <br/> |The admin has created the order, it's been received by Microsoft.  <br/> |
|**Contacting carrier** <br/> |Yes  <br/> |No  <br/> |Yes  <br/> |No  <br/> |The order has been received and approved by Microsoft and we are working with the losing carrier to get it approved  <br/> |
|**Transfer approved** <br/> |Yes  <br/> |Firm Order Commitment(FOC)  <br/> |Yes  <br/> |No  <br/> |The order has been accepted by the losing carrier and the FOC date has been set.  <br/> |
|**Transfer pending** <br/> |Yes  <br/> |No  <br/> |No  <br/> |No  <br/> |The transfer is less than 24 hours away so the order can no longer be edited or cancelled.  <br/> |
|**Error** <br/> |No  <br/> |Yes  <br/> |Yes  <br/> |Yes (at this time, you can't delete the port order if there is an error. The port order needs to be recreated or you need to  [Póngase en contacto con el soporte de Office 365 para empresas: ayuda para administradores](http://technet.microsoft.com/library/32a17ca7-6fa0-4870-8a8d-e25ba4ccfd4b%28Office.14%29.aspx).  <br/> |The losing carrier has rejected the order.  <br/> |
|**Completed** <br/> |Yes  <br/> |No  <br/> |No  <br/> |No  <br/> |The numbers have been successfully transferred.  <br/> |
|**Cancelled** <br/> |No  <br/> |Yes  <br/> |No  <br/> |No  <br/> |The admin has canceled the order.  <br/> |
   

 **For complete step-by-step instructions, see  [Números de teléfono de transferencia a Office 365](transfer-phone-numbers-to-office-365.md).**
  
    
    


## See also


#### 


  
    
    
 [Términos y condiciones de las llamadas de emergencias](emergency-calling-terms-and-conditions.md)
  
    
    
 [Audio Conferencing complimentary dial-out period](audio-conferencing-complimentary-dial-out-period.md)
