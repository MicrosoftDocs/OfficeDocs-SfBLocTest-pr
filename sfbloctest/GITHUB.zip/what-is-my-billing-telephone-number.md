---
title: What is my billing telephone number?
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 6/14/2016
ms.audience: Admin
ms.topic: Setup/Install
f1_keywords: ms.lync.lac.PortOrderAccountInfoBTN
ms.prod: LYNC
description: Learn what your Skype for Business billing telephone number is, and where to go to get step by step instructions on how to transfer a number.
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: 63bfb6a7-7e03-4f29-8ae2-d11b92caa14d
---


# What is my billing telephone number?

The billing telephone number (BTN) is the main phone number that is included on your bill and is billed by your service provider or carrier. If you are transferring a phone number from an account that has only one phone number, you will need to put this phone number in. If you are transferring phone numbers from an account that has more than one, you can look at your bill or contact your service provider or carrier to determine what the billing telephone number is for your account.
  
    
    


 **For complete step-by-step instructions, see  [Números de teléfono de transferencia a Office 365](transfer-phone-numbers-to-office-365.md).**
  
    
    


## See also


#### 


  
    
    
 [Términos y condiciones de las llamadas de emergencias](emergency-calling-terms-and-conditions.md)
  
    
    
 [Audio Conferencing complimentary dial-out period](audio-conferencing-complimentary-dial-out-period.md)
