---
title: What should I put in for the account number?
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 6/14/2016
ms.audience: Admin
ms.topic: Setup/Install
f1_keywords: ms.lync.lac.PortOrderAccountInfoAccountNumber
ms.prod: LYNC
description: See what you should put as an account number into Skype for Business, and where you can find that. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: 7c477cc4-78e7-4a1f-ac3c-ac63151f9cf7
---


# What should I put in for the account number?

Typically, you can find the account number on any bill or invoice you have from your service provider or carrier or log on to their web site. If you still don't know the account number, you can contact your service provider or carrier to get it.
  
    
    


> [!CAUTION]
>  It's important that you make sure you don't use spaces, dashes or hyphens when entering your service provider or carrier account number.
  
    
    


 **For complete step-by-step instructions, see  [Números de teléfono de transferencia a Office 365](transfer-phone-numbers-to-office-365.md).**
  
    
    


## See also


#### 


  
    
    
 [Términos y condiciones de las llamadas de emergencias](emergency-calling-terms-and-conditions.md)
  
    
    
 [Audio Conferencing complimentary dial-out period](audio-conferencing-complimentary-dial-out-period.md)
