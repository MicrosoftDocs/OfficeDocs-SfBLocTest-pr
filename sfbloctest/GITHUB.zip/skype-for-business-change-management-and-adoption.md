---
title: Administración y adopción de cambios en Skype Empresarial
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 12/30/2016
ms.audience: Admin
ms.topic: Planning
ms.service: OFFICE365
description: Get information and tips on updating your organization from Lync client to Skype for Business. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: d8d85da6-52e7-4819-8451-45c103fb5ccb
---


# Administración y adopción de cambios en Skype Empresarial

El cliente de Skype Empresarial está inspirado en la apariencia de Skype pero proporciona el mismo nivel de seguridad y control que el cliente de Lync. Esta nueva interfaz de usuario es una actualización del cliente de Lync 2013 actual que estará disponible en una actualización mensual en abril para aquellos clientes con Office 2013 Pro Plus.
  
    
    


Cuando el cliente de Skype Empresarial se inicie, es imprescindible cubrir dos elementos clave para que la transición y la adopción de la nueva interfaz de usuario se desarrolle correctamente: concienciación y preparación. La mayor parte de esta transición consiste en concienciar de que la nueva experiencia del cliente se instalará en los escritorios de los usuarios y proporcionar un número de recursos para la preparación que ayuden a que la transición a Skype Empresarial sea un proceso muy sencillo.
  
    
    


A medida que nos acerquemos al lanzamiento del cliente de Skype Empresarial, seguiremos agregando recursos para ayudarle a que su organización esté preparada para la transición al nuevo cliente. Vuelva a consultar esta página para comprobar si hay nueva información sobre cambios o esos recursos adicionales.
  
    
    


- Planes de comunicación sugeridos para su organización.
    
  
- Plantillas de correo electrónico que puede usar para comunicar esos cambios a sus usuarios.
    
  
- Vídeos para presentar el nuevo cliente de Skype Empresarial.
    
  
- Vídeos para la formación del nuevo cliente de Skype Empresarial.
    
  
- Guías de referencia rápida para ayudarle en la transición a usted y a sus usuarios finales.
    
  
- Ayuda en línea y documentación de soporte sobre el cliente de Skype Empresarial.
    
  

 **Otros recursos**
  
    
    


-  [Recursos de cliente de Skype Empresarial en Lync Server: concienciación y planificación de la configuración](http://go.microsoft.com/fwlink/?LinkId=529147)
    
  
-  [Recursos de cliente de Skype Empresarial en Lync Online: concienciación y planificación de la configuración](http://go.microsoft.com/fwlink/?LinkId=529149)
    
  
-  [Recursos de preparación y concienciación del cliente de Skype Empresarial](http://go.microsoft.com/fwlink/?LinkId=529159)
    
  
-  [Descubrir Skype Empresarial](http://go.microsoft.com/fwlink/p/?LinkId=528686)
    
  

## See also


#### 


  
    
    
 [Skype Empresarial: Haga que lo increíble suceda ](http://aka.ms/Skype4Bamazing )
  
    
    
 [Skype Empresarial: Novedades de clientes ]( http://aka.ms/Skype4Bwhatsnew)
  
    
    
 [Skype Empresarial: Tutorial para nuevos usuarios ](http://aka.ms/Skype4Bsteps )
  
    
    
 [Skype Empresarial: Introducción rápida ](http://aka.ms/Skype4Bintro )
