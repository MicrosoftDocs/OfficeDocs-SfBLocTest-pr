---
title: ¿Cuáles son los planes de marcado?
ms.author: tonysmit
author: tonysmit
ms.date: 9/22/2017
ms.audience: Admin
f1_keywords: ms.cac.portal.dialplansoverview
description: Learn what type of dial calling plans (PSTN Calling dial plans) are available with Office 365 and how to choose one for your company.  
ms.technology:
- Communications admin center
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
ms.set-free-tag: Strat_SB_PSTN
ms.assetid: 2f0cfb59-1ca1-4e31-84ce-09d0b1a7ce1b
---


# ¿Cuáles son los planes de marcado?

> [!IMPORTANT]
> Este artículo se ha traducido con traducción automática; vea la  [declinación de responsabilidades](2f0cfb59-1ca1-4e31-84ce-09d0b1a7ce1b.md#MT_Footer). Para su referencia, puede encontrar la versión en inglés de este artículo  [aquí](https://support.office.com/en-us/article/2f0cfb59-1ca1-4e31-84ce-09d0b1a7ce1b). 
  
    
    


Un plan de marcado es un conjunto determinado de reglas de normalización que traducen los números de teléfono marcados por un usuario individual a un formato alternativo (generalmente E.164) para fines de autorización y enrutamiento de llamada.
  
    
    


Un plan de marcado consiste en una regla de normalización o varias que definen cómo los números de teléfono expresados en varios formatos se traducen a un formato alternativo. La misma línea de marcado se puede interpretar y traducir de diferentes maneras según los planes de marcado, por lo que de acuerdo con el plan de marcado asignado a un usuario determinado, el mismo número marcado se puede traducir y enrutar de manera diferente.
  
    
    


Consulte  [Crear y administrar planes de marcado](create-and-manage-dial-plans.md) para crear y administrar planes de marcado de inquilino.
  
    
    


## Alcance de un plan de marcado inquilino

El alcance de un plan de marcado determina el nivel jerárquico en el que se puede aplicar. Los alcances son diferentes a los de una implementación en el sitio de Skype Empresarial Server 2015. Los clientes obtienen el plan de marcado adecuado a través de la configuración de abastecimiento provista automáticamente cuando los usuarios se registran en Skype Empresarial Online. Como administrador, usted puede gestionar y asignar niveles de alcance del plan de marcado con PowerShell remoto.
  
    
    
En Skype empresarial Online existen dos tipos de planes de marcado: ámbito y servicio inquilino (que es para su organización) ámbito. Un plan de marcado de ámbito de servicio se define para cada país o región donde está disponible el sistema de teléfono de Office 365. Cada usuario se asigna automáticamente el plan de marcado de país de servicio que coincida con la ubicación de uso de Office 365 asignados al usuario. No puede cambiar el plan de marcado de servicio país, sin embargo, puede crear planes de marcado de inquilinos ámbito que aumentan el plan de marcado de país de servicio. Como aprovisionados clientes obtienen un "plan de marcado eficaz" que es una combinación del plan de marcado de país de servicio y el plan de marcado de inquilinos adecuadamente ámbito. Por lo tanto, no es necesario definir todas las reglas de normalización en planes de marcado de inquilinos pueden ya están en el plan de marcado de país de servicio.
  
    
    
Los planes de marcado de inquilino se pueden dividir en dos alcances: el alcance de inquilino o el alcance de usuario. Si un inquilino define y asigna un plan de marcado de alcance de usuario, ese usuario recibirá un plan de marcado efectivo del plan de marcado del país de servicio del usuario y el plan de marcado del usuario asignado. Si un inquilino define un plan de marcado de alcance de inquilino pero no asigna un plan de marcado de alcance de usuario, ese usuario recibirá un plan de marcado efectivo del plan de marcado del país de servicio del usuario y el plan de marcado de inquilino.
  
    
    
El siguiente es el modelo de herencia de los planes de marcado en Skype Empresarial Online.
  
    
    

  
    
    
![How dial plans are inherited in Skype for Business Online.](images/b2744f33-ebbd-4c23-bfba-1747312ab178.png)
  
    
    
Los siguientes son los posibles planes de marcado efectivos:
  
    
    
 **País de servicio** Si no se define un plan de marcado de alcance de inquilino y no se asigna al usuario un plan de marcado de alcance de usuario inquilino, el usuario recibirá un plan de marcado efectivo dirigido al país de servicio asociado con su Ubicación de uso de Office 365.
  
    
    
 **Inquilino mundial-País de servicio** Si se define un plan de marcado de usuario inquilino pero no se asigna a un usuario, el usuario habilitado recibirá un plan de marcado efectivo compuesto por un plan de marcado inquilino combinado y el plan de marcado del país de servicio asociado con su Ubicación de uso de Office 365.
  
    
    
 **Usuario inquilino-País de servicio** Si se define y se asigna un plan de marcado de usuario inquilino a un usuario, el usuario habilitado recibirá un plan de marcado efectivo compuesto por un plan de marcado de usuario inquilino combinado y el plan de marcado del país de servicio asociado con su Ubicación de uso de Office 365.
  
    
    
Consulte  [Crear y administrar planes de marcado](create-and-manage-dial-plans.md) para crear sus planes de marcado inquilino.
  
    
    

## Diseño de planes de marcado de inquilino

Para planificar los planes de marcado de inquilino siga estos pasos:
  
    
    

- **Paso 1** Decidir si se necesita un plan de marcado personalizado para mejorar la experiencia de marcado del usuario; generalmente, responde a la necesidad del marcado que no es E.164, como el marcado nacional abreviado o las extensiones.
    
  
- **Paso 2** Determinar si se necesita un plan de marcado de alcance de usuario inquilino o de inquilino mundial, o ambos. Los planes de marcado de alcance de usuario son necesarios y los usuarios tienen diferentes requisitos de marcado local.
    
  
- **Paso 3** Identificar una cantidad válida de patrones para cada plan de marcado necesario. Únicamente son necesarios los patrones de números que no están definidos en los planes de marcado del país de nivel de servicios.
    
  
- **Paso 4** Desarrollar un esquema a nivel de la organización para nombrar los planes de marcado. Al adoptar un esquema de denominación estándar se asegura la coherencia en una organización y se facilita el mantenimiento y las actualizaciones.
    
  
El  [Marco de operaciones de Skype](https://www.skypeoperationsframework.com/) cuenta con socios y recursos adicionales para asistirlo con la implementación de planes de marcado de inquilino.
  
    
    

## Crear su nuevo plan de marcado de inquilino

Al crear un nuevo plan de marcado, debe ingresar la información que se solicita.
  
    
    

### Nombre y nombre simple

Debe especificar un nombre descriptivo para los planes de marcado de usuario que identifique a los usuarios a los que se asignará el plan de marcado. El Nombre simple del plan de marcado se completa previamente con una línea que se deriva del nombre del plan de marcado. El campo Nombre simple se puede editar, y esto le permite crear una convención de denominación más descriptiva para sus planes de marcado. El valor Nombre simple no puede estar en blanco y debe ser único. Es una buena práctica desarrollar una convención de denominación para toda su organización y usarla de manera coherente en todos los sitios y usuarios.
  
    
    

### Descripción

Le recomendamos que escriba el nombre común y reconocible de la ubicación geográfica o el grupo de usuarios a los que se aplica el plan de marcado correspondiente.
  
    
    

### Prefijo de acceso externo


> [!CAUTION]
> El prefijo de acceso externo aún no es compatible. 
  
    
    

Puede especificar un prefijo de acceso externo de hasta 4 caracteres (#, * y 0-9) si los usuarios deben marcar un dígito adicional o más (por ejemplo, 9) para obtener una línea externa.
  
    
    

> [!NOTE]
> Si especifica un prefijo de acceso externo, no es necesario crear una regla de normalización adicional para incorporar el prefijo. 
  
    
    

Consulte  [Crear y administrar planes de marcado](create-and-manage-dial-plans.md) para crear sus planes de marcado inquilino.
  
    
    

## Reglas de normalización

Las reglas de normalización definen cómo se traducen los números expresados en varios formatos. La misma línea de número se puede interpretar y traducir de diferentes maneras, según la ubicación desde la que se marca. Las reglas de normalización pueden ser necesarias y los usuarios deben tener la capacidad de marcar números internos y externos abreviados.
  
    
    
Se debe asignar una regla de normalización o más al plan de marcado. Las reglas de normalización se hacen coincidir de arriba hacia abajo, por lo que el orden en que aparecen en un plan de marcado inquilino es importante. Por ejemplo, si un plan de marcado inquilino tiene 10 reglas de normalización, se probará la lógica de coincidencia del número marcado a partir de la primera regla de normalización, luego pasará a la segunda, y así sucesivamente. Si se produce una coincidencia, se usará esa regla y no se intentará que coincida con las otras reglas definidas. Un plan de marcado inquilino determinado puede tener un máximo de 25 reglas de normalización.
  
    
    

### Determinar las reglas de normalización necesarias

Como todo plan de marcado inquilino se combina efectivamente con un plan de marcado del país de servicio de un usuario dado, es probable que las reglas de normalización del plan de marcado del país de servicio deban ser evaluadas para determinar cuáles de ellas son necesarias por parte del plan de marcado inquilino. Se puede utilizar efectivamente el cmdlet de **Get-CsEffectiveTenantDialPlan** para este propósito. El cmdlet toma la identidad del usuario como parámetro de entrada y devolverá todas las reglas de normalización aplicables al usuario.
  
    
    

### Crear reglas de normalización

Las reglas de normalización utilizan expresiones regulares de .NET Framework para especificar los patrones de coincidencia numérica que utiliza el servidor para traducir líneas de marcado a formato E.164 para realizar la búsqueda inversa de número. Las reglas de normalización se pueden crear al especificar la expresión habitual para la coincidencia y la traducción que se debe realizar al encontrarla. Al terminar puede ingresar un número de prueba para verificar que la regla de normalización funcione según lo esperado.
  
    
    
Para tener detalles sobre el uso de expresiones regulares de .NET Framework consulte [Expresiones regulares de .NET Framework](https://go.microsoft.com/fwlink/p/?linkId=140927).
  
    
    
Consulte  [Crear y administrar planes de marcado](create-and-manage-dial-plans.md) para crear y administrar reglas de normalización para sus planes de marcado de inquilino.
  
    
    

### Reglas de normalización de muestra

La siguiente tabla muestra reglas de normalización de muestra que se escriben como expresiones regulares de .NET Framework. Las muestras son meramente ejemplos y no sirven como referencia prescriptiva para crear sus propias reglas de normalización.
  
    
    
 **Reglas de normalización utilizando las Expresiones regulares de .NET Framework**
  
    
    

||||||
|:-----|:-----|:-----|:-----|:-----|
|**Nombre de la regla** <br/> |**Descripción** <br/> |**Patrón de números** <br/> |**Traducción** <br/> |**Ejemplo** <br/> |
|Extensión4dígitos  <br/> |Traduce extensiones de 4 dígitos.  <br/> |^(\\d{4})$  <br/> |+1425555$1  <br/> |0100 se traduce a +14255550100  <br/> |
|Extensión5dígitos  <br/> |Traduce extensiones de 5 dígitos.  <br/> |^5(\\d{4})$  <br/> |+1425555$1  <br/> |50100 se traduce a +14255550100  <br/> |
|LlamadaRedmond7dígitos  <br/> |Traduce números de 7 dígitos a números locales de Redmond.  <br/> |^(\\d{7})$  <br/> |+1425$1  <br/> |5550100 se traduce a +14255550100  <br/> |
|OperadorRedmond  <br/> |Traduce 0 a Operador de Redmond.  <br/> |^0$  <br/> |+14255550100  <br/> |0 se traduce a +14255550100  <br/> |
|PrefijoSitioRedmond  <br/> |Traduce números con un prefijo de red (6) y el código de sitio de Redmond (222).  <br/> |^6222(\\d{4})$  <br/> |+1425555$1  <br/> |62220100 se traduce a +14255550100  <br/> |
|Rango5dígitos  <br/> |Traduce extensiones de 5 dígitos a partir del rango de dígitos entre 3 y 7 inclusive.  <br/> |^([3-7]\\d{4})$  <br/> |+142570$1  <br/> |54567 se traduce a +14255554567  <br/> |
|PrefijoAñadido  <br/> |Añade un prefijo de país delante de un número de 9 dígitos con restricciones en el primer y el tercer dígito.  <br/> |^([2-9]\\d\\d[2-9]\\d{6})$  <br/> |1$1  <br/> |4255554567 se traduce a 14255554567  <br/> |
|SinTraducción  <br/> |Coinciden 5 dígitos pero no hay traducción.  <br/> |^(\\d{5})$  <br/> |$1  <br/> |34567 se traduce a 34567  <br/> |
   
 **Plan de marcado de Redmond basado en las reglas de normalización que se describen anteriormente.**
  
    
    
La siguiente tabla ilustra un plan de marcado de muestra para Redmond, Washington, Estados Unidos, basado en las reglas de normalización que se muestran en la tabla anterior.
  
    
    

||
|:-----|
|**Plan de marcado de Redmond** <br/> |
|Extensión5dígitos  <br/> |
|LlamadaRedmond7dígitos  <br/> |
|PrefijoSitioRedmond  <br/> |
|OperadorRedmond  <br/> |
   

> [!NOTE]
> Los nombres de las reglas de normalización que se muestran en la tabla anterior no incluyen espacios, pero esto es opcional. Por ejemplo, el primer nombre de la tabla podría haberse escrito como "extensión de 5 dígitos" o "Extensión de 5 dígitos" y ser igualmente válido. 
  
    
    


## Temas relacionados

 [Crear y administrar planes de marcado](create-and-manage-dial-plans.md)
  
    
    

## 
<a name="MT_Footer"> </a>


> [!NOTE]
> **Declinación de responsabilidades de traducción automática**: Este artículo se ha traducido con un sistema informático sin intervención humana. Microsoft ofrece estas traducciones automáticas para que los hablantes de otros idiomas distintos del inglés puedan disfrutar del contenido sobre los productos, los servicios y las tecnologías de Microsoft. Puesto que este artículo se ha traducido con traducción automática, es posible que contenga errores de vocabulario, sintaxis o gramática. 
  
    
    


