---
title: Skype-to-phone providers
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 5/4/2015
ms.audience: Admin
ms.topic: Reference
f1_keywords: ms.lync.lac.LyncToPhoneProvider
ms.service: OFFICE365
description: Learn what Skype-to-phone providers are and get links to setting up voice messaging, access numbers, and getting providers. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: 94cc6d9e-30b1-4d1c-885a-45840ec38f9d
---


# Skype-to-phone providers

 Skype para teléfonosyndicated partners approved by Microsoft are available for organizations that can provide voice mail and auto attendant features for Skype Empresarial Online organizations.
  
    
    


## Want to know more?

Using Skype para teléfono, users can make calls to and receive calls but requires that you set up an account with either a mobile phone carrier or a public switched telephone network (PSTN) carrier, depending on your Skype Empresarial Online service plan. 
  
    
    

-  [Configurar mensajería por voz de Skype a teléfono](skype-to-phone-voice-messaging-set-up.md)
    
  
-  [Skypes-to-phone access numbers](skypes-to-phone-access-numbers.md)
    
  
-  [Skype-to-phone providers](skype-to-phone-providers.md)
    
  

