---
title: Vídeo Comunicaciones externas de Skype Empresarial Online
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 5/13/2016
ms.audience: Admin
ms.topic: How To
ms.service: OFFICE365
description: Learn to set up Skype for Business Online external communications for your users can communicate with external Skype contacts. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Lync Online
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: a4fa9dea-1de3-461c-a32a-f1bf54596c16
---


# Vídeo: Comunicaciones externas de Skype Empresarial Online

****

  
    
    

  
    
    
![Su explorador no admite vídeo. Instale Microsoft Silverlight, Adobe Flash Player o Internet Explorer 9.](images/MSN_Video_Widget.gif)
  
    
    

  
    
    

  
    
    

 **Público:** Administradores de Office 365
  
    
    


Configurar las comunicaciones externas de Skype Empresarial Online para que sus usuarios puedan comunicarse con los contactos externos de Skype Empresarial, Lync y Skype.
  
    
    


Consulte también:  [Configurar las comunicaciones externas de Skype Empresarial Online](https://support.microsoft.com/es-es/help/10041/set-up-lync-online-external-communications) (tutorial guiado)
  
    
    


