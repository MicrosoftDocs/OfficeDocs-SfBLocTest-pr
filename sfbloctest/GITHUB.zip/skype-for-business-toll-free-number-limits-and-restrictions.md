---
title: Skype para restricciones y límites de número gratuitos de empresa
ms.author: tonysmit
author: tonysmit
ms.date: 11/8/2017
ms.audience: Admin
ms.technology:
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
ms.assetid: d0b9c232-2970-41cb-adf3-df91f03347c1
---



# Skype para restricciones y límites de número gratuitos de empresa

> [!IMPORTANT]
> Este artículo se ha traducido con traducción automática; vea la  [declinación de responsabilidades](d0b9c232-2970-41cb-adf3-df91f03347c1.md#MT_Footer). Para su referencia, puede encontrar la versión en inglés de este artículo  [aquí](https://support.office.com/en-us/article/d0b9c232-2970-41cb-adf3-df91f03347c1). 
  
    
    


La tabla siguiente contiene detalles específicos, las restricciones y límites de disponibilidad de un servicio gratuito de cada país o región donde está disponible un servicio gratuito. El formato de marcación, describe los códigos de acceso necesarios dentro de cada país al acceso de acceso telefónico o el número de teléfono gratuito.
  
    
    


Estas son un par de cosas importante para recordar:
  
    
    


- Números de teléfono gratuitos sólo funcionan en cada país o región. Por ejemplo, los usuarios no podrán llamar a un número de teléfono gratuito australiano fuera de Australia.
    
  
- No se admite para adquirir o trasladar de números de teléfono gratuito Universal de internacional (UIFN).
    
  
- En muchos países o regiones, la Agencia regulador/telecomunicaciones en el país o región requiere cada número de teléfono gratuito mantener al menos de 100 minutos de uso al mes para conservar el número. En caso de que recibe un número gratuito y el uso del número no cumple estos requisitos mínimos, Microsoft puede obligación por la Agencia regulador/telecomunicaciones para recuperar al número de usted.
    
  
- Alámbricos, línea fija y acceso a la red móvil a los números de teléfono gratuitos pueden restringirse completa o parcial. El formato de marcación, describe los códigos de acceso necesarios dentro de cada país o región para realizar llamadas con el número de teléfono gratuito.
    
  
- Plan de numeración de Norteamérica números gratuitos: Tasas por minuto para el Plan de numeración de Norteamérica números gratuitos determina el país de origen. La tasa por minuto gratuita para llamadas que proceden de la asignación de Estados Unidos a la tasa definida como "Norteamérica". Sin embargo, las llamadas que proceden de otros países América del Norte como Canadá, Puerto Rico, etc. tienen índices gratuitos específicos.
    
  

## Argentina



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0800 XXX XXXX  <br/> |
|Código de país o región ISO  <br/> |AR  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sin acceso de Telmex (y filiales)  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: Se cobra el tiempo de llamada.  <br/> |
   

## Australia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |1 800 XXX XXX  <br/> |
|Código de país o región ISO  <br/> |AU  <br/> |
|Isla o territorio cubierto  <br/> |Isla Christmas, Tasmania, Islas Cocos  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: Se cobra el tiempo de llamada.  <br/> |
   

## Belarús



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |8 820 XXXX XXXX  <br/> |
|Código de país o región ISO  <br/> |BY  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso a la red móvil desde Velcom, MTS y vida  <br/> |
   

## Belice



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |1 800 XXX XXXX  <br/> |
|Código de país o región ISO  <br/> |BZ  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Móvil: Disponible con la red móvil BTL.  <br/> |
   

## Bosnia y Herzegovina



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0800 XXXXX  <br/> |
|Código de país o región ISO  <br/> |BA  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Parcial. Ver comentarios.  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Accesible desde HT Eronet/Mostar Telekom Srpske/MTEL y BHT fijado y móvil redes.  <br/> |
   

## Brasil



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 0800-891-XXXX <br/>  0800 XXX XXXX <br/> |
|Código de país o región ISO  <br/> |BR  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial, pero con tarifa Premium. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: no se cargará hora de transmisión.  <br/> |
   

## Brunéi



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |801 4XXX  <br/> |
|Código de país o región ISO  <br/> |BN  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Bulgaria



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |00800 XXX XXXX  <br/> |
|Código de país o región ISO  <br/> |BG  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil de Vivacom &amp; Globul Mobile.  <br/> |
   

## Chile



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 123 XXXX XXXX <br/>  188 LARGO Y LARGOB DE LARGO Y LARGOB 800 <br/> |
|Código de país o región ISO  <br/> |CL  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |Sin acceso en la Isla de Pascua.  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Parcial. Ver comentarios.  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |El formato de número XXX XXX 188 800 es accesible desde la red telefónica. El formato de número XXXX XXXX 123 es accesible desde la red de Entel solo. Acceso móvil es accesible para ambos formatos de número.  <br/> |
   

## China - Norte (intervalo 10 800 714 XXXX)



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |10 800 714 XXXX  <br/> |
|Código de país o región ISO  <br/> |CN  <br/> |
|Isla o territorio cubierto  <br/> |Norte de China / solo red de China Netcom  <br/> |
|Isla/territorios no incluidos  <br/> |Sur de China  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Solo de China Netcom  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |No se puede acceder desde teléfonos públicos.  <br/> |
   

## China - Sur (intervalo 10 800 140 XXXX)



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |10 800 140 XXXX  <br/> |
|Código de país o región ISO  <br/> |CN  <br/> |
|Isla o territorio cubierto  <br/> |Sur de China / solo red de China Netcom  <br/> |
|Isla/territorios no incluidos  <br/> |Norte de China  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Solo de China Telecom  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |No se puede acceder desde teléfonos públicos.  <br/> |
   

## Colombia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |01 800 XXX XXXX  <br/> |
|Código de país o región ISO  <br/> |CO  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Croacia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | LARGO Y LARGOB LARGO Y LARGOB-0800 <br/>  0800 XXXX <br/> |
|Código de país o región ISO  <br/> |HR  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: No se cobra el tiempo de llamada.  <br/> |
   

## Chipre



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |8009 - XXXX  <br/> |
|Código de país o región ISO  <br/> |CY  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |Sin acceso en las partes de Chipre ocupadas por el ejército turco.  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: No se cobra el tiempo de llamada.  <br/> |
   

## Dinamarca



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 808 8XXXX <br/>  808 2XXXX <br/>  802 5XXXX <br/> |
|Código de país o región ISO  <br/> |DK  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |Sin acceso en las Islas Feroe ni en Groenlandia.  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí. Disponible con tarifa Premium.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Ecuador



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |1-800-XXX-XXX  <br/> |
|Código de país o región ISO  <br/> |EC  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |Sin acceso de Cuenca (Etapa).  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Solo de Pacifictel.  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> | Acceso solo desde la red de Pacifictel. <br/> |
   

## Egipto



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0800-XXX-XXXX  <br/> |
|Código de país o región ISO  <br/> |EG  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Solo desde Telecom Egypt.  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Estonia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |800 XXXX (XXX)  <br/> |
|Código de país o región ISO  <br/> |EE  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí. Disponible con tarifa Premium.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Finlandia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0 800 XXX XXX  <br/> |
|Código de país o región ISO  <br/> |FI  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Francia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0 800 9XX XXX  <br/> |
|Código de país o región ISO  <br/> |FR  <br/> |
|Isla o territorio cubierto  <br/> |Francia continental y Córcega  <br/> |
|Isla/territorios no incluidos  <br/> |Sin acceso en Mónaco, Reunión, Martinica, Guadalupe, Guyana, San Pedro y Miquelón, Mayotte, Nueva Caledonia, Polinesia Francesa, Wallis y Futuna.  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: Se cobra el tiempo de llamada.  <br/> |
   

## Alemania



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0 800 XXX XXXX  <br/> |
|Código de país o región ISO  <br/> |DE  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí. Disponible con tarifa Premium.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |No se garantiza el acceso desde redes móviles en itinerancia internacionales.  <br/> |
   

## Honduras



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |800 XXXX XXXX  <br/> |
|Código de país o región ISO  <br/> |HN  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Solo de Hondutel.  <br/> |
|Disponibilidad de la red móvil  <br/> |Solo de Tigo.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Hong Kong



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |800 XXX XXX  <br/> |
|Código de país o región ISO  <br/> |HK  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: Se cobra el tiempo de llamada.  <br/> |
   

## Hungría



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 06 800 XX LARGO Y LARGOB <br/>  06 801 XX LARGO Y LARGOB <br/> |
|Código de país o región ISO  <br/> |HU  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí. Disponible con tarifa Premium.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## India



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |000 800 XXXX LARGO Y LARGOB  <br/> |
|Código de país o región ISO  <br/> |IND  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Parcial. Ver comentarios.  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Access disponible en las siguientes redes: bucle Mobile, BSNL - fijo (todas las regiones pero Bhopal), Vodafone, IDEA/SPICE (todas las regiones pero Punjab Spice), MTS India/Shyam (fija), MTNL - fijo y móvil, dependencia (todas las regiones, pero Ahmedabad, Bhopal, Bhuneswer, Jaipur, Lucknow, Meerut), TTML y TTSL (fijo y postpaid), Tata DoCoMo, HFCL Infotel/Ping Mobile, S Tel Mobile, Uninor, Videocon Mobile, Bharti/Airtel red BSNL móvil.  <br/> Access no está disponible en las siguientes redes: TTSL (prepago), Etisalat DB Telecom y Jio.  <br/> |
   

## Indonesia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 001 803 XXXX CCC <br/>  007 803 XXXX CCC <br/> |
|Código de país o región ISO  <br/> |Id.  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Se proporcionan dos formatos de número más. El formato de número formato 007 803 CCC XXXX es accesible desde la red Telkom PT, incluidos Telkomsel y XL móvil. El formato de número 001 803 XXXX CCC es accesible desde la red Indosat. Para móviles: matriz celular (prefijo 0855, 0858, 0815 y 0816) solo.  <br/> |
   

## Irlanda



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |1 800 XXX XXX  <br/> |
|Código de país o región ISO  <br/> |IE  <br/> |
|Isla o territorio cubierto  <br/> |Todas las islas costeras de la República de Irlanda tienen cobertura.  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Accesible a través de redes móviles Vodafone, O2 Digiphone, Meteor y H3G.  <br/> |
   

## Israel



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 1-80-94 X-XXXX <br/>  1-80-92 X-XXXX <br/> |
|Código de país o región ISO  <br/> |IL  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |Sin acceso en los Territorios Palestinos.  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: Sin acceso de las redes móviles Paltel y Jawal/Watania.  <br/> |
   

## Japón



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |00531 XX XXXX  <br/> |
|Código de país o región ISO  <br/> |JP  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso a las redes móviles: NTT Docomo, Au (KDD) y Softbank.  <br/> |
   

## Kenia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0 800 7XX XXX  <br/> |
|Código de país o región ISO  <br/> |KE  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Parcial. Ver comentarios.  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Fija el acceso de red: Safaricom y Airtel. Acceso a la red móvil: Safaricom, Airtel y naranja.  <br/> |
   

## Luxemburgo



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |800 2 XXXX  <br/> |
|Código de país o región ISO  <br/> |LU  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Malasia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |1 800 XXX XXX  <br/> |
|Código de país o región ISO  <br/> |MY  <br/> |
|Isla o territorio cubierto  <br/> |Malasia Peninsular y Malasia Oriental  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: Se cobra el tiempo de llamada.  <br/> |
   

## México



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 001 800 XXXX LARGO Y LARGOB <br/>  01 800 XXX XXXX <br/> |
|Código de país o región ISO  <br/> |MX  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Parcial. Ver comentarios.  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Access no garantiza de roamers internacionales.  <br/> Para el formato de número de 001 800: access para fijo - Telmex. Para el acceso móvil - Telcel solo. Hora de transmisión se cargará. Sin costo adicional si es cliente final con Telmex como su  *proveedor local y de larga distancia*  . <br/> Para el formato de número de 01-800: se cargará la hora de transmisión de acceso móvil.  <br/> |
   

## Moldova



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0 800 6XXXX  <br/> |
|Código de país o región ISO  <br/> |MD  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Mónaco



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |800 9X XXX  <br/> |
|Código de país o región ISO  <br/> |MC  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Países Bajos



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0 800 XXX XXXX  <br/> |
|Código de país o región ISO  <br/> |NL  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí. Disponible con tarifa Premium.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: Se cobra el tiempo de llamada  <br/> |
   

## Panamá



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |00-800-XXX-XXXX  <br/> |
|Código de país o región ISO  <br/> |PA  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Solo de C&amp;.  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> | El cliente debe marcar 011 (el código de larga distancia internacional de Panamá) antes del número gratuito. <br/> |
   

## Paraguay



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |009-800-101-XXX  <br/> |
|Código de país o región ISO  <br/> |PY  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Perú



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0 800 XX XXX  <br/> |
|Código de país o región ISO  <br/> |PE  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Filipinas



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> ||
|Código de país o región ISO  <br/> |PH  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Solo de PLDT.  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial, pero con tarifa Premium. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Disponible con las redes Sun Cellular y Smart Mobile.  <br/> |
   

## Polonia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |00 800 XXX XX XX  <br/> |
|Código de país o región ISO  <br/> |PL  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: Se cobra el tiempo de llamada.  <br/> |
   

## Portugal



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |800 XXX XXX  <br/> |
|Código de país o región ISO  <br/> |PT  <br/> |
|Isla o territorio cubierto  <br/> |Azores, Madeira  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí. Disponible con tarifa Premium.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Catar



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |00800 XXXXXX  <br/> |
|Código de país o región ISO  <br/> |QA  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Solo de Qtel.  <br/> |
|Disponibilidad de la red móvil  <br/> |Solo de Q-tel y Vodafone.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Rumania



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0 800 XXX XXX  <br/> |
|Código de país o región ISO  <br/> |RO  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Solo de Romtelecom.  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí. Disponible con tarifa Premium.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Arabia Saudí



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 800 XXXX 814 <br/>  800 850 XXXX <br/> |
|Código de país o región ISO  <br/> |SA  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Solo de STC.  <br/> |
|Disponibilidad de la red móvil  <br/> |Solo de STC.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Serbia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |LARGO Y LARGOB LARGO Y LARGOB-0800  <br/> |
|Código de país o región ISO  <br/> |RS  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Singapur



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |800 XXX XXXX  <br/> |
|Código de país o región ISO  <br/> |SG  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Eslovaquia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0 800 0XX XXX  <br/> |
|Código de país o región ISO  <br/> |SK  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí. Disponible con tarifa Premium.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Eslovenia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0 800 800XX  <br/> |
|Código de país o región ISO  <br/> |SI  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |ninguno  <br/> |
   

## Sudáfrica



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0 800 XXX XXX  <br/> |
|Código de país o región ISO  <br/> |ZA  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: Se cobra el tiempo de llamada.  <br/> |
   

## Corea del Sur



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 003 XXXX XXXX <br/>  00798 14 XXXX LARGO Y LARGOB <br/> |
|Código de país o región ISO  <br/> |KR  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## España



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |900 XXX XXX  <br/> |
|Código de país o región ISO  <br/> |ES  <br/> |
|Isla o territorio cubierto  <br/> |Islas Baleares e Islas Canarias  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí. Disponible con tarifa Premium.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Disponible la identificación móvil con diferentes impulsos de salida  <br/> |
   

## Suecia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 02 LARGO Y LARGOB XXXX <br/>  0200 XX XXXX <br/> |
|Código de país o región ISO  <br/> |SE  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Taiwán



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |00 801 XXX XXX  <br/> |
|Código de país o región ISO  <br/> |TW  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |ITFS:KG Telecom = NO  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Sin acceso wireline de telecomunicaciones KG. Acceso móvil: no se cargará hora de transmisión. Para el acceso móvil: acceso desde todas las redes móviles excepto Telecom KG.  <br/> |
   

## Tailandia



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 001 800 XXXX DE LARGO Y LARGOB LARGO Y LARGOB <br/>  1-800-XXX-XXX <br/> |
|Código de país o región ISO  <br/> |TH  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> | Acceso móvil: No se cobra el tiempo de llamada excepto para las redes en itinerancia, que se cobrarán como tiempo de llamada local. Para el acceso móvil: Acceso desde todas las redes móviles. <br/> |
   

## Turquía



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |00 800 XXXX XXXXX  <br/> |
|Código de país o región ISO  <br/> |TR  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí, excepto de Super Online.  <br/> |
|Disponibilidad de la red móvil  <br/> |No  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Emiratos Árabes Unidos



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 800 014 XXXX <br/>  800 017 XXXX <br/>  XX 800 LARGO Y LARGOB <br/>  800 X XXXX XXXX <br/> |
|Código de país o región ISO  <br/> |AE  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Reino Unido



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 0 800 XXX XXXX <br/>  0 808 XXXX LARGO Y LARGOB <br/> |
|Código de país o región ISO  <br/> |GB  <br/> |
|Isla o territorio cubierto  <br/> |Inglaterra, Guernsey, Isla de Man, Irlanda del Norte, Escocia, Baja California e Islas del canal  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Uruguay



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0004 019 XXXX  <br/> |
|Código de país o región ISO  <br/> |UY  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí, excepto de Claro.  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Acceso móvil: Se cobra el tiempo de llamada. Acceso móvil: Disponible desde Ancel y Movistar.  <br/> |
   

## Venezuela



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> |0 800 XXX XXXX  <br/> |
|Código de país o región ISO  <br/> |VE  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Sí  <br/> |
|Disponibilidad de la red móvil  <br/> |Sí  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |Ninguno  <br/> |
   

## Vietnam



  
    
    
> 
|||
|:-----|:-----|
|¿Número gratuito llamadas disponible?  <br/> |Sí  <br/> |
|Formatos de marcado  <br/> | 120-11-3XX <br/>  122-LARGO Y LARGOB-XX <br/>  1800 XXXX: formato ya no está disponible <br/> |
|Código de país o región ISO  <br/> |VN  <br/> |
|Isla o territorio cubierto  <br/> |No aplicable  <br/> |
|Isla/territorios no incluidos  <br/> |No aplicable  <br/> |
|Disponibilidad de línea por cable o fijo  <br/> |Parcial. Ver comentarios.  <br/> |
|Disponibilidad de la red móvil  <br/> |Parcial. Ver comentarios.  <br/> |
|Comentarios, las restricciones y problemas de acceso  <br/> |El formato de número de XX XXX 120 funcionará de Vietnam Telecom internacional (VTI) y redes móviles y fijas de VNPT (Vietnam entrada y telecomunicaciones).  <br/> > [!NOTE]> Mobifone &amp; Vinaphone forman parte de VNPT. El formato de número 122 cobertura de la red de largo y LARGOB XX: Viettel (fijo y móvil). Según el Ministerio Vietnam de telecomunicaciones, la duración máxima de llamada permitido es 2 horas.           |
   

## 
<a name="MT_Footer"> </a>


> [!NOTE]
> **Declinación de responsabilidades de traducción automática**: Este artículo se ha traducido con un sistema informático sin intervención humana. Microsoft ofrece estas traducciones automáticas para que los hablantes de otros idiomas distintos del inglés puedan disfrutar del contenido sobre los productos, los servicios y las tecnologías de Microsoft. Puesto que este artículo se ha traducido con traducción automática, es posible que contenga errores de vocabulario, sintaxis o gramática. 
  
    
    

