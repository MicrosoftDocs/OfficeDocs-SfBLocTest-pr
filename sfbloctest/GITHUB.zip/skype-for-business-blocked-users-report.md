---
title: Informe de usuarios bloqueados de Skype Empresarial
ms.author: tonysmit
author: tonysmit
ms.date: 10/24/2017
ms.audience: Admin
description: Learn about setting up Skype for Business Online domain federation with the domains you specify. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business admin center
- Skype for Business Online
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: 0ac844b2-1b08-4e5a-addf-03cde7af7a40
---


# Informe de usuarios bloqueados de Skype Empresarial

> [!IMPORTANT]
> Este artículo se ha traducido con traducción automática; vea la  [declinación de responsabilidades](0ac844b2-1b08-4e5a-addf-03cde7af7a40.md#MT_Footer). Para su referencia, puede encontrar la versión en inglés de este artículo  [aquí](https://support.office.com/en-us/article/0ac844b2-1b08-4e5a-addf-03cde7af7a40). 
  
    
    


El nuevo panel **Informes** de Office 365 muestra la información general de actividad en los productos de Office 365 de su organización. Le permite explorar los informes de nivel de cada producto para obtener datos más pormenorizados sobre las actividades dentro de cada producto. Por ejemplo, puede usar el informe **Usuarios bloqueados de Skype Empresarial** para ver los usuarios de su organización cuya capacidad para realizar llamadas de RTC se ha bloqueado. Este informe, junto con los demás informes de Skype Empresarial, le ofrece detalles sobre la actividad, entre los que se incluye el uso de RTC en toda su organización.
  
    
    


 Consulte [Informes de actividades en el Centro de administración de Office 365](http://technet.microsoft.com/library/0d6dfb17-8582-4172-a9a9-aed798150263%28Office.14%29.aspx) para ver los informes disponibles.
  
    
    


> [!NOTE]
> Podrá ver todos los informes de Skype Empresarial cuando inicie sesión como administrador en el Centro de administración de Office 365. 
  
    
    


## Cómo acceder al informe Usuarios bloqueados de Skype Empresarial


1. Vaya al Centro de administración de Office 365 > **Informes**
    
  
2. Seleccione **Informes** en el menú izquierdo y, a continuación, haga clic en **Uso**.
    
  
3. En el desplegable bajo **Seleccionar un informe**, haga clic en **Usuarios bloqueados de Skype Empresarial**.
    
     ![Blocked users widget.](images/e21e72b7-87d5-499c-bd91-51307ec8199e.snag)
  

    
    > [!IMPORTANT]
      > Según la suscripción de Office 365 que tenga, puede que no vea todos los productos ni los informes que se muestran aquí. 

## Interpretar la Skype para Business bloqueados informe de usuarios

Puede obtener una vista en de su usuario **Skype para empresas bloqueados usuario** consultando cada una de las columnas que se muestran.
  
    
    
Este es el aspecto del informe.
  
    
    

  
    
    
![Block users report.](images/3cc9009c-f24a-4bd0-b7a1-5fbb76353eaf.png)
  
    
    

  
    
    

  
    
    

|||
|:-----|:-----|
|**1** <br/> | La tabla muestra un desglose de todos los usuarios que están bloqueados y realizar llamadas. Muestra todos los usuarios que tienen el sistema telefónico en Office 365 o conferencias de Audio que se les ha asignado. Se pueden agregar o quitar columnas a la tabla. <br/> **Identificador de usuario** es el inicio de sesión del usuario. <br/> **Número de teléfono** es el número de teléfono asignado a un usuario. <br/> **Hora de la acción de bloqueo** es la hora (UTC) en que se bloqueó al usuario para que no pudiera realizar llamadas. <br/> **Acción de bloqueo** es el tipo de acción que se realizó para bloquear al usuario. <br/> **Motivo de la acción de bloqueo** es el motivo por el que se bloqueó al usuario para que no pudiera realizar llamadas. <br/> |
|**2** <br/> |Haga clic para arrastrar una columna a **Para agrupar por una columna concreta, arrastre y coloque el encabezado de columna aquí** si desea crear una vista que agrupe todos los datos de una o más columnas. <br/> |
|**3** <br/> |También puede exportar los datos del informe a un archivo .csv de Excel haciendo clic o tocando pulsando en el botón **Exportar a Excel**.  <br/> De esta forma se exportan los datos de todos los usuarios, a los que puede aplicar orden y filtros simples para realizar más análisis. Si tiene menos de 2000 usuarios, puede ordenar y filtrar dentro de la tabla en el mismo informe. Si tiene más de 2000 usuarios, para ordenar y filtrar tendrá que exportar los datos.  <br/> |
   

## ¿Desea ver otros informes de Skype Empresarial?


-  [Informe de actividad de Skype Empresarial](skype-for-business-activity-report.md) Puede ver cuánto los usuarios utilizan punto a punto, organizada y participó en sesiones de conferencia.
    
  
-  [Informe de clientes usados de Skype Empresarial](skype-for-business-clients-used-report.md) Puede para ver los dispositivos incluidos sistemas operativos basados en Windows y dispositivos móviles que tienen el Skype empresarial instalan y utilizan para mensajería instantánea y reuniones.
    
  
-  [Informe de actividad de organizador de conferencias de Skype Empresarial](skype-for-business-conference-organizer-activity-report.md) Puede ver cuánto los usuarios están organizar conferencias que utilizan mensajería instantánea, audio y vídeo, uso compartido de Web, marcado o fuera de las partes - 3 º y marcado-o fuera de Microsoft.
    
  
-  [Informe de actividad de participantes de conferencias de Skype Empresarial](skype-for-business-conference-participant-activity-report.md) Puede ver cuántas mensajería instantánea, audio o vídeo, compartir aplicaciones, Web y y conferencias de conferencias de acceso telefónico o fuera son que se ha participado en.
    
  
-  [Informe de actividad punto a punto de Skype Empresarial](skype-for-business-peer-to-peer-activity-report.md) Puede ver cuánto los usuarios utilizan mensajería instantánea, audio y vídeo, uso compartido de aplicaciones y transferencia de archivos.
    
  
-  [Informe de usuarios bloqueados de Skype Empresarial](0ac844b2-1b08-4e5a-addf-03cde7af7a40.md) Puede ver los usuarios de su organización que se ha bloqueado de realizar llamadas de RTC.
    
  
-  [Informe de uso de RTC de Skype Empresarial](skype-for-business-pstn-usage-report.md) Puede ver el número de minutos de llamadas entrantes y salientes y el costo para estas llamadas.
    
  
-  [Informe de usuarios bloqueados de Skype Empresarial](0ac844b2-1b08-4e5a-addf-03cde7af7a40.md) Puede ver los detalles sobre el tipo de medio que se usa, la duración de la sesión, el cliente que utiliza y la dirección URL de la conferencia.
    
  

## 
<a name="MT_Footer"> </a>


> [!NOTE]
> **Declinación de responsabilidades de traducción automática**: Este artículo se ha traducido con un sistema informático sin intervención humana. Microsoft ofrece estas traducciones automáticas para que los hablantes de otros idiomas distintos del inglés puedan disfrutar del contenido sobre los productos, los servicios y las tecnologías de Microsoft. Puesto que este artículo se ha traducido con traducción automática, es posible que contenga errores de vocabulario, sintaxis o gramática. 
  
    
    


## See also
<a name="MT_Footer"> </a>


#### 


  
    
    
 [Informes de actividades en el Centro de administración de Office 365](http://technet.microsoft.com/library/0d6dfb17-8582-4172-a9a9-aed798150263%28Office.14%29.aspx)
