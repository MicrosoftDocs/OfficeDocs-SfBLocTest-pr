---
title: Solución de problemas de inicio de sesión de Skype Empresarial Online para administradores
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 12/30/2016
ms.audience: Admin
ms.topic: Troubleshooting
ms.prod: LYNC
description: Learn common causes for Skype for Business Online sign-errors and Work through troubleshooting these problems. 
ms.technology:
- Lync 2013 for Office 365
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business admin center
- Skype for Business Online
ms.assetid: cdd4801a-2fe1-4aab-bbb6-db5f95f972d1
---


# Solución de problemas de inicio de sesión de Skype Empresarial Online para administradores

Para solucionar problemas de errores durante el inicio de sesión en Lync, empiece por eliminar las causas más frecuentes de dificultades durante el inicio de sesión. Si es necesario, puede seguir pasos específicos de solución, según el tipo de error. Si, aun así, el usuario no puede iniciar sesión, recopile más información y busque más ayuda.
  
    
    


## ¿Qué desea hacer?
<a name="__top"> </a>



  
    
    
>  [Comprobar causas frecuentes de errores durante el inicio de sesión de Lync](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__toc323194094)
    
  

  
    
    
>  [Seguir pasos de solución para un error específico (solo empresas)](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__toc325626440)
    

  
    
    
>  [Agregue una entrada de firewall para msoidsvc.exe en su servidor proxy](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__add_a_firewall)
    
  

  
    
    
>  [Actualizar la configuración DNS](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__update_dns_service)
    
  

  
    
    
>  [Instale un certificado SSL de un tercero en su servidor ADFS](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__verify_upn_and)
    
  

  
    
    
>  [Actualizar credenciales de seguridad](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__update_security_credentials_1)
    
  

  
    
    
>  [Modifique las claves de registro TrustModelData](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__modify_trustmodeldata_registry)
    
  

  
    
    
>  [Actualice la configuración de usuario en Active Directory](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__update_user_settings_1)
    
  

  
    
    
>  [Usar la guía de solución de problemas del soporte técnico de Microsoft](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__toc325626447)
    
  

  
    
    
>  [Recopilar más información y buscar ayuda adicional](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__collect_more_information_1)
    
  

## Comprobar causas frecuentes de errores durante el inicio de sesión de Lync
<a name="__toc323194094"> </a>

La mayoría de los problemas de inicio de sesión de Lync pueden resumirse en unas pocas causas, y muchas de estas son fáciles de corregir. En la siguiente tabla, se enumeran algunas causas comunes de los errores que se producen durante el inicio de sesión y algunos pasos que usted o los usuarios pueden seguir para resolverlas.
  
    
    


|**Causa posible**|**Solución**|
|:-----|:-----|
|Durante el inicio de sesión, aparece un cuadro de diálogo con la siguiente frase: **Lync no puede verificar si el servidor es de confianza para su dirección de inicio de sesión. ¿Desea conectarse de todas formas?** <br/> |Verifique que el nombre de dominio del cuadro de diálogo pertenezca a un servidor de confianza de su organización, por ejemplo, **domainName.contoso.com**. Pídale al usuario que seleccione la casilla **Confiar siempre en este servidor** y, a continuación, haga clic en **Conectar**. <br/> Los clientes empresariales pueden evitar que aparezca este mensaje cuando un usuario inicia sesión por primera vez, modificando el registro de Windows en el equipo de cada usuario. Para obtener detalles, consulte  [Modifique las claves de registro TrustModelData](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__modify_trustmodeldata_registry).  <br/> |
|Error en la escritura de la dirección de inicio de sesión, nombre de usuario o contraseña  <br/> | Confirme que el nombre de inicio de sesión y la contraseña del usuario sean correctos. <br/>  Verifique que el nombre de inicio de sesión del usuario tenga el siguiente formato: **bobk@contoso.com**. Este puede ser diferente al formato que usó para iniciar sesión en la red de su organización.  <br/>  Pídale al usuario que vuelva a intentar iniciar sesión en Lync. <br/> |
|Olvido de la contraseña  <br/> |Restablezca la contraseña del usuario y notifíquele la nueva contraseña provisoria.  <br/> |
|No tiene la licencia para usar Lync Online  <br/> |Confirme que el usuario está registrado como usuario de Lync. Si no lo está, registre al usuario y luego, pídale que vuelva a intentar iniciar sesión en Lync.  <br/> |
|Versión incorrecta de Lync instalada  <br/> |En general, este problema se asocia a un mensaje de error que contiene la siguiente frase: **es posible que el servicio de autenticación no sea compatible con esta versión del programa**.  <br/> Pídale al usuario que desinstale y vuelva a instalar Lync desde el portal de Office 365.  <br/> |
|Problema al adquirir el certificado personal necesario para iniciar sesión  <br/> |Si la dirección de inicio de sesión del usuario se ha modificado recientemente, puede que sea necesario eliminar los datos de inicio de sesión almacenados en caché. Pida a los usuarios que cierren sesión y hagan clic en el vínculo Borrar mi información de inicio de sesión que aparece en la pantalla para, a continuación, volver a intentarlo.  <br/> |
|Estableció un nombre de dominio personalizado y es posible que los cambios no hayan terminado de propagarse en el sistema.  <br/> |Primero, asegúrese de haber modificado los registros del Servicio de nombre de dominio (DNS) para reflejar el cambio. Para obtener detalles, vea  [Actualizar los registros del Servicio DNS (SRV)](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__update_dns_settings).  <br/> Si ya hizo los cambios necesarios en el DNS, recomiéndele al usuario que intente iniciar sesión más tarde. Los cambios en el DNS pueden demorar hasta 72 horas en verse reflejados en el sistema.  <br/> |
|Reloj del sistema no sincronizado con el reloj del servidor  <br/> |Asegúrese de que el controlador de dominio de su red se esté sincronizando con una fuente de tiempo externa confiable. Para obtener detalles, consulte el artículo 816042 de Microsoft Knowledge Base,  [Cómo configurar un servidor de tiempo autoritativo en Windows Server](http://go.microsoft.com/fwlink/?linkid=3052&amp;kbid=816042).  <br/> |
   
 [Para solucionar problemas de errores durante el inicio de sesión en Lync, empiece por eliminar las causas más frecuentes de dificultades durante el inicio de sesión. Si es necesario, puede seguir pasos específicos de solución, según el tipo de error. Si, aun así, el usuario no puede iniciar sesión, recopile más información y busque más ayuda.](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__top)
  
    
    

## Seguir pasos de solución para un error específico (solo empresas)
<a name="__toc325626440"> </a>


> [!IMPORTANT]
> Estas instrucciones se crearon para los clientes de Microsoft Office 365, Plan E. Si usted es cliente de Office 365, Plan P, pase a la sección que sigue,  [Recopilar más información y buscar ayuda adicional](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__collect_more_information_1). 
  
    
    

Si ya probó las sugerencias de la sección anterior y el usuario todavía no puede iniciar sesión, puede seguir intentando solucionar el problema, según el tipo de error. En la siguiente tabla, se enumeran los mensajes de error más frecuentes y las causas posibles. Después de la tabla se detallan los procedimientos para tratar cada problema.
  
    
    


|**Mensaje de error**|**Causa posible**|**Solución**|
|:-----|:-----|:-----|
|No se encontró la dirección de inicio de sesión  <br/> |Las solicitudes de inicio de sesión del Asistente de inicio de sesión de Microsoft Online Services (msoidsvc.exe) no están atravesando su firewall externo o servidor proxy.  <br/> | [Agregue una entrada de firewall para msoidsvc.exe en su servidor proxy](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__add_a_firewall) <br/> |
|El servidor no está disponible temporalmente  <br/> |Si su organización tiene un dominio personalizado, es posible que estén faltando las configuraciones necesarias para el Sistema de nombre de dominio (DNS) o que sean incorrectas.  <br/> | [Actualizar la configuración DNS](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__update_dns_service) <br/> |
|El servidor no está disponible temporalmente  <br/> |Si su organización está utilizando un único inicio de sesión con Servicios de federación de Active Directory (ADFS), es posible que haya usado un certificado de Capas de sockets seguros (SSL) con firma personal en lugar de un certificado de una entidad de certificación externa.  <br/> | [Instale un certificado SSL de un tercero en su servidor ADFS](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__verify_upn_and) <br/> |
|Problema para adquirir un certificado personal obligatorio para iniciar sesión  <br/> |Si ya eliminó los datos del servidor almacenados en caché que usa Lync para iniciar sesión, pero el error sigue apareciendo, es posible que la credenciales de seguridad del usuario estén dañadas o que una carpeta RSA del equipo del usuario esté bloqueando la autenticación.  <br/> | [Actualizar credenciales de seguridad](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__update_security_credentials_1) <br/> |
|Cuando un usuario inicia sesión por primera vez, aparece un cuadro de diálogo del certificado de confianza.  <br/> |Este cuadro de diálogo aparece si su servidor Lync todavía no aparece en la lista de la clave de registro **TrustModelData**.  <br/> | [Modifique las claves de registro TrustModelData](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__modify_trustmodeldata_registry) <br/> |
|El usuario no tiene habilitación para SIP  <br/> |Si se hizo una instalación previa de Microsoft Office Communications Server o Skype Empresarial Server 2015 en su organización, es posible que no haya eliminado a sus usuarios del servidor antes de desinstalar el software. Como consecuencia, el atributo **msRTCSIP-UserEnabled** todavía está establecido como **FALSO** en los servicios de dominio de Active Directory. <br/> | [Actualice la configuración de usuario en Active Directory](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__update_user_settings_1) <br/> |
   

### Agregue una entrada de firewall para msoidsvc.exe en su servidor proxy
<a name="__add_a_firewall"> </a>

Este procedimiento es una solución posible para el siguiente mensaje de error: **No se encontró la dirección de inicio de sesión**.
  
    
    
 **NOTA**: en los pasos que siguen se asume que está usando Microsoft Forefront Threat Management Gateway (TMG) 2010. Si tiene otra solución para puerta de enlace web, use las configuraciones que se describen en el paso 4, a continuación.
  
    
    
Para crear una entrada de aplicación para Msoidsvc.exe en Forefront TMG 2010, siga estos pasos:
  
    
    

1. En el panel izquierdo, en primer plano, haga clic en **Conexión de red**.
    
  
2. Haga clic en la pestaña **Red**. En la pestaña **Tareas** del panel derecho, haga clic en **Establecer la configuración de cliente de Forefront TMG**.
    
  
3. En el cuadro de diálogo **Configuración de cliente de Forefront TMG**, haga clic en **Nuevo**.
    
  
4. En el cuadro de diálogo **Configuración de entrada de la aplicación**, configure la siguientes reglas:
    
  


|****Aplicación****|****Clave****|****Valor****|
|:-----|:-----|:-----|
|**msoidsvc** <br/> |Deshabilitar  <br/> |0  <br/> |
|**msoidsvc** <br/> |DisableEx  <br/> |0  <br/> |
   
Para obtener detalles, consulte el artículo 2409256 de Microsoft Knowledge Base,  [No puede conectarse a Skype Empresarial Online porque un firewall local bloquea la ](http://go.microsoft.com/fwlink/?linkid=3052&amp;kbid=2409256).
  
    
    

### Actualizar la configuración DNS
<a name="__update_dns_service"> </a>

Si su organización tiene un dominio personalizado, este procedimiento representa una solución posible para el siguiente mensaje de error: **El servidor no está disponible temporalmente**.
  
    
    

- Póngase en contacto con el registrador de su nombre de dominio para obtener información sobre cómo agregar el siguiente registro CNAME a su dominio:
    
  - **Tipo de registro DNS**: CNAME
    
  
  - **Nombre**: sip
    
  
  - **Valor/Destino**: sipdir.online.microsoft.com
    
  
Para obtener detalles, consulte el artículo 2566790 de Microsoft Knowledge Base,  [No se puede iniciar sesión en Skype Empresarial Online porque el servidor no está disponible ](http://go.microsoft.com/fwlink/?linkid=3052&amp;kbid=2566790), y el artículo Wiki de Office 365,  [Cómo garantizar que su red funcione con Skype Empresarial Online](http://go.microsoft.com/fwlink/?linkid=231156).
  
    
    

### Instale un certificado SSL de un tercero en su servidor ADFS
<a name="__verify_upn_and"> </a>

Para instalar un certificado SSL de un tercero en su servidor de Servicios de Federación de Active Domain (ADFS), siga estos pasos:
  
    
    

1. Obtenga un certificado SSL de una entidad de certificación externa como VeriSign o Thawte.
    
  
2. Instale el certificado en su servidor ADFS con la consola de administración de ADFS. Para obtener detalles, consulte  [Planee e implemente Active Directory Federation Services 2.0 para usar con inicios de sesión únicos](http://go.microsoft.com/fwlink/?linkid=231164).
    
  

### Actualizar credenciales de seguridad
<a name="__update_security_credentials_1"> </a>

Este procedimiento representa una solución posible para el mensaje de error **Problemas para adquirir un certificado personal obligatorio para iniciar sesión**.
  
    
    
Para eliminar los posibles problemas con los certificados o credenciales, primero debe renovar el certificado del usuario en Windows Certificate Manager. Para hacerlo, siga estos pasos:
  
    
    

1. Abra Windows Certificate Manager. Para hacerlo, haga clic en **Inicio**, **Correr**, escriba **certmgr.msc** y haga clic en **Aceptar**.
    
  
2. Haga doble clic en **personal** y, a continuación, en **Certificados**.
    
  
3. Ordene por la columna **Emitido por** y, a continuación, busque un certificado que haya emitido Communications Server.
    
  
4. Haga clic con el botón derecho sobre el certificado y luego, haga clic en **Eliminar**.
    
  
Luego, si el usuario está usando Windows 7, elimine las credenciales almacenadas en Windows Credential Manager. Para hacerlo, siga estos pasos:
  
    
    

1. Haga clic en **Inicio**, **Panel de control** y, a continuación, en **Administrador de credenciales**.
    
  
2. Busque el conjunto de credenciales que se usa para conectarse a Lync Online.
    
  
3. Expanda el conjunto de credenciales y, a continuación, haga clic en **Quitar de la cámara**.
    
  
4. Vuelva a iniciar sesión en Lync Online e introduzca las credenciales del usuario nuevamente.
    
  
Por último, si ya actualizó las credenciales, pero el usuario todavía no puede iniciar sesión, intente eliminar la carpeta RSA del equipo del usuario, ya que podría estar bloqueando el proceso de autenticación:
  
    
    

1. Inicie sesión en el equipo del usuario mediante una cuenta de administrador.
    
  
2. Si es necesario, active la opción de vista de carpeta **Mostrar archivos ocultos**. Para obtener detalles, consulte el tema de ayuda de Windows  [Mostrar archivos ocultos](http://go.microsoft.com/fwlink/?linkid=231159).
    
  
3. Escriba lo siguiente en la barra de direcciones del explorador de archivos: **C:\\Documents and Settings\\UserName\\Application Data\\Microsoft\\Crypto\\RSA**, **donde** ** *UserName* ** ** es su nombre de inicio de sesión de Windows**.
    
  
4. Elimine todas las carpetas que empiecen con el nombre **S-1-5-21-** seguido de una cadena de números.
    
  

### Modifique las claves de registro TrustModelData
<a name="__modify_trustmodeldata_registry"> </a>

Cuando un usuario inicia sesión por primera vez, es posible que le aparezca un cuadro de diálogo con la siguiente frase: **Lync no puede verificar si el servidor es de confianza para su dirección de inicio de sesión. ¿Quiere conectarse de todas formas?**Esta es una función de seguridad y no un error. Sin embargo, puede evitar que aparezca el cuadro de diálogo usando un Objeto de directiva de grupo (GPO) para actualizar los equipos de los usuarios con su nombre de dominio antes de que inicien sesión por primera vez. Para esto, haga lo siguiente:
  
    
    

- Cree e implemente un GPO que se anexe a su nombre de dominio de Lync Online, por ejemplo, domainName.contoso.com, en el valor actual de HKEY_LOCAL_MACHINE\\Software\\Policies\\Microsoft\\Communicator\\TrustModelData.
    
  

> [!IMPORTANT]
> Debe *anexar*  su nombre de dominio al valor existente, no solo sustituirlo.
  
    
    

Para obtener detalles, consulte el artículo 2531068 de Microsoft Knowledge Base,  [Skype Empresarial no puede verificar si el servidor es de confianza para su dirección de inicio de sesión](http://go.microsoft.com/fwlink/?linkid=3052&amp;kbid=2531068).
  
    
    

### Actualice la configuración de usuario en Active Directory
<a name="__update_user_settings_1"> </a>

Si se hizo una instalación previa de Microsoft Office Communications Server o Skype Empresarial Server 2015 en su organización, es posible que no haya eliminado a sus usuarios del servidor antes de desinstalar el software. Como consecuencia, el atributo **msRTCSIP-UserEnabled** todavía está establecido como **FALSO** en los servicios de dominio de Active Directory.
  
    
    
Para solucionar este problema, siga estos pasos:
  
    
    

1. Actualice el atributo **msRTCSIP-UserEnabled** en todos los usuarios afectados como **VERDADERO**.
    
  
2. Vuelva a ejecutar la herramienta de sincronización de directorios (DirSync) de Microsoft Online Services. Para obtener detalles, consulte  [Sincronización de Active Directory: mapa de ruta](http://technet.microsoft.com/es-es/library/hh967642.aspx).
    
  
 [Para solucionar problemas de errores durante el inicio de sesión en Lync, empiece por eliminar las causas más frecuentes de dificultades durante el inicio de sesión. Si es necesario, puede seguir pasos específicos de solución, según el tipo de error. Si, aun así, el usuario no puede iniciar sesión, recopile más información y busque más ayuda.](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__top)
  
    
    

## Usar la guía de solución de problemas del soporte técnico de Microsoft
<a name="__toc325626447"> </a>

Si todavía no puede resolver los problemas de inicio de sesión del usuario, revise la sugerencias del artículo 2541980 de Microsoft Knowledge Base,  [Cómo solucionar problemas de autenticación y conectividad en Skype Empresarial Online](http://go.microsoft.com/fwlink/?linkid=3052&amp;kbid=2541980).
  
    
    

## Recopilar más información y buscar ayuda adicional
<a name="__collect_more_information_1"> </a>

Si siguió las instrucciones anteriores y, aun así, no puede resolver los problemas de inicio de sesión en Lync Online, debe recopilar más información y ponerse en contacto con el soporte técnico. Para hacerlo, siga estos pasos:
  
    
    

1. Obtenga los archivos de registro de Lync y los detalles de registros de eventos de Windows del equipo del usuario. Para obtener instrucciones paso a paso, consulte el tema de ayuda para el usuario final  [Activar registros de errores en Skype Empresarial](http://technet.microsoft.com/library/eaf6602b-95e0-4c27-869f-36017475806c%28Office.14%29.aspx).
    
  
2. Envíe los archivos de registro y la información detallada sobre el error al equipo de soporte técnico de Microsoft.
    
  
Es posible que le pidan que envíe más información de diagnóstico, mediante la instalación del Kit de herramientas de soporte de registro y diagnóstico de Microsoft Online Services (MOSDAL) en el equipo del usuario afectado. Para obtener detalles, consulte  [Cómo usar el Kit de herramientas de soporte MOSDAL](http://technet.microsoft.com/library/ddf1f52f-24a1-4675-abe0-141052c88b72%28Office.14%29.aspx).
  
    
    
 [Para solucionar problemas de errores durante el inicio de sesión en Lync, empiece por eliminar las causas más frecuentes de dificultades durante el inicio de sesión. Si es necesario, puede seguir pasos específicos de solución, según el tipo de error. Si, aun así, el usuario no puede iniciar sesión, recopile más información y busque más ayuda.](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md#__top)
  
    
    

