---
title: This Skype for Business Online feature isn't enabled
ms.author: TONYSMIT
author: TONYSMIT
manager: scotv
ms.date: 5/4/2015
ms.audience: Admin
ms.topic: Troubleshooting
f1_keywords: ms.lync.lac.FeatureNotEnabled
description: Find possible causes and action suggestions when you get a Skype for Buisness Online feature isn't enabled error. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: e95a7d09-0c45-4b95-956e-f099b7b0e659
---


# This Skype for Business Online feature isn't enabled

Sorry, it looks like the user isn't licensed for this feature.
  
    
    



|**Possible cause**|**Suggested action**|
|:-----|:-----|
|You have licenses available, but haven't turned on the feature for this user.  <br/> |Go to the **Office 365 admin center** > > **Users and groups** to license this user. <br/> |
|The user is in a location where this feature isn't available.  <br/> |If possible, go to **Office 365 admin center** > **Users and groups** and assign this user to a location where the feature is available. <br/> |
|The feature hasn't been turned on for your organization.  <br/> |Go to **Office 365 admin center** > **Skype Empresarial** and turn on the feature for your entire organization. <br/> |
   

