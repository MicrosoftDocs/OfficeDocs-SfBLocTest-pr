---
title: ¿Qué planes de llamada en Office 365?
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 10/3/2017
ms.audience: Admin
ms.topic: Discovery
ms.service: OFFICE365
description: Learn what Office 365 Callings Plans (PSTN calling) are, what regions it's available in, and where to go for step by step instructions on how to set it up. 
ms.collection:
- Adm_Skype4B_Online
- Adm_Skype4B_Online_Top
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag:
- Adm_O365_FullSet
- DianeF_Adm_Simplified
- LIL_Placement
- Strat_SB_PSTN
ms.assetid: 3dc773b9-95e0-4448-b2f1-887c54022429
---



# ¿Qué planes de llamada en Office 365?

> [!IMPORTANT]
> Este artículo se ha traducido con traducción automática; vea la  [declinación de responsabilidades](3dc773b9-95e0-4448-b2f1-887c54022429.md#MT_Footer). Para su referencia, puede encontrar la versión en inglés de este artículo  [aquí](https://support.office.com/en-us/article/3dc773b9-95e0-4448-b2f1-887c54022429). 
  
    
    


Llamar a los planes son un teléfono de complemento de servicio que, cuando se combina con el sistema telefónico en Office 365, puede convertirse en el sistema telefónico para toda la organización. Llamar a planear proporciona las personas de su empresa con un número de teléfono principal y permite realizar y recibir llamadas telefónicas fuera de su organización. Existen dos tipos de planes de llamada: **Llamar a planear nacionales** y **Llamar a planear internacional**. Para obtener más información, vea  [Calling Plans for Office 365](calling-plans-for-office-365.md).
  
    
    


Los usuarios que tienen asignados números de teléfono pueden realizar llamadas de voz desde los dispositivos de Skype Empresarial, incluidos  [Obtener teléfonos con Skype Empresarial Online](getting-phones-for-skype-for-business-online.md), equipos y dispositivos móviles. Pueden controlar sus llamadas a través de los teléfonos de escritorio y, así, por ejemplo, pueden silenciar o reactivar el audio, pausar y reanudar llamadas, transferir llamadas y usar las funciones de desvío de llamadas.
  
    
    


  
    
    
![Descripción general de llamadas RTC.](images/dde1d83d-9854-4e36-9eaf-8ba0dc0c6ffe.png)
  
    
    

  
    
    

  
    
    

## Países o regiones admitidos

Planes de llamada están disponibles en estos  [Países o regiones que se pueden llamar a los planes y las conferencias de Audio](countries-regions-that-are-supported-for-audio-conferencing-and-calling-plans.md).
  
    
    

## Configuración

La configuración de llamar a los planes son fáciles. Puede buscar, adquirir y asignar a nuevos números de teléfono a los usuarios. Puede transferir los números existentes a Office 365.
  
    
    
 **Para obtener instrucciones paso a paso de instalación, consulte  [Configurar planes de llamada](set-up-calling-plans.md).**
  
    
    
Para obtener más información sobre el sistema telefónico, llamar a los planes y conferencias de audio, vea este vídeo de YouTube:  [sistema telefónico de Office 365 y las reuniones de RTC de Skype empresarial ](https://www.youtube.com/watch?v=5Cxawu9mIag&amp;list=PLXtHYVsvn_b8dbRbnL19GUPcBH1UQ7c4x&amp;index=28).
  
    
    

||
|:-----|
|![Icono pequeño de LinkedIn Learning](images/7e5cb7c8-dc66-4c9a-a16d-a30f10a970bd.png) **¿Usa Office 365 por primera vez?**         Descubra cursos en vídeo gratuitos para **administradores de Office 365 y profesionales de TI**, ofrecidos por LinkedIn Learning. |
   

## 
<a name="MT_Footer"> </a>


> [!NOTE]
> **Declinación de responsabilidades de traducción automática**: Este artículo se ha traducido con un sistema informático sin intervención humana. Microsoft ofrece estas traducciones automáticas para que los hablantes de otros idiomas distintos del inglés puedan disfrutar del contenido sobre los productos, los servicios y las tecnologías de Microsoft. Puesto que este artículo se ha traducido con traducción automática, es posible que contenga errores de vocabulario, sintaxis o gramática. 
  
    
    


## See also
<a name="MT_Footer"> </a>


#### 


  
    
    
 [Términos y condiciones de las llamadas de emergencias](emergency-calling-terms-and-conditions.md)
  
    
    
 [Skype Empresarial Online: etiqueta de declinación de responsabilidades en llamadas de emergencia](https://go.microsoft.com/fwlink/?LinkID=692099)
  
    
    
 [What are emergency locations, addresses and call routing?](what-are-emergency-locations-addresses-and-call-routing.md)
  
    
    
 [Audio Conferencing complimentary dial-out period](audio-conferencing-complimentary-dial-out-period.md)
  
    
    
 [Skype para Business y Microsoft Teams licencias de complemento](skype-for-business-and-microsoft-teams-add-on-licensing.md)
