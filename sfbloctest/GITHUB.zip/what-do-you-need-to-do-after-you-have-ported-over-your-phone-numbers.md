---
title: What do you need to do after you have ported over your phone numbers?
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 6/16/2016
ms.audience: Admin
ms.topic: Setup/Install
f1_keywords: ms.lync.lac.PortOrderFinish
description: See what you need to do next after you've ported your phone numbers to Skype for Business.
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: 825a6cf0-3d22-419a-8358-a8678f14b61d
---


# What do you need to do after you have ported over your phone numbers?

After you have submitted your port order, we will contact your carrier and working out the details with them. When the final transfer date has been set, we will notify you via email. However, while waiting on your carrier to accept the order, go ahead and create the required emergency address you will use with these numbers.
  
    
    


- You can learn more about  [What are emergency locations, addresses and call routing?](what-are-emergency-locations-addresses-and-call-routing.md).
    
  
- You can  [Agregar o quitar una dirección de emergencia para su organización](add-or-remove-an-emergency-address-for-your-organization.md) if you need to.
    
  
- If your phone numbers already have an emergency address  [Agregar, cambiar o quitar una ubicación de emergencia de su organización](add-change-or-remove-an-emergency-location-for-your-organization.md).
    
  
-  [Asignar, cambiar o quitar un número de teléfono en Skype empresarial](assign-change-or-remove-a-phone-number-for-a-user.md) .
    
  

## See also


#### 


  
    
    
 [Términos y condiciones de las llamadas de emergencias](emergency-calling-terms-and-conditions.md)
  
    
    
 [Audio Conferencing complimentary dial-out period](audio-conferencing-complimentary-dial-out-period.md)
