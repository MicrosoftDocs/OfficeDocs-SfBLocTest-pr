---
title: Skype for Business Online admin help [Internal only]
ms.author: tonysmit
author: tonysmit
ms.date: 9/20/2017
ms.audience: Admin
ms.topic: Navigation
description: This is an internal only topic for Skype for Business Online admin help, with links to other topic. 
ms.assetid: dfe5d76a-1d9f-48cf-bdc9-7681831b5d12
---


# Skype for Business Online admin help [Internal only]

Here is a listing of all Skype for Business Online admin topics that are available at  [Office 365 Help](https://support.office.com).
  
    
    


> [!CAUTION]
> **These links only work at https://support.officeppe.com because this isn't published externally. To get to this internal site, you MUST be connected to corp.net and can't be using a VPN.**
  
    
    


## Accessibility and regulatory


||
|:-----|
| [Accessibility Declaration of Conformance for Skype for Business Online in France](accessibility-declaration-of-conformance-for-skype-for-business-online-in-france.md) <br/> |
| [Accessibility solutions for Skype for Business Online in France](accessibility-solutions-for-skype-for-business-online-in-france.md) <br/> |
| [Llamadas RTC de Skype Empresarial - Código de prácticas para Reino Unido](calling-plans-in-office-365code-of-practice-for-the-united-kingdom-u-k.md) <br/> |
| [Llamadas RTC de Skype Empresarial - Código de gestión de quejas para Reino Unido](calling-plans-in-office-365complaint-handling-code-for-the-united-kingdom-u-k.md) <br/> |
| [Prácticas de recopilación de datos de Skype Empresarial](skype-for-business-data-collection-practices.md) <br/> |
| [Audio Conferencing complimentary dial-out period](audio-conferencing-complimentary-dial-out-period.md) <br/> |
   

## Office 365 Phone System voicemail


||
|:-----|
| [Cambiar el idioma predeterminado en los saludos del buzón de voz y los correos electrónicos de su organización](change-the-default-language-for-voicemail-greetings-and-emails-in-your-organizat.md) <br/> |
| [Languages for voicemail greetings and messages from Skype for Business](languages-for-voicemail-greetings-and-messages-from-skype-for-business.md) <br/> |
| [Configurar el correo de voz del sistema telefónico: Ayuda de administración](set-up-phone-system-voicemailadmin-help.md) <br/> |
   

## Office 365 Phone System and Calling Plans


||
|:-----|
| [Agregar o quitar una dirección de emergencia para su organización](add-or-remove-an-emergency-address-for-your-organization.md) <br/> |
| [Agregar, cambiar o quitar una ubicación de emergencia de su organización](add-change-or-remove-an-emergency-location-for-your-organization.md) <br/> |
| [Asignar, cambiar o quitar un número de teléfono en Skype empresarial](assign-change-or-remove-a-phone-number-for-a-user.md) <br/> |
| [Asignar o cambiar la dirección de emergencia de un usuario](assign-or-change-an-emergency-address-for-a-user.md) <br/> |
| [Authorized person on the account](authorized-person-on-the-account.md) <br/> |
| [Cambiar la dirección de emergencia de un usuario](change-the-emergency-address-for-a-user.md) <br/> |
| [Cambiar la ubicación de emergencia de un usuario](change-the-emergency-location-for-a-user.md) <br/> |
| [Crear y administrar planes de marcado](create-and-manage-dial-plans.md) <br/> |
| [Crear una cola de llamada del sistema telefónico](create-a-phone-system-call-queue.md) <br/> |
| [Diferentes tipos de números de teléfono utilizados en Skype empresarial Online](different-kinds-of-phone-numbers-used-for-calling-plans.md) <br/> |
| [Descargar una Carta de autorización (LOA)](download-a-letter-of-authorization-loa.md) <br/> |
| [Emergency calling disclaimer (download details)](https://www.microsoft.com/en-us/download/details.aspx?id=49918) <br/> |
| [Términos y condiciones de las llamadas de emergencias](emergency-calling-terms-and-conditions.md) <br/> |
| [Obtener el nuevo formulario de solicitud de números de teléfono de usuario](get-new-user-phone-numbers-request-form.md) <br/> |
| [Manage phone numbers for your organization](manage-phone-numbers-for-your-organization.md) <br/> |
| [Obtener números de teléfono de Skype Empresarial para los usuarios](getting-phone-numbers-for-your-users.md) <br/> |
| [Aquí es lo que obtiene con el sistema telefónico en Office 365](here-s-what-you-get-with-phone-system-in-office-365.md) <br/> |
| [Cómo se puede usar la identificación de llamadas en su organización](how-can-caller-id-be-used-in-your-organization.md) <br/> |
| [How do I create a support ticket for address validation?](how-do-i-create-a-support-ticket-for-address-validation.md) <br/> |
| [¿Cuántos números de teléfono puede obtener?](how-many-phone-numbers-can-you-get.md) <br/> |
| [How should I enter the phone numbers?](how-should-i-enter-the-phone-numbers.md) <br/> |
| [Manually submit a custom service request](manually-submit-a-custom-service-request.md) <br/> |
| [Port order account information](port-order-account-information.md) <br/> |
| [Port order overview](port-order-overview.md) <br/> |
| [Llamar a los problemas conocidos de planes](calling-plans-known-issues.md) <br/> |
| [Buscar números de teléfono para los usuarios](search-for-phone-numbers-for-users.md) <br/> |
| [Ver una lista de números de teléfono de su organización](see-a-list-of-phone-numbers-in-your-organization.md) <br/> |
| [Establecer el identificador de llamada de un usuario](set-the-caller-id-for-a-user.md) <br/> |
| [Configurar un operador automático de sistema telefónico](set-up-a-phone-system-auto-attendant.md) <br/> |
| [Configurar planes de llamada](set-up-calling-plans.md) <br/> |
| [Establecer el PIN para transferir los números de teléfono a un nuevo proveedor de servicios](set-your-pin-for-transferring-phone-numbers-to-a-new-service-provider.md) <br/> |
| [Skype para restricciones y límites de número gratuitos de empresa](skype-for-business-toll-free-number-limits-and-restrictions.md) <br/> |
| [Submitting a service request for local number porting](submitting-a-service-request-for-local-number-porting.md) <br/> |
| [Números de teléfono de transferencia a Office 365](transfer-phone-numbers-to-office-365.md) <br/> |
| [¿Cuáles son los operadores automáticos de sistema telefónico?](what-are-phone-system-auto-attendants.md) <br/> |
| [What are emergency locations, addresses and call routing?](what-are-emergency-locations-addresses-and-call-routing.md) <br/> |
| [¿Cuáles son los planes de marcado?](what-are-dial-plans.md) <br/> |
| [What do you need to do after you have ported over your phone numbers?](what-do-you-need-to-do-after-you-have-ported-over-your-phone-numbers.md) <br/> |
| [What if my phone carrier isn't listed here?](what-if-my-phone-carrier-isn-t-listed-here.md) <br/> |
| [What is address validation?](what-is-address-validation.md) <br/> |
| [What is my billing telephone number?](what-is-my-billing-telephone-number.md) <br/> |
| [¿Qué planes de llamada en Office 365?](what-are-calling-plans-in-office-365.md) <br/> |
| [What should I put in for the account number?](what-should-i-put-in-for-the-account-number.md) <br/> |
| [What should I put in for the company name?](what-should-i-put-in-for-the-company-name.md) <br/> |
| [What should I put in for the service address?](what-should-i-put-in-for-the-service-address.md) <br/> |
| [What's the status of my port orders?](what-s-the-status-of-my-port-orders.md) <br/> |
| [Why am I having problems entering address information when it's out of the U.S?](why-am-i-having-problems-entering-address-information-when-it-s-out-of-the-u-s.md) <br/> |
| [Why has number activation failed?](http://technet.microsoft.com/library/e027d2dd-7178-44e7-8718-d3a16bb6e018%28Office.14%29.aspx) <br/> |
| [Why is number activation just pending?](http://technet.microsoft.com/library/f55b91a7-6b17-454f-809f-319ceba2e7fd%28Office.14%29.aspx) <br/> |
| [Why is number activation listed as incomplete?](http://technet.microsoft.com/library/0163d4e9-4cd7-4c91-bcbe-e7b52d6328d2%28Office.14%29.aspx) <br/> |
| [Why is number activation listed as pending?](http://technet.microsoft.com/library/ee6ae734-4dcc-4927-87ee-227ee3211118%28Office.14%29.aspx) <br/> |
| [Your port order was accepted](your-port-order-was-accepted.md) <br/> |
   

## Delegation


||
|:-----|
| [Configurar y solucionar problemas de Skype empresarial Online delegación](set-up-and-troubleshoot-skype-for-business-online-delegation.md)|
   

## Miscellaneous


||
|:-----|
| [Administración y adopción de cambios en Skype Empresarial](skype-for-business-change-management-and-adoption.md) <br/> |
| [Recursos de cliente de Skype Empresarial en Lync Server: concienciación y planificación de la configuración](skype-for-business-client-on-lync-server-resources-awareness-and-readiness-plann.md) <br/> |
| [Cliente de Skype Empresarial en Lync Online: conciencia y preparación para la planificación](skype-for-business-client-on-lync-onlineawareness-and-readiness-planning.md) <br/> |
| [Nuevas características de Skype Empresarial Online](http://technet.microsoft.com/library/7adf82d2-c902-4624-83cd-9c9c7adc3310%28Office.14%29.aspx) <br/> |
| [Recursos de Skype Empresarial Online](http://technet.microsoft.com/library/8976a427-1683-43a7-9a90-af249726d763%28Office.14%29.aspx) <br/> |
| [Cambiar de la interfaz de usuario del cliente de Lync a la de Skype Empresarial](switching-between-the-skype-for-business-and-the-lync-client-user-interfaces.md) <br/> |
   

## Optimizing your network for Skype for Business Online


||
|:-----|
| [Flujo de llamadas con ExpressRoute](call-flow-using-expressroute.md) <br/> |
| [ExpressRoute y QoS en Skype Empresarial Online](expressroute-and-qos-in-skype-for-business-online.md) <br/> |
| [Calidad de medios y rendimiento de conectividad de la red en Skype Empresarial Online](media-quality-and-network-connectivity-performance-in-skype-for-business-online.md) <br/> |
| [Optimizar la red para Skype Empresarial Online](optimizing-your-network-for-skype-for-business-online.md) <br/> |
| [Servidores proxy para Skype Empresarial Online](proxy-servers-for-skype-for-business-online.md) <br/> |
| [Optimización del rendimiento de Skype Empresarial Online](http://technet.microsoft.com/library/beec23c2-c5d6-4e84-a8af-e82aefca7802%28Office.14%29.aspx) <br/> |
   

## Phones


||
|:-----|
| [Obtener teléfonos con Skype Empresarial Online](getting-phones-for-skype-for-business-online.md) <br/> |
| [Implementación de teléfonos de Skype Empresarial Online](deploying-skype-for-business-online-phones.md) <br/> |
   

## Policy management


||
|:-----|
| [Transferencia de archivos punto a punto de bloque en Skype empresarial Online](block-point-to-point-file-transfers-in-skype-for-business-online.md) <br/> |
| [Crear directivas de acceso externo personalizado en Skype empresarial Online](create-custom-external-access-policies-in-skype-for-business-online.md) <br/> |
| [Establecer directivas de conferencia de Skype Empresarial Online en su organización](set-skype-for-business-online-conferencing-policies-for-your-organization.md) <br/> |
| [Establecer directivas móviles de Skype Empresarial Online en su organización](set-skype-for-business-online-mobile-policies-for-your-organization.md) <br/> |
| [Establecer directivas de cliente de Skype Empresarial Online en su organización](set-skype-for-business-online-client-policies-for-your-organization.md) <br/> |
   

## Office 365 Audio Conferencing


||
|:-----|
| [Asignar a un tercero como el proveedor de conferencias de audio](assign-a-third-party-as-the-audio-conferencing-provider.md) <br/> |
| [Asignar Microsoft como proveedor de conferencias de audio](assign-microsoft-as-the-audio-conferencing-provider.md) <br/> |
| [Audioconferencia idiomas compatibles](audio-conferencing-supported-languages.md) <br/> |
| [Problemas conocidos y solución de problemas de conferencias audio](audio-conferencing-troubleshooting-and-known-issues.md) <br/> |
| [Cambiar la configuración de un puente de conferencia de audio](change-the-settings-for-an-audio-conferencing-bridge.md) <br/> |
| [Cambiar el pago o gratuitos números en el puente de conferencia de audio](change-the-toll-or-toll-free-numbers-on-your-audio-conferencing-bridge.md) <br/> |
| [Comparar los proveedores de audioconferencia](compare-audio-conferencing-providers.md) <br/> |
| [Llamar desde una reunión para que otras personas puedan unirse](dialing-out-from-a-meeting-so-other-people-can-join-it.md) <br/> |
| [Mensajes de correo electrónico que se envían automáticamente a los usuarios cuando cambie su configuración de conferencias de Audio](emails-that-are-automatically-sent-to-users-when-their-audio-conferencing-settin.md) <br/> |
| [Habilitar o deshabilitar el envío de correos electrónicos cuando cambie la configuración de conferencias de Audio](enable-or-disable-sending-emails-when-audio-conferencing-settings-change.md) <br/> |
| [Permitir a los usuarios grabar su nombre al unirse a una reunión](enable-users-to-record-their-name-when-they-join-a-meeting.md) <br/> |
| [¿Administrar la configuración de conferencias de Audio de mi organización?](manage-the-audio-conferencing-settings-for-my-organization.md) <br/> |
| [Moving a user's audio conferencing provider to Microsoft](moving-a-user-s-audio-conferencing-provider-to-microsoft.md) <br/> |
| [Números de teléfono para las conferencias de Audio](phone-numbers-for-audio-conferencing.md) <br/> |
| [Restablecer un id. de conferencia para un usuario](reset-a-conference-id-for-a-user.md) <br/> |
| [Restablecer el PIN de conferencia de acceso telefónico local de un usuario](reset-the-audio-conferencing-pin-for-a-user.md) <br/> |
| [Ver, cambiar y restablecer un id. de conferencia asignado a un usuario](see-change-and-reset-a-conference-id-assigned-to-a-user.md) <br/> |
| [Ver una lista de números de acceso telefónico para conferencias de acceso telefónico local](see-a-list-of-audio-conferencing-numbers.md) <br/> |
| [Ver una lista de usuarios habilitados para conferencias de acceso telefónico local](see-a-list-of-users-that-are-enabled-for-audio-conferencing.md) <br/> |
| [Enviar un correo electrónico a un usuario con su información sobre la conferencia de acceso telefónico local](send-an-email-to-a-user-with-their-audio-conferencing-information.md) <br/> |
| [Establecer la longitud del PIN para las reuniones de acceso telefónico local](set-the-length-of-the-pin-for-audio-conferencing-meetings.md) <br/> |
| [Set up Audio Conferencing for Skype for Business and Microsoft Teams](set-up-audio-conferencing-for-skype-for-business-and-microsoft-teams.md) <br/> |
| [Establecer idiomas del operador automático para conferencias de Audio](set-auto-attendant-languages-for-audio-conferencing.md) <br/> |
| [Establecer los números de teléfono de conferencias de Audio para organizadores que se incluyen en invitaciones](set-the-audio-conferencing-phone-numbers-for-meeting-organizers-that-are-include.md) <br/> |
| [Configuración del servicio de migración de reuniones (MMS)](setting-up-the-meeting-migration-service-mms.md) <br/> |
| [Iniciar una audioconferencia por teléfono sin un PIN](start-an-audio-conference-over-the-phone-without-a-pin.md) <br/> |
| [Try or purchase Audio Conferencing in Office 365](try-or-purchase-audio-conferencing-in-office-365.md) <br/> |
| [Activar o desactivar los anuncios de entrada y salida para las reuniones](turn-on-or-off-entry-and-exit-announcements-for-meetings.md) <br/> |
| [What are dynamic conference IDs in Skype for Business Online?](http://technet.microsoft.com/library/1079d8f9-46cf-4412-b673-dfd366130fd7%28Office.14%29.aspx) <br/> |
   

## Reporting


||
|:-----|
| [Creación de informes en Skype Empresarial Online](skype-for-business-online-reporting.md) <br/> |
| [Informe de actividad de Skype Empresarial](skype-for-business-activity-report.md) <br/> |
| [Informe de clientes usados de Skype Empresarial](skype-for-business-clients-used-report.md) <br/> |
| [Informe de actividad de organizador de conferencias de Skype Empresarial](skype-for-business-conference-organizer-activity-report.md) <br/> |
| [Informe de actividad de participantes de conferencias de Skype Empresarial](skype-for-business-conference-participant-activity-report.md) <br/> |
| [Informe de actividad punto a punto de Skype Empresarial](skype-for-business-peer-to-peer-activity-report.md) <br/> |
| [Informe de usuarios bloqueados de Skype Empresarial](skype-for-business-blocked-users-report.md) <br/> |
| [Informe de uso de RTC de Skype Empresarial](skype-for-business-pstn-usage-report.md) <br/> |
| [Skype for Business session details report](skype-for-business-session-details-report.md) - not started <br/> |
   

## Service phone numbers


||
|:-----|
| [Obtener números de teléfono de servicio de Skype Empresarial](getting-service-phone-numbers-for-skype-for-business-and-microsoft-teams.md)|
   

## Supported countries and regions


||
|:-----|
| [Países o regiones que se pueden llamar a los planes y las conferencias de Audio](countries-regions-that-are-supported-for-audio-conferencing-and-calling-plans.md)|
   

## Set up Skype for Business Online


||
|:-----|
| [Accesibilidad en Skype Empresarial Online](http://technet.microsoft.com/library/14fb922b-beef-478e-8d29-491cc30c8da6%28Office.14%29.aspx) <br/> |
| [Allow users to contact external Skype for Business users](allow-users-to-contact-external-skype-for-business-users.md) <br/> |
| [Configurar la presencia en Skype Empresarial Online](configure-presence-in-skype-for-business-online.md) <br/> |
| [Configure presence privacy mode](http://technet.microsoft.com/library/33d57fe-b9cf-43c1-961a-edf28db738e8.aspx) <br/> |
| [Admins: Configure Skype for Business settings for individual users](admins-configure-skype-for-business-settings-for-individual-users.md) <br/> |
| [Customize meeting invitations](customize-meeting-invitations.md) <br/> |
| [Implementar el cliente de Skype Empresarial en Office 365](deploy-the-skype-for-business-client-in-office-365.md) <br/> |
| [Features managed by your Office 365 provider](features-managed-by-your-office-365-provider.md) <br/> |
| [Permitir a los usuarios grabar sus conferencias de audio y vídeo](let-people-record-their-audio-and-video-conferences.md) <br/> |
| [Permitir que los usuarios de Skype Empresarial agreguen contactos de Skype](let-skype-for-business-users-add-skype-contacts.md) <br/> |
| [Configurar Skype Empresarial Online](set-up-skype-for-business-online.md) <br/> |
| [Skype for Business Online admin center users page limitations](skype-for-business-online-admin-center-users-page-limitations.md) <br/> |
| [Resumen de configuración de Skype Empresarial Online](skype-for-business-online-settings-summary.md) <br/> |
| [This Skype for Business Online feature isn't enabled](this-skype-for-business-online-feature-isn-t-enabled.md) <br/> |
| [The user's Skype for Business Online service plan isn't valid](the-user-s-skype-for-business-online-service-plan-isn-t-valid.md) <br/> |
| [Solución de problemas con Skype Empresarial Online](troubleshoot-problems-with-skype-for-business-online.md) <br/> |
| [Solución de problemas de inicio de sesión de Skype Empresarial Online para administradores](troubleshooting-skype-for-business-online-sign-in-errors-for-administrators.md) <br/> |
| [Activar o desactivar la precarga de contenido con Outlook en las reuniones](turn-on-or-off-allowing-content-to-be-preloaded-for-meetings-using-outlook.md) <br/> |
| [Activar o desactivar los mensajes sin conexión para administradores](turn-on-or-off-offline-messages-for-admins.md) <br/> |
| [Probar la instalación de Skype Empresarial Online](test-your-skype-for-business-online-installation.md) <br/> |
| [Activar o desactivar las notificaciones del teléfono móvil](turn-on-or-off-mobile-phone-notifications.md) <br/> |
| [Activar o desactivar los informes de comentarios de clientes de Skype Empresarial](turn-on-or-off-skype-for-business-client-feedback-reporting.md) <br/> |
| [User statistics and organization information](user-statistics-and-organization-information.md) <br/> |
| [Vídeo: Comunicaciones externas de Skype Empresarial Online](video-skype-for-business-online-external-communications.md) - revising. <br/> |
| [Why can't I use the Skype for Business Online admin center right now?](why-can-t-i-use-the-skype-for-business-online-admin-center-right-now.md) <br/> |
   

## Set up Skype Meeting Broadcast


||
|:-----|
| [Habilitar la Difusión de reunión de Skype](enable-skype-meeting-broadcast.md) <br/> |
| [Configurar la red para Difusión de reunión de Skype](set-up-your-network-for-skype-meeting-broadcast.md) <br/> |
| [Make changes to Skype Meeting Broadcast settings for your organization](make-changes-to-skype-meeting-broadcast-settings-for-your-organization.md) <br/> |
| [Skype Meeting Broadcast Preview settings](skype-meeting-broadcast-preview-settings.md) <br/> |
   

## Skype for Business and Windows PowerShell


||
|:-----|
| [Configurar el equipo de Skype para Windows PowerShell y administración empresarial Online](setup-your-computer-for-skype-for-business-online-management-and-windows-powersh.md) <br/> |
| [Descargue e instale el Skype para módulo Business Connector en línea](download-and-install-the-skype-for-business-online-connector-module.md) <br/> |
| [Descargar e instalar Windows PowerShell 3.0](download-and-install-windows-powershell-3-0.md) <br/> |
| [Administrar la mensajería unificada de Exchange y alojado correo de voz de Skype empresarial Online](manage-exchange-unified-messaging-and-hosted-voicemail-in-skype-for-business-onl.md) <br/> |
| [Administrar cuentas de usuario](manage-user-accounts-using-the-skype-for-business-online-connector.md) <br/> |
| [Administrar Skype para las organizaciones empresariales en línea con el Skype para Business Connector en línea](manage-skype-for-business-online-organizations-using-the-skype-for-business-onli.md) <br/> |
| [Diagnosticar problemas de conexión con la Skype para Business Connector en línea](diagnose-connection-problems-with-the-skype-for-business-online-connector.md) <br/> |
   

## Skype for Business licensing


||
|:-----|
| [Add funds and manage Communications Credits](add-funds-and-manage-communications-credits.md) <br/> |
| [Asignar Skype para Business y Microsoft Teams licencias](assign-skype-for-business-and-microsoft-teams-licenses.md) <br/> |
| [Calling Plans for Office 365](calling-plans-for-office-365.md) <br/> |
| [Configurar comunicaciones créditos para su organización](set-up-communications-credits-for-your-organization.md) <br/> |
| [Skype para Business y Microsoft Teams licencias de complemento](skype-for-business-and-microsoft-teams-add-on-licensing.md) <br/> |
| [¿Qué son créditos de comunicaciones?](what-are-communications-credits.md) <br/> |
   

## Skype for Business mobile app security


||
|:-----|
| [Skype para la seguridad de la aplicación móvil de empresa](skype-for-business-mobile-app-security.md)|
   

## Skype for Business Online support in Outlook on the web


||
|:-----|
| [Compatibilidad de Skype Empresarial Online en Outlook en la web](skype-for-business-online-support-in-outlook-on-the-web.md)|
   

## Skype-to-phone


||
|:-----|
| [Skype a teléfono](skype-to-phone.md) <br/> |
| [Configurar mensajería por voz de Skype a teléfono](skype-to-phone-voice-messaging-set-up.md) <br/> |
| [Skypes-to-phone access numbers](skypes-to-phone-access-numbers.md) <br/> |
| [Skype-to-phone providers](skype-to-phone-providers.md) <br/> |
   

## Using Call Quality in your organization


||
|:-----|
| [Dimensiones y medidas disponibles en panel de calidad de llamada para Teams de Microsoft y Skype empresarial Online](dimensions-and-measures-available-in-call-quality-dashboard-for-microsoft-teams.md) <br/> |
| [Configurar Skype para Business Analytics de llamadas](set-up-skype-for-business-call-analytics.md) <br/> |
| [Turning on and using Call Quality Dashboard for Microsoft Teams and Skype for Business Online](turning-on-and-using-call-quality-dashboard-for-microsoft-teams-and-skype-for-bu.md) <br/> |
| [Calidad de llamadas de análisis de uso llamar a solucionar problemas de una mala Skype para la empresa](use-call-analytics-to-troubleshoot-poor-skype-for-business-call-quality.md) <br/> |
| [¿Cuál es la diferencia entre el análisis de llamadas y panel de calidad de llamada?](what-s-the-difference-between-call-analytics-and-call-quality-dashboard.md) <br/> |
   

