---
title: What should I put in for the service address?
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 6/14/2016
ms.audience: Admin
ms.topic: Setup/Install
f1_keywords: ms.lync.lac.PortOrderAccountInfoServiceAddress
ms.prod: LYNC
description: Learn what your service address is, how it differes from your billing address, and where you can find it. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: b7bcf334-1dc6-4fd7-8145-f89ce695fca0
---


# What should I put in for the service address?

This is the service address that is different from billing or emergency address that you have registered with your phone service provider or carrier. If you don't know this, you can contact your service provider or carrier to find out the service address that is listed on your account.
  
    
    


 **For complete step-by-step instructions, see  [Números de teléfono de transferencia a Office 365](transfer-phone-numbers-to-office-365.md).**
  
    
    


## See also


#### 


  
    
    
 [Términos y condiciones de las llamadas de emergencias](emergency-calling-terms-and-conditions.md)
  
    
    
 [Audio Conferencing complimentary dial-out period](audio-conferencing-complimentary-dial-out-period.md)
