---
title: Your port order was accepted
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 9/22/2017
ms.audience: Admin
ms.topic: Setup/Install
f1_keywords: ms.lync.lac.PortOrderQuickViewPanelTransferAccepted
description: What it means when your port order has been accepted, and what you need to do next to finish your Skype for Business set up. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: 5c2e57c2-76c4-4a36-9d01-92cd15c5eb3e
---


# Your port order was accepted

Your port order is approved! Look for your phone numbers in the **Skype for Business admin center** > **Voice** > **Phone numbers**.
  
    
    


 **IMPORTANTE**: Para poder ver la opción **Voz** en el panel de navegación izquierdo del Centro de administración de Skype Empresarial, primero tiene que adquirir como mínimo una **licencia de Enterprise E5**, una licencia del complemento **Sistema telefónico** o una licencia del complemento **Audioconferencia**.
  
    
    


Now that it's approved and your phone numbers are ready, you will need to do a couple things to get everything set up.
  
    
    


- Make sure you  [Skype para Business y Microsoft Teams licencias de complemento](skype-for-business-and-microsoft-teams-add-on-licensing.md). You will need an **Phone System** and **Domestic Calling Plan** or **International Plan**.
    
  
- Create your  [Agregar o quitar una dirección de emergencia para su organización](add-or-remove-an-emergency-address-for-your-organization.md) and if you want to your [Agregar, cambiar o quitar una ubicación de emergencia de su organización](add-change-or-remove-an-emergency-location-for-your-organization.md) (if you need to - In some countries/regions you get an emergency address with the phone number).
    
  
- Go ahead and  [Asignar, cambiar o quitar un número de teléfono en Skype empresarial](assign-change-or-remove-a-phone-number-for-a-user.md).
    
  

## See also


#### 


  
    
    
 [Términos y condiciones de las llamadas de emergencias](emergency-calling-terms-and-conditions.md)
  
    
    
 [Audio Conferencing complimentary dial-out period](audio-conferencing-complimentary-dial-out-period.md)
