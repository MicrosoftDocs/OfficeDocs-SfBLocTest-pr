---
title: What should I put in for the company name?
ms.author: tonysmit
author: tonysmit
manager: scotv
ms.date: 6/14/2016
ms.audience: Admin
ms.topic: Setup/Install
f1_keywords: ms.lync.lac.PortOrderAccountInfoCompanyName
ms.prod: LYNC
description: What to put for the company in Skype for Business, and where you can find it. 
ms.collection: Adm_Skype4B_Online
ms.technology:
- Office 365 Enterprise
- Office 365 Enterprise admin
- Office 365 Midsize Business
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
- Skype for Business Online admin center
ms.set-free-tag: Adm_O365_FullSet
ms.assetid: 5c274a36-9e7a-4399-af08-688ffc75b8ac
---


# What should I put in for the company name?

This is the name of your company or organization. The name of the company is limited to 25 characters which includes spaces. The name of the company isn't used to process the port order request, it is used in the case of a dispute or if something is incorrect when the phone numbers are being ported over. If you can't fit the entire name of the company in the box, it won't delay or cancel the port order.
  
    
    


 **For complete step-by-step instructions, see  [Números de teléfono de transferencia a Office 365](transfer-phone-numbers-to-office-365.md).**
  
    
    


## See also


#### 


  
    
    
 [Términos y condiciones de las llamadas de emergencias](emergency-calling-terms-and-conditions.md)
  
    
    
 [Audio Conferencing complimentary dial-out period](audio-conferencing-complimentary-dial-out-period.md)
