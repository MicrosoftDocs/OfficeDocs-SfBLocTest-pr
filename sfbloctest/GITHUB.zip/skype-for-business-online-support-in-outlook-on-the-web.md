---
title: Compatibilidad de Skype Empresarial Online en Outlook en la web
ms.author: tonysmit
author: tonysmit
ms.date: 11/8/2016
ms.audience: Admin
ms.technology:
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
ms.assetid: 305984ec-3da8-4509-bb2b-6643dcf2cb7d
---


# Compatibilidad de Skype Empresarial Online en Outlook en la web

Outlook en la web (Outlook Web App) en Office 365 ofrece un cliente básico de Skype Empresarial en la barra de navegación. Este cliente básico está disponible para usuarios en línea cuyo administrador no ha configurado una URL mnemónica para su organización de Office 365. Siempre que la cuenta del usuario esté en línea y no tenga una URL mnemónica, se podrá ver la experiencia, incluso si la organización dispone de cuentas de usuario locales. Los usuarios que tienen cuentas de usuario locales (con o sin URL mnemónicas) o gestionadas por Microsoft verán la experiencia de Lync en Outlook Web App.
  
    
    


La tabla siguiente ayuda a resumir las distintas configuraciones que puede tener y qué cliente web se utiliza:
  
    
    


||||
|:-----|:-----|:-----|
|**Ubicación de la cuenta de usuario** <br/> |**Hay una URL mnemónica configurada o una organización dedicada** <br/> |**Experiencia de Skype Empresarial o Lync** <br/> |
|Online  <br/> |No  <br/> |Experiencia web de Skype Empresarial  <br/> |
|Online  <br/> |Sí  <br/> |Experiencia web de Lync  <br/> |
|Híbrida pero hospedada en línea  <br/> |No  <br/> |Experiencia web de Skype Empresarial  <br/> |
|Híbrida pero hospedada en línea  <br/> |Sí  <br/> |Experiencia web de Lync  <br/> |
|Híbrida pero hospedada localmente  <br/> |No  <br/> |Experiencia web de Lync  <br/> |
|Híbrida pero hospedada localmente  <br/> |Sí  <br/> |Experiencia web de Lync  <br/> |
|Local pura  <br/> |No  <br/> |Experiencia web de Lync  <br/> |
|Local pura  <br/> |Sí  <br/> |Experiencia web de Lync  <br/> |
   

