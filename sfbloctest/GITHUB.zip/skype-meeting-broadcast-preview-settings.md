---
title: Skype Meeting Broadcast Preview settings
ms.author: tonysmit
author: tonysmit
ms.date: 3/20/2017
ms.audience: End User
f1_keywords: ms.lync.lac.BroadcastMeetingsPreview
ms.technology:
- Office 365 Enterprise admin
- Office 365 Midsize Business admin
- Office 365 Small Business admin
- Skype for Business
- Skype for Business admin center
- Skype for Business Online
ms.assetid: 651d4773-cbd8-49e9-b55e-7abb8064060a
---


# Skype Meeting Broadcast Preview settings

The Skype for Business customer programs provides you early access to new products and features. It enables your organization to get a sneak peek at what's coming and to test out the new features in your own environment and give feedback before we release product builds to the general public. To find out more, see  [Skype for Business preview](https://www.skypepreview.com/).
  
    
    


